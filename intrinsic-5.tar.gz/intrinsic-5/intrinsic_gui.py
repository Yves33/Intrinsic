#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

if __name__ == '__main__':
    import sys
    sys.path.insert(0,'./modules')
    from wxgridframe import GridFrame
    import intrinsic as itsq
    import wx
    import matplotlib
    matplotlib.use('WXAgg')
    class MyGridFrame(GridFrame):
        def Process(self,inpath):
            return itsq.process(inpath)

        def Display(self):
            self.res_sheet.ClearGrid()
            if self.df is None:
                return
            keys=self.df.index if self.disable_filter else itsq.filterfields()
            ## our dataframe is an array of tuples (magnitude,dimension_str), but contains nan!
            for row,key in enumerate(keys):
                self.res_sheet.SetCellValue(row,0,str(key))
                self.res_sheet.SetCellTextColour(row,0, "red")
                for col in range(len(self.df.columns)):
                    try:
                        #value may be np.nan, but as we're in a try/except block, we do'nt need to test
                        value=self.df[col][key] ## can't use iloc here
                        self.res_sheet.SetCellValue(row,col+2,str(value[0]))
                        self.res_sheet.SetCellValue(row,1,str(value[1]))
                        #self.res_sheet.SetCellTextColour(row,1, "green")
                    except:
                        pass
            #self.res_sheet.AutoSizeColumns()
            self.notebook.SetSelection(0)
            
    def main():
        redir=False
        app = wx.App(redirect=redir)
        ex = MyGridFrame(None)
        ex.Show()
        app.MainLoop()

    main()
