#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import wx
import wx.adv
import os,warnings
from wx.lib.scrolledpanel import ScrolledPanel

def autocolor(color,_typ):
    if isinstance (color,str) and color.startswith('#') and len(color)==7:
        #got an html color
        if _typ=='str':
            return color
        elif _typ=='int':
            return tuple(int(color.lstrip('#')[i:i+2], 16) for i in (0, 2 ,4))
        elif _typ=='float':
            (r,g,b)= tuple(int(color.lstrip('#')[i:i+2], 16) for i in (0, 2 ,4))
            return(r/255.0,g/255.0,b/255.0)
    elif isinstance (color, tuple) and isinstance(color[0],float) and max(color)<=1.0:
        #got a float tupple
        (r,g,b)=color[0:3]
        if _typ=='str':
            col=wx.Colour(int(color[0]*255),int(color[1]*255),int(color[2]*255))
            return col.GetAsString(flags=wx.C2S_HTML_SYNTAX)
        elif _typ=='float':
            return (r,g,b)
        elif _typ=='int':
            return(int(r*255),int(g*255),int(b*255))
    elif isinstance (color, tuple) and isinstance(color[0],int) and max(color)<=255:
        #got a float tupple
        (r,g,b)=color[0:3]
        if _typ=='str':
            col=wx.Colour(color[0],color[1],color[2])
            return col.GetAsString(flags=wx.C2S_HTML_SYNTAX)
        elif _typ=='int':
            return (r,g,b)
        elif _typ=='float':
            return(r/255.0,g/255.0,b/255.0)
    elif isinstance (color, wx._core.Colour) and isinstance(color[0],int) and max(color)<=255:
        #got a float tupple
        (r,g,b)=color[0:3]
        if _typ=='str':
            return color.GetAsString(wx.C2S_HTML_SYNTAX)
        elif _typ=='int':
            return (r,g,b)
        elif _typ=='float':
            return(r/255.0,g/255.0,b/255.0)
    else:
        if _typ=='str':
            return '#000000'
        elif _typ=='int':
            return (0.0,0.0,0.0)
        elif _typ=='float':
            return(0,0,0)

class FileDrop(wx.FileDropTarget):
    def __init__(self, window):
        wx.FileDropTarget.__init__(self)
        self.window = window

    def OnDropFiles(self, x, y, filenames):
        try:
            self.window.SetValue(filenames[0])
        except:
            self.window.SetPath(filenames[0])
        return True

class ParamPanel(ScrolledPanel):
    def __init__(self, parent,*args,**kwargs):
        ## explicit __setattr__ as we're overriding __setattr__ method
        object.__setattr__(self,'lbl_width',kwargs.pop('label_width',200))
        object.__setattr__(self,'widget_height',kwargs.pop('widget_height',-1))
        object.__setattr__(self,'widget_width',kwargs.pop('widget_width',-1))
        object.__setattr__(self,'panels',[self])
        object.__setattr__(self,'widgets',{})
        object.__setattr__(self,'collapsibles',[])
        object.__setattr__(self,'types',{})
        object.__setattr__(self,'indent',1)
        object.__setattr__(self,'autocollapse', kwargs.pop("autocollapse",True))
        super(ParamPanel,self).__init__(parent, -1)
        self.SetupScrolling(scroll_x=False)
        self.SetAutoLayout(1)

    def run_demo(self):
        #            key    wid     label        value  range   ret_type    tooltip
        #{'k':,'w':,'l':,'v':,'r':,'t':,'h':,'s':}
        self.append([None,'foldable','Basic Editors',None,None,'str','This tooltip should never be displayed.'])
        self.append([None,'label','Test label',None,'label value','str',None])
        self.append(['entry_str','entry','Fist text entry',None,'Some value','str','This entry will be converted to text.'])
        self.append(['entry_int','entry','Fist int entry',None,125,'int','This entry will be converted to integer number.'])
        self.append(['entry_float','entry','Fist float entry',None,3.14159,'float','This entry will be converted to floating point number.'])
        self.append([None,'fend'])
        self.append([None,'foldable','Spinners and sliders',None,None,'str','This tooltip should never be displayed.'])
        self.append(['spinner_int','spinner','Iterations',"0|100","5",'int','That spinner returns an integer number.'])
        self.append(['spinner_float','spinner','Threshold',"0|100|2.56","50.2",'float','This one returns a floating point number.'])
        self.append(['slider_int','slider','Max Trials',"0|100|5","50",'int','Slider can only return integer.'])
        self.append([None,'fend'])
        self.append([None,'foldable','Combos and lists',None,None,'str','This tooltip should never be displayed.'])
        self.append(['combo_str','combo','Choose a string',"Apple|Oranges|Bananas|Coconuts",'Oranges','str','Cool tooltip'])
        self.append(['combo_int','combo','Frequency',"0|50|60|12456","50",'int','Cool tooltip'])
        self.append(['checklist','checklist','Select many','apple|orange|banana|pears|stawberry|pinapple|cherry|grapes|kiwi|blackberry|melon|mango|coconut|litchis','apple|banana|pears','str','ttip'])
        self.append(['simplelist','list','Select one','apple|orange|banana|pears|stawberry|pinapple|cherry|coconut','pears','str','ttip'])
        self.append([None,'fend'])
        self.append([None,'foldable','Buttons and Checkboxes',None,None,'str','Cool tooltip'])
        self.append(['checkbox','check','A simple checkbox',None,False,'bool','Cool slider tooltip'])
        self.append(['radiobox','radio','A radio button group','One|Two|Three|Four|Five','Three','str','ttip']),
        self.append(['button','button','A button',None,"Go Now!!",'bool','Cool button tooltip'])
        self.append(['btn1|btn2|btn3|btn4','Several buttons',None,None,"1st|2nd|3rd|4th",'bool','Cool button tooltip'])
        self.append([None,'fend'])
        self.append([None,'foldable','Pickers',None,None,'str','Cool tooltip'])
        self.append(['file_open_picker','file','Open a file','Text files (*.txt)|*.pdf',"C:\\",'str','Cool button tooltip'])
        self.append(['file_save_picker','file','Save a file','',"C:\\",'str','Cool button tooltip'])
        self.append(['dir_picker','dir','Choose a directory','',"C:\\",'str','Cool button tooltip'])
        self.append(['foreground','color','Foreground color (str)',None,'#AA0055','str','ttip'])                                       #25
        self.append(['background','color','Background color (int)',None,(255,0,0),'int','ttip'])
        self.append(['any','color','Any color (float)',None,(1.0,0.0,0.0),'float','ttip'])
        self.append([None,'fend'])

    def _sz(self):
        return self.panels[-1].GetSizer()

    def _add_indent(self):
        self._sz().Add(wx.StaticText(self.panels[-1],-1,label="  "*(self.indent)*5,size=((self.indent)*10,-1)))

    def _on_collapse(self,evt):
        ##todo:collapse all other panel
        self.FitInside()
        if self.autocollapse and not evt.Collapsed:
            for w in self.collapsibles:
                if evt.EventObject!=w:
                    w.Collapse(True)
                    self.FitInside()

    def _collapse_all(self,collapse=True):
        for w in self.collapsibles:
            if isinstance(w,wx.CollapsiblePane):
                w.Collapse(collapse)
                self.FitInside()

    def _gtk3colourhook(self):
        c=wx.GetTopLevelParent(self).GetBackgroundColour()
        self.panels[0].SetBackgroundColour(c)
        self.panels[-1].SetBackgroundColour(c)
        self.SetBackgroundColour(c)

    def append(self,entry):
        def get_digits(number):
            if'.' in  number:
                return len(number.split('.')[1])
            else:
                return 0
        if isinstance(entry, list): 
            _key=entry[0]
            _widget=entry[1]
            _label=entry[2] if len(entry)>2 else None
            _range=entry[3] if len(entry)>3 else None
            _default=entry[4] if len(entry)>4 else None
            _typ=entry[5] if len(entry)>5 else None
            _ttip=entry[6] if len(entry)>6 else None
        #elif isinstance(entry, dict): 

        wx_FLAGS=wx.ALL|wx.CENTER|wx.ALIGN_CENTER_VERTICAL
        wx_FLAGS=wx.ALIGN_TOP|wx.ALIGN_LEFT
        lblw=self.lbl_width
        widh=self.widget_height
        widw=self.widget_width
        if self.panels[-1].GetSizer() is None:
            if _widget!='foldable':
                self.indent+=1
                self.panels[-1].SetSizer(wx.FlexGridSizer(cols=3))
            else:
                self.panels[-1].SetSizer(wx.BoxSizer(wx.VERTICAL))
        if _widget=="foldable":
            #if key is None: ## we must keep a ref to collapsible to enable auto collapse
            #    key=wx.NewIdRef()
            self.widgets[_key]=wx.CollapsiblePane(self.panels[-1],-1, label=_label,style=wx.CP_DEFAULT_STYLE|wx.CP_NO_TLW_RESIZE)
            self.collapsibles.append(self.widgets[_key])
            self._sz().Add(self.widgets[_key], wx_FLAGS)
            self.panels.append(self.widgets[_key].GetPane())
            ##self._gtk3colourhook()
            self.Bind(wx.EVT_COLLAPSIBLEPANE_CHANGED, self._on_collapse, self.widgets[_key])
            self.widgets[_key].Expand()
        if _widget=="fend":
            self.indent-=1
            self.panels.pop()
        if _widget=="label":
            self._add_indent()
            self._sz().Add(wx.StaticText(self.panels[-1],-1,label=str(_label),size=(lblw-self.indent*10,widh)))
            self.widgets[_key]=(wx.StaticText(self.panels[-1],-1,label=str(_default)))
            self._sz().Add(self.widgets[_key],wx_FLAGS)
            self.types[_key]=_typ
        '''
        text control. Can't get validator to work!
        '''
        if _widget=="entry":
            self._add_indent()
            self._sz().Add(wx.StaticText(self.panels[-1],-1,label=str(_label),size=(lblw-self.indent*10,widh)))
            self.widgets[_key]=wx.TextCtrl(self.panels[-1],
                                            -1,
                                            style=wx.TE_PROCESS_ENTER,
                                            value=str(_default),
                                            size=(widw,widh)
                                            )
            if _typ=='str':
                dt = FileDrop(self.widgets[_key])
                self.widgets[_key].SetDropTarget(dt)
            if _ttip:
                self.widgets[_key].SetToolTip(_ttip)
            self.widgets[_key].Bind(wx.EVT_TEXT_ENTER,lambda evt:self._dispatch_event(evt,_key))
            self.widgets[_key].Bind(wx.EVT_KILL_FOCUS,lambda evt:self._dispatch_event(evt,_key) or evt.Skip())
            self._sz().Add(self.widgets[_key], wx_FLAGS)
            self.types[_key]=_typ
        '''
        combo box control.
        '''
        if _widget=="combo":
            self._add_indent()
            self._sz().Add(wx.StaticText(self.panels[-1],-1,label=str(_label),size=(lblw-self.indent*10,widh)))
            self.widgets[_key]=wx.ComboBox(self.panels[-1],
                                            -1,
                                            choices=_range.split('|'),
                                            value="",
                                            size=(widw,widh)
                                            )
            self.widgets[_key].SetValue(str(_default))
            if _ttip:
                self.widgets[_key].SetToolTip(_ttip)
            self.widgets[_key].Bind(wx.EVT_COMBOBOX,lambda evt:self._dispatch_event(evt,_key))
            self._sz().Add(self.widgets[_key], wx_FLAGS)
            self.types[_key]=_typ
        '''
        spinner control. accepts float or int values
        '''
        if _widget=='spinner':
            self._add_indent()
            self._sz().Add(wx.StaticText(self.panels[-1],-1,label=str(_label),size=(lblw-self.indent*10,widh)))
            if _typ=='int':
                self.widgets[_key]=(wx.SpinCtrl(self.panels[-1],\
                                                    min=int(_range.split('|')[0]),\
                                                    max=int(_range.split('|')[1]),\
                                                    value=str(_default),\
                                                    size=(widw,widh))
                                                    )
                self.widgets[_key].Bind(wx.EVT_SPINCTRL,lambda evt:self._dispatch_event(evt,_key))
            elif _typ=='float':
                self.widgets[_key]=(wx.SpinCtrlDouble(self.panels[-1],-1, \
                                                    min=float(_range.split('|')[0]),\
                                                    max=float(_range.split('|')[1]),\
                                                    inc=float(_range.split('|')[2]),\
                                                    value=str(_default),\
                                                    initial=float(_default),\
                                                    size=(widw,widh))
                                                    )
                self.widgets[_key].SetDigits(get_digits(_range.split('|')[2]))
                self.widgets[_key].Bind(wx.EVT_SPINCTRLDOUBLE,lambda evt:self._dispatch_event(evt,_key))
            if _ttip:
                self.widgets[_key].SetToolTip(_ttip)
            self._sz().Add(self.widgets[_key], wx_FLAGS)
            self.types[_key]=_typ
        '''
        slider control. only accepts int values
        todo: initialize style at panel level: self.slider_flags=wx.SL_HORIZONTAL|wx.SL_AUTOTICKS|wx.SL_LABELS
        '''
        if _widget=='slider':
            self._add_indent()
            self._sz().Add(wx.StaticText(self.panels[-1],-1,label=str(_label),size=(lblw-self.indent*10,widh)))
            self.widgets[_key]=wx.Slider(self.panels[-1], 
                                            minValue=int(_range.split('|')[0]),\
                                            maxValue=int(_range.split('|')[1]),\
                                            value=int(_default),\
                                            size=(widw,widh),\
                                            style=wx.SL_HORIZONTAL
                                            )
            if _ttip:
                self.widgets[_key].SetToolTip(_ttip)
            self.widgets[_key].Bind(wx.EVT_SCROLL,lambda evt:self._dispatch_event(evt,_key))
            self._sz().Add(self.widgets[_key], wx_FLAGS)
            self.types[_key]=_typ
        '''
        checkbox control
        '''
        if _widget=='check':
            self._add_indent()
            self._sz().Add(wx.StaticText(self.panels[-1],-1,label=str(_label),size=(lblw-self.indent*10,widh)))
            self.widgets[_key]=wx.CheckBox(self.panels[-1],
                                            label=''
                                            )
            self.widgets[_key].SetValue(_default)
            if _ttip:
                self.widgets[_key].SetToolTip(_ttip)
            self.widgets[_key].Bind(wx.EVT_CHECKBOX,lambda evt:self._dispatch_event(evt,_key))
            self._sz().Add(self.widgets[_key], wx_FLAGS)
            self.types[_key]=_typ
        '''
        button control
        '''
        if _widget=='button':
            self._add_indent()
            self._sz().Add(wx.StaticText(self.panels[-1],-1,label=str(_label),size=(lblw-self.indent*10,widh)))
            self.widgets[_key]=wx.Button(self.panels[-1],
                                        label=str(_default),
                                        size=(widw,widh)
                                        )
            if _ttip:
                self.widgets[_key].SetToolTip(_ttip)
            self.widgets[_key].Bind(wx.EVT_BUTTON,lambda evt:self._dispatch_event(evt,_key))
            self._sz().Add(self.widgets[_key], wx_FLAGS)
            self.types[_key]=_typ
        '''
        file picker control
        '''
        if _widget=='file':
            self._add_indent()
            self._sz().Add(wx.StaticText(self.panels[-1],-1,label=str(_label),size=(lblw-self.indent*10,widh)))
            flags=wx.FLP_OPEN if _range and len(_range)!=0 else wx.FLP_SAVE
            self.widgets[_key]=wx.FilePickerCtrl(self.panels[-1],
                                                wildcard=_range,
                                                style=flags|wx.FLP_USE_TEXTCTRL,
                                                size=(widw,widh)
                                                )
            self.widgets[_key].SetPath(_default)
            if flags==wx.FLP_OPEN:
                dt = FileDrop(self.widgets[_key])
                self.widgets[_key].SetDropTarget(dt)
            if _ttip:
                self.widgets[_key].SetToolTip(_ttip)
            self.widgets[_key].Bind(wx.EVT_FILEPICKER_CHANGED,lambda evt:self._dispatch_event(evt,_key))
            self._sz().Add(self.widgets[_key], wx_FLAGS)
            self.types[_key]=_typ
        '''
        dir picker control
        '''
        if _widget=='dir':
            self._add_indent()
            self._sz().Add(wx.StaticText(self.panels[-1],-1,label=str(_label),size=(lblw-self.indent*10,widh)))
            self.widgets[_key]=wx.DirPickerCtrl(self.panels[-1],
                                                style=wx.FLP_USE_TEXTCTRL,
                                                size=(widw,widh))
            self.widgets[_key].SetPath(_default)
            if _ttip:
                self.widgets[_key].SetToolTip(_ttip)
            self.widgets[_key].Bind(wx.EVT_DIRPICKER_CHANGED,lambda evt:self._dispatch_event(evt,_key))
            self._sz().Add(self.widgets[_key], wx_FLAGS)
            self.types[_key]=_typ
        '''
        checklist control
        '''
        if _widget=='checklist':
            self._add_indent()
            self._sz().Add(wx.StaticText(self.panels[-1],-1,label=str(_label),size=(lblw-self.indent*10,widh)))
            self.widgets[_key]=wx.CheckListBox(self.panels[-1],
                                                -1,
                                                choices=_range.split('|'),
                                                size=(widw,-1)
                                                )
            #try co convert _default to list of int
            if _default.split('|')[0].isdigit():
                self.widgets[_key].SetCheckedItems([int(i) for i in _default.split('|')])
            else:
                self.widgets[_key].SetCheckedItems([_range.split('|').index(item) for item in _default.split('|')])
            if _ttip:
                self.widgets[_key].SetToolTip(_ttip)
            self.widgets[_key].Bind(wx.EVT_CHECKLISTBOX,lambda evt:self._dispatch_event(evt,_key))
            self._sz().Add(self.widgets[_key], wx_FLAGS)
            self.types[_key]=_typ
        '''
        list control. should be avoided and replaced with combo
        '''
        if _widget=='list':
            self._add_indent()
            self._sz().Add(wx.StaticText(self.panels[-1],-1,label=str(_label),size=(lblw-self.indent*10,widh)))
            self.widgets[_key]=wx.ListBox(self.panels[-1],
                                            -1,
                                            choices=_range.split('|'),
                                            size=(widw,-1)
                                            )
            self.widgets[_key].SetSelection(_range.split('|').index(_default))
            if _ttip:
                self.widgets[_key].SetToolTip(_ttip)
            self.widgets[_key].Bind(wx.EVT_LISTBOX,lambda evt:self._dispatch_event(evt,_key))
            self._sz().Add(self.widgets[_key], wx_FLAGS)
            self.types[_key]=_typ
        '''
        radio box control. should be avoided and replaced with combo
        '''
        if _widget=='radio':
            self._add_indent()
            self._sz().Add(wx.StaticText(self.panels[-1],-1,label=str(_label),size=(lblw-self.indent*10,widh)))
            self.widgets[_key]=wx.RadioBox(self.panels[-1], 
                                            label='',
                                            choices=_range.split('|'),
                                            style=wx.RA_SPECIFY_COLS,
                                            size=(widw,-1),
                                            majorDimension=1)
            self.widgets[_key].SetSelection(_range.split('|').index(_default))
            if _ttip:
                self.widgets[_key].SetToolTip(_ttip)
            self.widgets[_key].Bind(wx.EVT_RADIOBOX,lambda evt:self._dispatch_event(evt,_key))
            self._sz().Add(self.widgets[_key], wx_FLAGS)
            self.types[_key]=_typ
        '''
        color picker control
        '''
        if _widget=='color':
            self._add_indent()
            self._sz().Add(wx.StaticText(self.panels[-1],-1,label=str(_label),size=(lblw-self.indent*10,widh)))
            self.widgets[_key]=wx.ColourPickerCtrl(self.panels[-1])
            self.widgets[_key].SetColour(autocolor(_default,'str'))
            if _ttip:
                self.widgets[_key].SetToolTip(_ttip)
            self.widgets[_key].Bind(wx.EVT_COLOURPICKER_CHANGED,lambda evt:self._dispatch_event(evt,_key))
            self._sz().Add(self.widgets[_key], wx_FLAGS)
            self.types[_key]=_typ           
        '''
        finalize everything
        '''
        if self._sz():
            self._sz().Fit(self)
        if self.autocollapse:
            self._collapse_all(True)
        
    def get_value(self,key):
        def convert(x,typ_):
            if typ_=='float':
                return float(x)
            elif typ_=='int':
                return int(x)
            elif typ_=='str':
                return str(x)
            elif typ_=='bool':
                return bool(x)

        _w=self.widgets[key]
        _typ=self.types[key]
        if 'ComboBox' in str(type(_w)):
            return convert(_w.GetValue(),_typ)
        elif 'TextCtrl' in str(type(_w)):
            return convert(_w.GetValue(),_typ)
        elif 'SpinCtrlDouble' in str(type(_w)) or 'FloatSpin' in str(type(_w)):
            return convert(_w.GetValue(),_typ)
        elif 'SpinCtrl' in str(type(_w)):
            return convert(_w.GetValue(),_typ)
        elif 'Slider' in str(type(_w)):
            return convert(_w.GetValue(),_typ)
        elif 'CheckBox' in str(type(_w)):
            return convert(_w.GetValue(),_typ)
        elif 'RadioBox' in str(type(_w)):
            return convert(_w.GetItemLabel(_w.GetSelection()),_typ)
        elif 'ColourPickerCtrl' in str(type(_w)):
            return _w.GetColour() ## warning no conversion here
        elif 'DatePickerCtrl' in str(type(_w)):
            return convert(_w.GetValue().FormatISODate(),_typ)
        elif 'CalendarCtrl' in str(type(_w)):
            return convert(_w.GetValue(),_typ)
        elif 'StaticText' in str(type(_w)):
            return None
        elif 'StaticBitmap' in str(type(_w)):
            return None
        elif 'ListBox' in str(type(_w)) and not 'CheckListBox' in str(type(_w)):
            return convert(_w.GetString(_w.GetSelection()),_typ)
        elif 'FilePickerCtrl' in str(type(_w)):
            return convert(os.path.normpath(_w.GetPath()),_typ)
        elif 'DirPickerCtrl' in str(type(_w)):
            return convert(os.path.normpath(_w.GetPath()),_typ)
        elif 'CheckListBox' in str(type(_w)):
            return '|'.join(_w.GetCheckedStrings())
        elif 'Button' in str(type(_w)):
            return 'Idle'
        else:
            warnings.warn("Don't know how to convert "+str(type(_w)),UserWarning)
            return None

    def set_value(self,key,value):
        if key not in self.widgets.keys():
            return
        _w=self.widgets[key]
        _typ=self.types[key]
        if 'ComboBox' in str(type(_w)):
            _w.SetValue(str(value))
        elif 'TextCtrl' in str(type(_w)):
            _w.SetValue(str(value))
        elif 'SpinCtrlDouble' in str(type(_w)) or 'FloatSpin' in str(type(_w)):
            _w.SetValue(value)
        elif 'SpinCtrl' in str(type(_w)):
            _w.SetValue(str(value))
        elif 'Slider' in str(type(_w)):
            _w.SetValue(int(value))
        elif 'CheckBox' in str(type(_w)):
            _w.SetValue(bool(value))
        elif 'RadioBox' in str(type(_w)):
            if type(value)==type(0):
                _w.SetSelection(value)
            elif type(value)==type('str'):
                _w.SetSelection(_w.FindString(value))
        elif 'ColourPickerCtrl' in str(type(_w)):
            _w.SetColour(autocolor(value,'str'))
        elif 'DatePickerCtrl' in str(type(_w)):
            raise NotImplementedError ##return convert(_w.GetValue().FormatISODate(),_typ)
        elif 'CalendarCtrl' in str(type(_w)):
            raise NotImplementedError ##return convert(_w.GetDate().FormatISODate(),_typ)
        elif 'TimeCtrl' in str(type(_w)):
            raise NotImplementedError ##return convert(_w.GetValue(),_typ)
        elif 'StaticText' in str(type(_w)):
            raise NotImplementedError ##return None
        elif 'StaticBitmap' in str(type(_w)):
            raise NotImplementedError ##return None
        elif 'ListBox' in str(type(_w)) and not 'CheckListBox' in str(type(_w)):
            if type(value)==type(0):
                _w.SetSelection(value)
            elif type(value)==type('str'):
                _w.SetSelection(_w.FindString(value))
        elif 'FilePickerCtrl' in str(type(_w)):
            _w.SetPath(os.path.normpath(str(value)))
        elif 'DirPickerCtrl' in str(type(_w)):
            _w.SetPath(os.path.normpath(str(value)))
        elif 'CheckListBox' in str(type(_w)):
            _w.SetCheckedStrings(value.split('|'))
        elif 'Button' in str(type(_w)):
            raise NotImplementedError ##return 'Idle'
        else:
            warnings.warn("Don't know how to convert "+str(type(_w)),UserWarning)
            return None

    def asdict(self):
        return {k:self.get_value(k) for k in self.widgets.keys()}

    def _dispatch_event(self,event,key):
        ##print(key,self.get_value(key))
        qpevent = ParamPanelEvent(myEVT_PARAMPANEL_CHANGED, self.GetId())
        qpevent.SetValue(self.get_value(key))
        qpevent.SetKey(key)
        qpevent.SetEventObject(self)
        self.GetEventHandler().ProcessEvent(qpevent)

    def __getattr__(self,key):
        try:
            return super(ParamPanel,self).__getattribute__(key)
        except AttributeError:
            try:
                return self.get_value(key)
            except:
                raise AttributeError

    def __setattr__(self,key,value):
        if 'widgets' in self.__dict__.keys():
            if key in self.widgets.keys():
                self.set_value(key,value)
                return
        self.__dict__[key]=value

    def notify(key,value,sender=None):
        if sender is None:
            try:
                sender=wx.GetTopLevelWindows()[0] ##hackish
            except:
                raise RuntimeError("qpnotify needs one (and only one) top level window!")
        qpevent = ParamPanelEvent(myEVT_PARAMPANEL_NOTIFY, sender.GetId())
        qpevent.SetValue(value)
        qpevent.SetKey(key)
        qpevent.SetEventObject(sender)
        sender.GetEventHandler().ProcessEvent(qpevent)

myEVT_PARAMPANEL_CHANGED = wx.NewEventType()
EVT_PARAMPANEL_CHANGED = wx.PyEventBinder(myEVT_PARAMPANEL_CHANGED, 1)

myEVT_PARAMPANEL_NOTIFY = wx.NewEventType()
EVT_PARAMPANEL_NOTIFY = wx.PyEventBinder(myEVT_PARAMPANEL_NOTIFY, 1)

class ParamPanelEvent(wx.PyCommandEvent):
    def __init__(self, evtType, id):
        wx.PyCommandEvent.__init__(self, evtType, id)
        self.EventObject=None
        self.value=None
        self.key=None

    def SetKey(self, key):
        self.key = key

    def GetKey(self):
        return self.key

    def SetValue(self, value):
        self.value = value

    def GetValue(self):
        return self.value

if __name__ == '__main__':
    ID_EXIT=200
    class Example(wx.Frame):
        def __init__(self, *args, **kw):
            super(Example, self).__init__(*args, **kw)
            self.InitUI()

        def InitUI(self):
            self.pg = ParamPanel(self, label_width=250,widget_height=32,widget_width=180,autocollapse=False)
            self.pg.run_demo()
            self.pg.entry_str='dynamic text setting'
            self.pg.checkbox=True
            self.pg.radiobox='Five'
            self.pg.simplelist='cherry'
            self.pg.file_open_picker='/home/yves/Documents/url.pdf'
            self.pg.dir_picker='/usr/share'
            self.pg.foreground="#FFFF00"
            self.pg.checklist="coconut|mango"
            self.Bind(wx.EVT_SIZE, self.OnSize)
            self.Bind(EVT_PARAMPANEL_CHANGED,self.OnChange)
            self.Bind(EVT_PARAMPANEL_NOTIFY,self.OnNotify)

            filemenu= wx.Menu()
            filemenu.Append(ID_EXIT, "E&xit"," Terminate the program")
            editmenu = wx.Menu()
            menuBar = wx.MenuBar()
            menuBar.Append(filemenu, "&File")
            menuBar.Append(editmenu, "&Edit")
            self.SetMenuBar(menuBar)
            self.Bind(wx.EVT_MENU, self.OnExit, id=ID_EXIT)

            self.sizer = wx.BoxSizer(wx.VERTICAL)
            self.sizer.Add(self.pg,1,wx.EXPAND)
            self.SetSizer(self.sizer)

            sb = self.CreateStatusBar()

            self.SetTitle("Demo")
            self.Center()
            ParamPanel.notify('entry_str987','value set through notification',wx.GetTopLevelWindows()[0])

        def OnExit(self, e):
            self.Close(True)

        def OnSize(self, e):
            size = self.GetSize()
            e.Skip()

        def OnDoubleClick(self, e):
            size =  self.GetSize()

        def OnChange(self,e):
            print("Entry ",e.GetKey()," was changed to ",e.GetValue()," entry_int is still ",e.EventObject.entry_int)

        def OnNotify(self,e):
            self.pg.set_value(e.GetKey(),e.GetValue())


    class MyApp(wx.App):
        def __init__(self, *args, **kwargs):
            super(MyApp,self).__init__(self,*args,**kwargs)
            self.ex=Example(None,size=(450,512))
            self.ex.Show()

    app=MyApp()
    app.MainLoop()