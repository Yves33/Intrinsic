#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.
import sys
sys.path.insert(0,"./modules")
from wxplotdialog import PlotDialog, ParamPlotDialog

import os,sys,time
sys.path.insert(0,'./modules/')

import warnings
warnings.filterwarnings("ignore",category=UserWarning)

import matplotlib.cbook
warnings.filterwarnings("ignore",category=matplotlib.cbook.mplDeprecation)
from matplotlib.backends.backend_wxagg import (
    FigureCanvasWxAgg as FigureCanvas,
    NavigationToolbar2WxAgg
    )
import matplotlib
import matplotlib.style as mplstyle
from matplotlib.backend_bases import NavigationToolbar2
from matplotlib.figure import Figure
matplotlib.use('WXAgg')
matplotlib.rcParams["path.simplify"]
matplotlib.rcParams["path.simplify_threshold"]=1.0
matplotlib.rcParams['agg.path.chunksize'] = 20000

import wx
from wxparampanel import EVT_PARAMPANEL_CHANGED

import numpy as np
import scipy
import neo
import neomonkey
neomonkey.installmonkey()
import pandas as pd

from xyfitter import XYFitter
from baseprotocol import BaseProtocol,BaseFrame, once
from utils import *

from experiment import Experiment
######################################################################################
######################################################################################
## BASE and UTITY CLASSES
######################################################################################
######################################################################################
 
class testframe(BaseFrame):
    def __init__(self,sig,cmd,idx,parent):
        super(synframe,self).__init__(idx,parent)

    def guicommand(self,p):
        pass

    def keyevent(self,event):
        if event.GetKeyCode()==ord('N'):
            logging.getLogger().warning("'N'! are you sure? the answer is 42")

    def process(self,bitmask=0xFFFF):
        ## process is automatically called at frame creation
        pass

    @once
    def setup(self):
        #self._fig().subplots(2, 1, gridspec_kw={'height_ratios': [2, 1],"top":0.9},sharex = True)
        mosaic='''
        AAAA
        BBBB
        CDEF
        '''
        self._fig().subplot_mosaic(mosaic)
        self._axes(0).sharex(self._axes(1))
        self._cursor(self._axes(1),'h',0,
                    lambda x:self.parent.currentframe().__setattr__("fftthr",x) or \
                    self.parent.draw (False))
        #self._cursor(self._axes(0),'h',cfg.TC_FIT_STOP,
        #            lambda x:cfg.set('TC_FIT_STOP',x) or self.parent.process(0xFFFF) or self.parent.draw (False))
        ## for some unknown reason, binding the key handler using mpl_connect results in a massive slowdown of the whole program
        ## we therefore bind it through standard wx.Bind()
        self._fig().canvas.Bind(wx.EVT_KEY_DOWN,self.keyevent)
        #self._fig().canvas.mpl_connect('key_press_event', self.keyevent)

    def draw(self,drawall=True):
        self._fig().canvas.set_window_title("Ramp protocol")
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            self._axes(0).plot(self.current.s(),self.current.pA(),color='blue',gid='traces')
            self._axes(1).plot(self.voltage.s(),self.voltage.mV(),color='green',gid='traces')

class synprotocol(BaseProtocol):
    def __init__(self,sigs,interactive,fig=None):
        self.frames=[synframe(s,idx=e,parent=self) for e,s in enumerate(sigs) ]
        super(synprotocol,self).__init__(interactive,fig)

    def provides(self):
        return {}

    def results(self):
        self.r= {}
        return self.r

    ## msgwrap event dispatcher
    def dispatch(self,evt):
        key=evt.GetKey()
        value=evt.GetValue()
        p=evt.EventObject
        wait_crsr = wx.BusyCursor()
        if key in ['cmd_btn']:
            pass
        del wait_crsr

    def params(self):
        return [
            [None,'foldable','Filters',None,None,'str','This tooltip should never be displayed.'],
            ['convolve_duration','spinner','Baseline average (s)',"0|10|0.5",1.0,'float','Sets the time window for baseline removal.'],
            ['notch_frequency','combo','Notch frequency (Hz)','0|50|60','0','int','Controls the frequency of Notch filter. Use 0 to skip filter'],
            ['rectify_policy','combo','Rectification','keep|negate|abs','negate','str','How to rectify the data (peaks must be upward).'],
            ['smoothing','spinner','Smoothing (pts)',"0|10|1",1,'int','Convolution for signal smoothing.'],
            ['prefilter_btn','button',' ',None,'Filter!','str','Start event extraction'],
            [None,'fend'],
            [None,'foldable','Deconvolution',None,None,'str','This tooltip should never be displayed.'],
            #['save_template','file','Save template','',str(pathlib.Path(__file__).resolve()),'str','Saves current time range as template epsc for later correlation.'],
            ['rise_ms','spinner','Rise time (ms)',"0|15.0|0.5",1.0,'float','Time constant for rising edge. usually 0.5-2.0.'],
            ['decay_ms','spinner','Decay time (ms)',"0|50.0|0.5",4.0,'float','Time constant for falling edge. usually 4.0-10.0.'],
            ['llambda','spinner','llambda',"0|10|0.5",5.0,'float','llambda.'],
            ['order','spinner','Order',"1|20|1",7,'int','order.'],
            ['upward','check','Upward events',None,True,'bool','Upward (True) or Downward (False) events'],
            ['fft_deconvolve_btn','button',' ',None,'Deconvolve!','str','Performs signal deconvolution'],
            ['fft_extract_btn','button',' ',None,'Extract!','str','Extract events'],
            [None,'fend'],
            [None,'foldable','Event Filtering',None,None,'str','This tooltip should never be displayed.'],
            ['filter_min_ampl','spinner','Minimal amplitude',"0|2000|0.5",5.0,'float','minimum event amplitude.'],
            ['filter_max_ampl','spinner','Maximal amplitude',"0|2000|5",2000,'float','maximal event amplitude.'],
            ['filter_min_peak','spinner','Minimal peak value',"0|2000|1.0",10.0,'float','minimum event peak (above baseline).'],
            [None,'fend'],
            [None,'foldable','Event Fitting',None,None,'str','This tooltip should never be displayed.'],
            ['fit_max_wtc','spinner','Maximal time constant (s)',"0.000|0.100|0.001",0.05,'float','maximal decay time constant use 0 to disable.'],
            ['fit_visible','check','Visible events only',None,False,'bool','Only fit events in current time range'],
            ['fit_btn','button',' ',None,'Fit!','str','Attempts to fit exponential on some events'],
            [None,'fend'],
            [None,'foldable','Burst grouping',None,None,'str','This tooltip should never be displayed.'],
            ['burst_first_t','spinner','First T (s)',"0.000|1e4|0.100",0.060,'float','maximum delay between the two first spikes of a burst.'],
            ['burst_max_t','spinner','Max T (s)',"0.000|1e4|0.100",0.040,'float','maximum delay two spikes in a burst.'],
            ['burst_min_count','spinner','Minimal count',"0|1e4|1",2,'float','Minimal number of events in Burst.'],
            ['burst_btn','button',' ',None,'Make bursts!','str','Computes bursts'],
            [None,'fend'],
            [None,'foldable','Average',None,None,'str','This tooltip should never be displayed.'],
            ['avg_norm','check','Normalize before average',None,True,'bool','normalize events before averaging'],
            ['avg_onset','check','Use onset for origin',None,True,'bool','Synchronize events relative to their onset (other wise peak)'],
            ['avg_pre','spinner','Time before (s)',"0.000|0.100|0.001",0.002,'float','Time to keep before event onset.'],
            ['avg_post','spinner','Time after (s)',"0|0.100|0.001",0.01,'float','Time to keep after event onset.'],
            [None,'fend'],
        ]

def process(inpath,disable_filters):
    # the nex 4 lines should be integrated in experiment
    exp=Experiment(inpath)
    sig=exp.signal(0)
    dlg=ParamPlotDialog(None, size=(800,600))
    from pro_inputres import InputResProtocol, InputResFrame
    protocol=InputResProtocol([neomonkey.average(sig)],[20],True,dlg.fig)
    ## compared to intrinsic, we have to load the params and bind them to dispatch func in protocol
    for p in protocol.params():
        dlg.parampanel.append(p)
    dlg.parampanel.Bind(EVT_PARAMPANEL_CHANGED, protocol.dispatch)
    dlg.ShowModal()
    dlg.Destroy()
    print("done")
    return pd.DataFrame([protocol.results()]).T

if __name__ == '__main__':
    import sys
    sys.path.insert(0,'./modules')
    from wxgridframe import GridFrame
    #import synaptic as synq
    import wx
    class MyGridFrame(GridFrame):
        def Process(self,inpath):
            return process(inpath,self.disable_filter)
            
    def main():
        redir=False
        app = wx.App(redirect=redir)
        ex = MyGridFrame(None)
        ex.Show()
        app.MainLoop()

    main()
