#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import sys
sys.path.insert(0,"./modules")
from pathlib import Path

## data science stack
from config import cfg
import logging
import numpy as np
import scipy as sc
import quantities as pq
from quantities import uV,mV,V
from quantities import pA,nA,uA,mA,A
from quantities import ns,us,ms,s

import neo

from mpl_toolbutton import TriggerBtn,ToggleBtn
from xyfitter import XYFitter
from baseprotocol import once,BaseFrame,BaseProtocol

from utils import _autoscale,_clamp, _norm, _pq_mean, _pq_max, _pq_nearest,_pq_value,_pq_unit

from collections import namedtuple
'''
    IV protocol,
    counts spikes, measures spike properties, AHP, resistance,...
    input:  sigs: array of neo.io.AnalogSignal with units V, mV (units are not checked)

    cfg: lots...
    usage: protocol=ivprotocol(sig,interactive)
           print(protocol.results())
'''
class Spike(object):
    def __init__(self,signal,pos,idx,fidx,ahpbaseline=None,params=None):
        #paramset=namedtuple('paramset',[k for k in params.keys()])
        #lcfg=paramset(*[v for v in params.values()])
        #import neomonkey
        #neomonkey.installmonkey()
        pre=cfg.IV_SPIKE_PRE_TIME
        post=cfg.IV_SPIKE_POST_TIME
        self.sr=signal.sr                                       ## sampling rate
        self.pos=pos                                            ## pos of spike (in samples)in frame
        self.idx=idx                                            ## the index of spike in frame
        self.fidx=fidx                                          ## the frame the spike belongs to belongs to
        self.time=signal.s[pos]                                 ## time of spike in frame. slicing signal will return a quantity object, and without copy(), we would only keep a reference
        self.peak=signal.V[pos]                                 ## peak amplitude of spike
        self.ISI=np.nan                                         ## inter spike interval. will be calculated later
        self.evoked=False                                       ## spike is evoked spike. will be calculated later
        self.rebound=False                                      ## spike is rebound spike
        self.complete=False                                     ## all spike related measurements were done
        #self.volts=signal.t(self.time-pre,self.time+post).V    ## keep AnalogSignal instead of quantity?
        self.volts=signal[int((self.time-pre)*self.sr):int((self.time+post)*self.sr)].V ## 4 times faster than previous line. does not check boudaries
        dvdt=np.gradient(self.volts)                            ## could event multiply by signal.sr here

        ## position and value for max rising slope (in samples)
        self.maxrisepos=dvdt.argmax()
        self.maxrise=   dvdt.max() * signal.sr             ## self.dvdt[self.maxrisepos] faster?
        self.maxrisepos+=self.pos-int(pre*signal.sr)

        ## position and value for max descending slope (in samples)
        self.maxfallpos=dvdt.argmin()
        self.maxfall=   dvdt.min() * signal.sr
        self.maxfallpos+=self.pos-int(pre*signal.sr)
    
        ## position and value for threshold
        ## using second derivative threshold isn't more efficient than maximum.
        ## see https://stackoverflow.com/questions/3843017/efficiently-detect-sign-changes-in-python
        ## the latest algorithm is as follow: get the threshold pos both on first and second derivatives, and take the first one!
        try:
            thrsignal=np.gradient(dvdt)/pq.s - cfg.IV_SPIKE_DV_THRESHOLD
            self.thresholdpos1=np.where(np.diff(np.signbit(thrsignal.magnitude)))[0][0]
            self.thresholdpos1+=self.pos-int(pre*signal.sr)
        except:
            self.thresholdpos1=np.nan
        try:
            thrsignal=dvdt/pq.s - cfg.IV_SPIKE_DV_THRESHOLD
            self.thresholdpos2=np.where(np.diff(np.signbit(thrsignal.magnitude)))[0][0]
            self.thresholdpos2+=self.pos-int(pre*signal.sr)
        except:
            self.thresholdpos2=np.nan
        if cfg.IV_SPIKE_LOWEST_THRESHOLD:
            self.thresholdpos=np.nanmin([self.thresholdpos1,self.thresholdpos2])
        else:
            self.thresholdpos=self.thresholdpos1 if self.thresholdpos1!=np.nan else self.thresholdpos2

        ## if we failed at identifying a threshold, then mark spike as incomplete and use np.nan values for the remaining spike measurements
        if np.isnan(self.thresholdpos) :
            logging.getLogger('myapp').warning(f"Could not isolate threshold for spike {self.idx} in frame {self.fidx}")
            self.complete=False
            self.thresholdpos=np.nan
            self.threshold=np.nan*pq.V
            self.amplitude=np.nan*pq.V
            self.halfwidth=np.nan*pq.s
            self.hwpos=[np.nan,np.nan]
        else:
            self.complete=True
            self.thresholdpos=int(self.thresholdpos)
            self.threshold=signal.V[self.thresholdpos]
            self.amplitude=self.peak-self.threshold
            ## position and value for half width 
            ## could be more precise here: we could find the exact time at which the signal crosses zero (),
            ## instead of first point before a zero crossing event occurs
            self.halfvoltage=self.peak-(self.peak-self.threshold)/2
            hwsignal=self.volts-self.halfvoltage
            self.hwpos=np.where(np.diff(np.signbit(hwsignal.magnitude)))[0]
            self.hwpos[0]+=self.pos-int(pre*signal.sr)
            try:
                ## for weird spikes, it may happen thta voltage does not fall back to half voltage...
                self.hwpos[1]+=self.pos-int(pre*signal.sr)
                self.halfwidth=float((self.hwpos[1]-self.hwpos[0])/signal.sr)*pq.s
            except:
                self.hwpos=np.append(self.hwpos,np.nan)
                self.halfwidth=np.nan
                self.complete=False


class IVFrame(BaseFrame):
    bitmask_ALL=0xFFFF          ## reprocess time constant
    bitmask_TC =1<<0            ## reprocess time constant
    bitmask_SPIKES =1<<1        ## reprocess time constant
    def __init__(self,sig,cmd,idx,parent,current=None):
        self.voltage=sig
        self.current=cmd
        self.idx=idx
        self.fitter=None
        self.fitstart=cfg.IV_CURRENT_INJECTION_START+cfg.EPSILON
        self.fitstop=-1
        ## no spike for now
        self.spikes=[]
        self.layout=0
        super(IVFrame,self).__init__(idx,parent)

    def process(self,bitmask=0xFFFF):
        ## baseline,resistance, sagratio
        self.baseline=self.voltage.t(cfg.IV_BASELINE_START,cfg.IV_CURRENT_INJECTION_START-cfg.EPSILON).V.mean()
        self.sagpeak=self.voltage.t(cfg.IV_CURRENT_INJECTION_START,cfg.IV_CURRENT_INJECTION_START+cfg.IV_SAG_PEAK_SEARCH).V.min()
        self.sagss=self.voltage.t(cfg.IV_CURRENT_INJECTION_START+(cfg.IV_CURRENT_INJECTION_START+cfg.IV_CURRENT_INJECTION_STOP)/2
                                    ,cfg.IV_CURRENT_INJECTION_STOP).V.mean()
        self.sagratio=(self.baseline-self.sagss)/(self.baseline-self.sagpeak) if self.current<0 else np.nan
        self.resistance=(self.baseline-self.sagpeak)/self.current if self.current!=0 and self.sagratio>cfg.IV_MAX_SAG_FOR_RES else np.nan*pq.Ohm
        self.resistance_interp=np.nan*pq.Ohm

        ## other analyses are in separated funcs
        if bitmask & IVFrame.bitmask_TC and self.current<=cfg.IV_TCFIT_THRESHOLD:
            self.process_tc()
        if bitmask & IVFrame.bitmask_SPIKES:
            self.process_spikes()
            self.process_firingpattern()
            self.process_sfa()

    def process_tc(self):
        ## if required, try to determine the end of fitting region by computing peak of sag
        if self.fitstop==-1:
            self.fitstop=np.argmin(self.voltage.t(cfg.IV_CURRENT_INJECTION_START,cfg.IV_CURRENT_INJECTION_START+cfg.IV_SAG_PEAK_SEARCH))*self.voltage.sp
            self.fitstop=cfg.IV_CURRENT_INJECTION_START+(self.fitstop)*0.8
        times=self.voltage.t(self.fitstart,self.fitstop).s.magnitude
        volts=self.voltage.t(self.fitstart,self.fitstop).V.magnitude
        self.fitter=XYFitter(times,volts,
                            cfg.IV_TCFIT_ORDER,cfg.IV_TCFIT_WEIGHTED_AVERAGE,
                            maxfev=cfg.ITSQ_FIT_ITERATION_COUNT)
        if self.fitter.success:
            times=self.voltage.t(self.fitstart,cfg.IV_CURRENT_INJECTION_STOP).s.magnitude
            self.fitline=neo.AnalogSignal(self.fitter.line(times)*pq.V,
                                        sampling_period=self.voltage.sampling_period,
                                        t_start=times[0]*pq.s)
            self.fitter.tc*=pq.s  ## adjust time constant units
            ## computed resistance from fitted curve
            self.resistance_interp=(self.fitline[-1]-self.baseline)/self.current if self.current!=0 else None

    def process_tc(self):
        if self.fitstop==-1:
            for ratio in range(10,1,-1):
                self.fitstop=np.argmin(self.voltage.t(cfg.IV_CURRENT_INJECTION_START,cfg.IV_CURRENT_INJECTION_START+cfg.IV_SAG_PEAK_SEARCH))*self.voltage.sp
                self.fitstop=cfg.IV_CURRENT_INJECTION_START+(self.fitstop)*ratio/10
                times=self.voltage.t(self.fitstart,self.fitstop).s.magnitude
                volts=self.voltage.t(self.fitstart,self.fitstop).V.magnitude
                self.fitter=XYFitter(times,volts,
                            cfg.IV_TCFIT_ORDER,cfg.IV_TCFIT_WEIGHTED_AVERAGE,
                            maxfev=cfg.ITSQ_FIT_ITERATION_COUNT)
                if self.fitter.success and 0.001*pq.s<self.fitter.tc<0.25*pq.s:
                    times=self.voltage.t(self.fitstart,cfg.IV_CURRENT_INJECTION_STOP).s.magnitude
                    self.fitline=neo.AnalogSignal(self.fitter.line(times)*pq.V,
                                        sampling_period=self.voltage.sampling_period,
                                        t_start=times[0]*pq.s)
                    self.fitter.tc*=pq.s  ## adjust time constant units
                    ## computed resistance from fitted curve
                    self.resistance_interp=(self.fitline[-1]-self.baseline)/self.current if self.current!=0 else None
                    return
                ## if fit does not work, 
                self.fitstop=np.argmin(self.voltage.t(cfg.IV_CURRENT_INJECTION_START,cfg.IV_CURRENT_INJECTION_START+cfg.IV_SAG_PEAK_SEARCH))*self.voltage.sp
                self.fitstop=cfg.IV_CURRENT_INJECTION_START+(self.fitstop)*0.8
        ## normal fitting
        times=self.voltage.t(self.fitstart,self.fitstop).s.magnitude
        volts=self.voltage.t(self.fitstart,self.fitstop).V.magnitude
        self.fitter=XYFitter(times,volts,
                            cfg.IV_TCFIT_ORDER,cfg.IV_TCFIT_WEIGHTED_AVERAGE,
                            maxfev=cfg.ITSQ_FIT_ITERATION_COUNT)
        if self.fitter.success:
            times=self.voltage.t(self.fitstart,cfg.IV_CURRENT_INJECTION_STOP).s.magnitude
            self.fitline=neo.AnalogSignal(self.fitter.line(times)*pq.V,
                                        sampling_period=self.voltage.sampling_period,
                                        t_start=times[0]*pq.s)
            self.fitter.tc*=pq.s  ## adjust time constant units
            ## computed resistance from fitted curve
            self.resistance_interp=(self.fitline[-1]-self.baseline)/self.current if self.current!=0 else None


    def process_spikes(self):
        ## convenient variables to simplify writing...
        times=self.voltage.s
        volts=self.voltage.V
        ## detect peaks
        peak_pos,peak_infos=sc.signal.find_peaks(self.voltage.V, \
                                    height=float(cfg.IV_SPIKE_MIN_PEAK),\
                                    prominence=float(cfg.IV_SPIKE_MIN_AMP),\
                                    #width=(int(0.0001*sr),int(0.05*sr)),\
                                    distance=int(cfg.IV_SPIKE_MIN_INTER*self.voltage.sr),\
                                    )

        ## make sure we do not have a spike at the beginning or at the end of frame (in which case we could not take pre and post points)
        skipstart=cfg.IV_SPIKE_PRE_TIME*self.voltage.sr
        skipend=len(self.voltage)-cfg.IV_SPIKE_POST_TIME*self.voltage.sr
        peak_pos=[p for p in peak_pos if p>skipstart and p<skipend]
        ## try to determine baseline
        self.ahpbaseline=self._try_guess_ahp_baseline(peak_pos)
        #self.ahpbaseline=-60*pq.mV
        ## build the list of spikes
        ## for multiprocessing to work on windows, one has to pass the parameters
        #params=dict(zip(['IV_SPIKE_PRE_TIME','IV_SPIKE_POST_TIME','IV_SPIKE_DV_THRESHOLD','IV_SPIKE_LOWEST_THRESHOLD'],
        #                [cfg.IV_SPIKE_PRE_TIME,cfg.IV_SPIKE_POST_TIME,cfg.IV_SPIKE_DV_THRESHOLD,cfg.IV_SPIKE_LOWEST_THRESHOLD],
        #))
        if cfg.ITSQ_ENABLE_MULTIPROCESSING and len(peak_pos)>50: 
            from multiprocessing import Pool
            with Pool() as pool:
                star_peak_pos=[(self.voltage,p,e,self.idx,self.ahpbaseline)   for e,p in enumerate(peak_pos) ]
                self.spikes=pool.starmap(Spike,star_peak_pos,)
        else:
            self.spikes=[  Spike(self.voltage,p,e,self.idx,self.ahpbaseline)   for e,p in enumerate(peak_pos) ]
        ## make list of evoked and rebound spikes and save attribute in spike object
        self.reboundspikes=[s for s in self.spikes if s.time>cfg.IV_CURRENT_INJECTION_STOP and self.current<0]
        self.evokedspikes=[s for s in self.spikes if cfg.IV_CURRENT_INJECTION_START<s.time<cfg.IV_CURRENT_INJECTION_STOP and self.current>=cfg.IV_SPIKE_EVOKED_THRESHOLD]
        for s in self.reboundspikes:
            s.rebound=True
        for s in self.evokedspikes:
            s.evoked=True
        ## calculate interspike interval
        for e,s in enumerate(self.evokedspikes):
            s.ISI=s.time-cfg.IV_CURRENT_INJECTION_START if e==0 else s.time-self.evokedspikes[e-1].time
        ## for evoked spikes, extract minimum following spike, aka ahp
        ahp_spikes=[s for s in self.evokedspikes if s.complete]
        for e,s in enumerate([s for s in self.evokedspikes]):
            if e<(len(self.evokedspikes)-1): ## we are sure that there will be another spike after
                s.ahppos=s.pos+np.argmin(   self.voltage.t(s.time,min(s.time+0.05*pq.s,self.evokedspikes[e+1].time)).V  ) ## this line crashes
                s.ahp=volts[s.ahppos]####YLF26APRIL#### self.ahpbaseline-volts[s.ahppos]
            else:
                s.ahppos=s.pos+np.argmin(   self.voltage.t(s.time,min(s.time+0.05*pq.s,cfg.IV_CURRENT_INJECTION_STOP)).V    )
                s.ahp=volts[s.ahppos]####YLF26APRIL#### self.ahpbaseline-volts[s.ahppos]
        ## end of spikes processing. store meta information for drawing
        ## NB: all measurements are now quantities,hence, when using var=qty,var will represent a reference to qty.
        ## when saving with jsonpickle, this results in a py/id object rather than a quantity.
        ## multiplying these quantities by 1 creates a copy of qty objet (could also use qty.copy() or qty.rescale())
        ## an alternate solution could be tocreate a function buildmeta and call it after reloading json
        ## NB2 : we nowalways refer to times and volts, which forces copying qty
        self.meta={}
        self.meta['maxriseV']=   {'x': times[[s.maxrisepos for s in self.spikes]],\
                                  'y': volts[[s.maxrisepos for s in self.spikes]] }
        #self.meta['maxrisedV']=  {'x': times[[s.maxrisepos for s in self.spikes]],\
        #                          'y':[s.maxrise*1 for s in self.spikes] }
        self.meta['maxfallV']=   {'x': times[[s.maxfallpos for s in self.spikes]],\
                                  'y': volts[[s.maxfallpos for s in self.spikes]] }
        self.meta['peak']=       {'x': times[[s.pos for s in self.spikes]],\
                                  'y': volts[[s.pos for s in self.spikes]] }
        self.meta['threshold']=  {'x':times[[s.thresholdpos for s in self.spikes if s.complete]],\
                                  'y':volts[[s.thresholdpos for s in self.spikes  if s.complete]]}
        self.meta['hwstart']=    {'x':times[[s.hwpos[0] for s in self.spikes  if s.complete]],\
                                  'y':volts[[s.hwpos[1] for s in self.spikes  if s.complete]]}
        self.meta['hwstop']=     {'x':times[[s.hwpos[1] for s in self.spikes  if s.complete]], \
                                  'y':volts[[s.hwpos[1] for s in self.spikes  if s.complete]]}
        self.meta['ahp']=        {'x':times[[s.ahppos for s in self.evokedspikes  if s.complete]],\
                                  'y':volts[[s.ahppos for s in self.evokedspikes  if s.complete]]}
    
    def _try_guess_ahp_baseline(self,pp):
            sr=int(self.voltage.sampling_rate)
            basesignal=self.voltage.V.magnitude
            basesignal[0:int(cfg.IV_CURRENT_INJECTION_START*sr)]=np.nan
            basesignal[int(cfg.IV_CURRENT_INJECTION_STOP*sr):]=np.nan
            for p in pp:
                basesignal[p-int(cfg.IV_SPIKE_PRE_TIME*sr):p+int(cfg.IV_SPIKE_POST_TIME*sr)]=np.nan
            return np.nanmean(basesignal)*pq.V

    def process_firingpattern(self):
        '''pattern classification according to candelas et al.
        https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3424761/ (Tadros, 2012)
        https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1665382/ (graham, 2004)
        Single spike     : less than 2 AP/pulse - and both AP within the first 250ms
        Delayed          : first latency>95 ms and spiking frequency>8Hz within the  first 5 spikes
        Transient        : last spike time<1.4s - and number of spikes>3. 1.4 s seems very late to me (say 1s)
        Gap firing       : latency>95ms and avg frequency(1-8)<8Hz
        Regular tonic    : tonic and SEM ap frequency (1-4)<2
        Irregular tonic  : tonic and SEM ap frequency (1-4)>2
        Gap firing       : latency>95ms and avg frequency(1-8)<8Hz
        the above classification fails when there is an isolated spike in the middle of the frame
        I just added a special case to classify these cells as "delayed"
        '''
        def freq(spikes):
            return (len(spikes)-1)/(spikes[-1].time-spikes[0].time)
        def sem(spikes):
            return sc.stats.sem(np.diff([s.time for s in spikes]))

        self.pattern="Undetermined"
        if self.current<=0:
           self.pattern=None
        if len([s for s in self.evokedspikes])==0:
            self.pattern=="silent" ## obviously!
        elif len([s for s in self.evokedspikes])<=2 and max([s.time-cfg.IV_CURRENT_INJECTION_START for s in self.evokedspikes])<0.125:
            self.pattern=p="single" ## strange that doublet spiking are indeed considered as single spiking
        elif len([s for s in self.evokedspikes])>=5 and min([s.time-cfg.IV_CURRENT_INJECTION_START for s in self.evokedspikes])>0.1:
            self.pattern=="delayed"## 
        elif len([s for s in self.evokedspikes])>=3 and max([s.time-cfg.IV_CURRENT_INJECTION_START for s in self.evokedspikes])<1.0:
            self.pattern="transient"
        elif len([s for s in self.evokedspikes])>=3 and min([s.time-cfg.IV_CURRENT_INJECTION_START for s in self.evokedspikes])>0.095 and freq(self.evokedspikes[:8])<8.0:
            self.pattern="gap"
        elif len([s for s in self.evokedspikes])>=3 and sem(self.evokedspikes[:4])>2:
            self.pattern="tonic_irregular"
        elif len([s for s in self.evokedspikes])>=3 and sem(self.evokedspikes[:4])<2:
            self.pattern="tonic"

    def process_sfa(self):
        if len(self.evokedspikes)<cfg.IV_MIN_SPIKES_FOR_SFADAPT:
            self.sfa_freq_lin=None
            self.sfa_freq_log=None
            self.sfa_freq_div=None
            self.sfa_peak_lin=None
            self.sfa_peak_log=None
            self.sfa_peak_div=None
            self.fano=None
        else:
            ## for intervals
            y=[s.ISI for s in self.evokedspikes[1:] ]
            x=list(range(len(y)))
            self.sfa_freq_lin, self.freq_intercept_lin, r_value_lin, p_value_lin, std_err_lin = sc.stats.linregress(x,y)
            self.sfa_freq_log, self.freq_intercept_log, r_value_log, p_value_log, std_err_log = sc.stats.linregress(x,np.log(y))
            self.sfa_freq_div =self.evokedspikes[-1].ISI/self.evokedspikes[1].ISI
            self.fano=np.std(y)/np.mean(y)
            ## for peaks
            y=[s.peak for s in self.evokedspikes[1:] ]
            x=list(range(len(y)))
            self.sfa_peak_lin, self.peak_intercept_lin, r_value_lin, p_value_lin, std_err_lin = sc.stats.linregress(x,y)
            self.sfa_peak_log, self.peak_intercept_log, r_value_log, p_value_log, std_err_log = sc.stats.linregress(x,np.log(y))
            self.sfa_peak_div =self.evokedspikes[-1].peak/self.evokedspikes[1].peak

    def activate(self):
        self._get_cursor(0).setpos(self.fitstart)
        self._get_cursor(1).setpos(self.fitstop)

    def deactivate(self):
        pass

    def togglegraphs(self,*args,**kwargs):
        for f in self.parent.frames:
            f.layout=f.layout+1 if f.layout<1 else 0
        self.draw(True)
        self._fig().canvas.draw()

    @once
    def setup(self):
        ## we need to add a button to trigger display of charts, but we don't need to keep a ref.
        ## keeping a ref would furthermore prevent correct pickling of object!
        btn=TriggerBtn(self._fig(),"charts",'alt+c',str(Path(__file__).parent/'resources/fa-linechart-solid.png'),'Chart graphics',
                    lambda *args,**kwargs:self.parent.currentframe().togglegraphs(*args,**kwargs))
        ## create main axes and set ax gid
        mainaxes=self._fig().subplots(2, 1, gridspec_kw={'height_ratios': [3, 1],"top":0.9},sharex = True)
        for ax in mainaxes.flatten():
            ax.set_gid('main')
        ## append cursors
        self._cursor(self._axes(),'v',self.fitstart,
                    lambda x:self.parent.currentframe().__setattr__('fitstart',x*pq.s) or \
                        self.parent.process(IVFrame.bitmask_TC) or \
                        self.parent.draw (False)
                    )
        self._cursor(self._axes(),'v',self.fitstop,
                    lambda x:self.parent.currentframe().__setattr__('fitstop',x*pq.s) or \
                        self.parent.process(IVFrame.bitmask_TC) or \
                        self.parent.draw (False)
                    )
        self._cursor(self._axes(0),'h',cfg.IV_SPIKE_MIN_PEAK,
                    lambda x:cfg.set('IV_SPIKE_MIN_PEAK',x*pq.V) or \
                        cfg.set('IV_SPIKE_MIN_AMP',(x*pq.V-self.parent.cursors[3].getpos())) or \
                        self.parent.process(IVFrame.bitmask_SPIKES) or \
                        self.parent.draw (False)
                    )
        self._cursor(self._axes(0),'h',cfg.IV_SPIKE_MIN_PEAK-cfg.IV_SPIKE_MIN_AMP,
                    lambda x:cfg.set('IV_SPIKE_MIN_AMP',cfg.IV_SPIKE_MIN_PEAK-x*pq.V) or \
                        self.parent.process(IVFrame.bitmask_SPIKES) or \
                        self.parent.draw (False)
                    )
        self._cursor(self._axes(1),'h',cfg.IV_SPIKE_DV_THRESHOLD,
                    lambda x:cfg.set('IV_SPIKE_DV_THRESHOLD',x) or self.parent.process(IVFrame.bitmask_SPIKES) or self.parent.draw (False)
                    )
        ## creates another set of axes and set gid
        altaxes=self._fig().subplots(2,3)
        for ax in altaxes.flatten():
            ax.set_gid('alt')
            ax.set_visible(False)

    def draw(self,drawall=True):
        def showgid(axes,gid): ## should belong to BaseProtocol
            for ax in axes:
                ax.set_visible(ax.get_gid()==gid)
                
        self.setup() ## ensure that axes are ready!
        self._fig().canvas.TopLevelParent.SetTitle(f"IV/Spontaneous firing protocol {self.current}pA")
        if self.layout==0:
            showgid(self._axes(),'main')
            self.drawmain(drawall)
        else:
            showgid(self._axes(),'alt')
            self.drawcharts(drawall)

    def drawcharts(self,drawall=True):
        axes=[ax for ax in self._axes() if ax.get_gid()=='alt']
        for ax in axes:
            ax.clear()
        a00,a01,a02,a10,a11,a12=axes
        if len(self.spikes)<1:
            return
        a00.plot(self.spikes[0].volts,np.gradient(self.spikes[0].volts)*self.voltage.sr,color='blue')
        if len(self.spikes)>1:
            for s in self.spikes[1:]:
                a00.plot(s.volts,np.gradient(s.volts)*self.voltage.sr,color='orange')
        a10.plot(np.mean(np.array([s.volts for s in self.spikes]),axis=0),
                np.mean(np.array([np.gradient(s.volts)*self.voltage.sr for s in self.spikes]),axis=0),color='blue' )
        a00.set(xlabel='Voltage (V)',ylabel='dV (V)',title='Phase plane')
        if len(self.evokedspikes)>=cfg.IV_MIN_SPIKES_FOR_SFADAPT:
            y=[s.ISI for s in self.evokedspikes[1:] ]
            x=list(range(len(y)))
            a01.plot(x, y,"o",color='black')
            a01.plot(x, [s*self.sfa_freq_lin+self.freq_intercept_lin for s in x],color='blue')
            a01.set(xlabel='Spike index',ylabel='Interval',title='freq=f(delay)')
            a11.plot(x, np.log(y),"o",color='black')
            a11.plot(x, [s*self.sfa_freq_log+self.freq_intercept_log for s in x],color='blue')
            a11.set(xlabel='Spike index',ylabel='Interval',title='log(freq)=f(delay)')
            y=[s.peak for s in self.evokedspikes[1:] ]
            a02.plot(x, y,"o",color='black')
            a02.plot(x, [s*self.sfa_peak_lin+self.peak_intercept_lin for s in x],color='blue')
            a02.set(xlabel='Spike index',ylabel='Peak',title='peak=f(delay)')
            a12.plot(x, np.log(y),"o",color='black')
            a12.plot(x, [s*self.sfa_peak_log+self.peak_intercept_log for s in x],color='blue')
            a12.set(xlabel='Spike index',ylabel='Peak',title='log(peak)=f(delay)')
        self._fig().tight_layout()

    def drawmain(self,drawall=True):
        title=''
        a0,a1=[ax for ax in self._axes() if ax.get_gid()=='main']
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            aa=len(self.voltage)<200e3
            a0.plot(self.voltage.s, self.voltage.V,color='blue', gid='traces',aa=aa, linewidth=1)
            a1.plot(self.voltage.s,np.gradient(self.voltage.V), color='green',gid='traces',aa=aa,linewidth=1)
            a1.plot(self.voltage.s,np.gradient(np.gradient(self.voltage.V)), color='orange',gid='traces',aa=aa,linewidth=1)
            _autoscale(a0,self.voltage.s,self.voltage.V)
        self._clf(['markers'])
        a0.axhline(self.baseline,color="grey",linestyle ="--",gid='markers')
        
        if self.current<0: ## for negative current, plot sagss and sagpeak
            title+=f'sagratio: {self.sagratio:.2f} '
            a0.axhline(self.sagss,color="blue",linestyle ="--",gid='markers')
            a0.axhline(self.sagpeak,color="orange",linestyle ="--",gid='markers')
        if self.fitter and self.fitter.success and self.current<=cfg.IV_TCFIT_THRESHOLD: ##plot fitter if fitting was successful  (or if fitter esists)
            title+=f'TC: {self.fitter.tc} '
            a0.plot( self.fitline.s, self.fitline.V,color='red',gid='markers')
        ## plot spike keypoints
        a0.plot(self.meta['peak']['x'],self.meta['peak']['y'],"x",color="red",gid="markers")
        a0.plot(self.meta['maxriseV']['x'],self.meta['maxriseV']['y'],"o",color="orange",gid="markers")
        a0.plot(self.meta['threshold']['x'],self.meta['threshold']['y'],"+",color="red",gid="markers")
        a0.plot(self.meta['hwstart']['x'],self.meta['hwstart']['y'],"3",color="red",gid="markers")
        a0.plot(self.meta['hwstop']['x'],self.meta['hwstop']['y'],"4",color="red",gid="markers")
        a0.plot(self.meta['ahp']['x'],self.meta['ahp']['y'],"+",color="purple",gid="markers")
        a0.set_title(title)

    def __getstate__(self):
        state = self.__dict__.copy()
        #del state['parent']
        del state['reboundspikes']
        del state['evokedspikes']
        return state


class IVProtocol(BaseProtocol):
    def __init__(self,sigs,cmds,interactive,fig=None):
        self.frames=[IVFrame(s,cmds[e],idx=e,parent=self) for e,s in enumerate(sigs) ]
        super(IVProtocol,self).__init__(interactive,fig=fig)
    
    @classmethod
    def fromexp(cls,exp):
        voltage=exp.signal(0)
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            epochs=exp.protocol.asepochs(0)
            cfg.IV_CURRENT_INJECTION_START=epochs[0][1]['start']
            cfg.IV_CURRENT_INJECTION_STOP=epochs[0][1]['stop']
            cfg.IV_CURRENT_STEPS=[e[1]['lvl'] for e in epochs]
        return cls(voltage,cfg.IV_CURRENT_STEPS,True,None)

    def provides(self):
        r={'IV_baseline':'average baseline (all frames).',
                'IV_resistance':'average resistance (frames with sag_ratio>0.95).',
                'IV_resistance_interp':'interpolated resistance (calculated from fit).',
                'IV_tc':'average time constant (frames with injected current<IV_TCFIT_THRESHOLD).',
                f'IV_sagratio_I={cfg.IV_SAG_TARGET_CURRENT}':'sag ratio (base-ss)/(base-peak) for IV_SAGRATIO_TGT_CURRENT amplitude.',
                f'IV_sagratio_tgt={cfg.IV_SAG_TARGET_VOLTAGE}':'sag ratio (base-ss)/(base-peak) for frame with baseline-steadystate closest to IV_SAGRATIO_TGT_VOLTAGE.',
                'IV_rheobase':'current required to observe a spike between cfg.IV_CURRENT_INJECTION_START and cfg.IV_CURRENT_INJECTION_STOP.',
                'IV_avg_spike_threshold':'spike threshold. average computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_avg_spike_peak':'spike peak. averagecomputed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_avg_spike_amplitude':'spike amplitude (=peak-threshold). averagecomputed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_avg_spike_half_width':'spike half width (at (peak-threshold)/2). averagecomputed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_avg_spike_max_rise_slope':'spike maximum rise slope. averagecomputed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_avg_spike_max_fall_slope':'spike maximum fall slope. averagecomputed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_avg_spike_ahp':'spike ahp. average computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_avg_spike_thr2ahp':'difference between threshold and ahp (aka fast_ahp). averagecomputed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_first_spike_threshold':'spike threshold. computed on first spike of first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_first_spike_peak':'spike peak. computed on first spike of first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_first_spike_amplitude':'spike amplitude (=peak-threshold). computed on first spike of first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_first_spike_half_width':'spike half width (at (peak-threshold)/2). computed on first spike of first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_first_spike_max_rise_slope':'spike maximum rise slope. computed on first spike of first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_first_spike_max_fall_slope':'spike maximum fall slope. computed on first spike of first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_first_spike_ahp':'spike ahp. computed on first spike of first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_first_spike_thr2ahp':'difference between threshold and ahp (aka fast_ahp). computed on first spike of first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_first_spike_delay':'delay of first spike. computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_first_spike_interval':'interspike interval for two first spikes. computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_last_spike_interval':'interspike interval for two last spikes. computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_first_div_last_spike_interval':'ratio between first and last spike intervals. computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_sfa_freq_lin':'spike frequency adaptation of spike intervals - linear fit. computed on frame with the more spikes if number of spikes > cfg.IV_MIN_SPIKES_FOR_SFADAPT.',
                'IV_sfa_freq_log':'spike frequency adaptation of spike intervals - log fit. computed on frame with the more spikes if number of spikes > cfg.IV_MIN_SPIKES_FOR_SFADAPT.',
                'IV_sfa_freq_div':'spike frequency adaptation of spike intervals - quotient. computed on frame with the more spikes if number of spikes > cfg.IV_MIN_SPIKES_FOR_SFADAPT.',
                'IV_sfa_peak_lin':'spike frequency adaptation of spike peak - linear fit. computed on frame with the more spikes if number of spikes > cfg.IV_MIN_SPIKES_FOR_SFADAPT.',
                'IV_sfa_peak_log':'spike frequency adaptation of spike peak - log fit. computed on frame with the more spikes if number of spikes > cfg.IV_MIN_SPIKES_FOR_SFADAPT.',
                'IV_sfa_peak_div':'spike frequency adaptation of spike peak - quotient. computed on frame with the more spikes if number of spikes > cfg.IV_MIN_SPIKES_FOR_SFADAPT.',
                'IV_max_nb_spikes':'maximal number of spikes evoked',
                'IV_max_freq':'maximal firing frequency',
                'IV_firing_pattern':'spike firing pattern. buggy and meaningless',
                'IV_fano':'fano factor. computed on frames with the more spikes',
                }
        for c in cfg.IV_CURRENT_STEPS:
            r.update({f'IV_evoked_spikes_({c})':f'number of evoked spikes for {c}pA injected current.'})
        for c in cfg.IV_CURRENT_STEPS:
            r.update({f'IV_rebound_spikes_({c})':f'number of rebound spikes for {c}pA injected current.'})
        return r

    def results(self):
        ## todo use contextlib to suppress errors 
        self.r={}
        self.r['IV_baseline']            =_pq_mean([f.baseline for f in self.frames if f.enabled ] , cfg.OUTPUT_V_UNIT)
        self.r['IV_resistance']          =_pq_mean([f.resistance for f in self.frames if f.current<0 and f.sagratio>=cfg.IV_MAX_SAG_FOR_RES and f.enabled] , cfg.OUTPUT_OHM_UNIT)
        self.r['IV_resistance_interp']   =_pq_mean([f.resistance_interp for f in self.frames if f.current<cfg.IV_TCFIT_THRESHOLD and f.enabled and f.fitter.success] , cfg.OUTPUT_OHM_UNIT)
        self.r['IV_tc']                  =_pq_mean([f.fitter.tc for f in self.frames if f.current<cfg.IV_TCFIT_THRESHOLD and f.enabled and f.fitter.success] , cfg.OUTPUT_S_UNIT)
        ## sag ratio
        frames_for_sag=sorted([f for f in self.frames if f.enabled],key=lambda f:np.fabs((f.baseline-f.sagss)-cfg.IV_SAG_TARGET_VOLTAGE))
        self.r[f'IV_sagratio_I={cfg.IV_SAG_TARGET_CURRENT}']    =np.nanmean([f.sagratio for f in self.frames if f.current==cfg.IV_SAG_TARGET_CURRENT and f.enabled]) if len(frames_for_sag) else np.nan
        self.r[f'IV_sagratio_tgt={cfg.IV_SAG_TARGET_VOLTAGE}']  =frames_for_sag[0].sagratio  if len(frames_for_sag) else np.nan
        
        #spikes
        frames_with_evoked_spikes=[f for f in self.frames if f.current>=0 and len(f.evokedspikes)>0 and f.enabled]
        if len(frames_with_evoked_spikes)>0:
            self.r[f'IV_rheobase']=frames_with_evoked_spikes[0].current.rescale(cfg.OUTPUT_A_UNIT)
        ##
        frames_with_min_spikes=[f for f in self.frames if len(f.evokedspikes)>=cfg.IV_MIN_SPIKES_FOR_MEASURE and f.enabled]
        if len(frames_with_min_spikes)>0:
            reference_frame=frames_with_min_spikes[0]
            self.r['IV_avg_spike_threshold']                 =_pq_mean([s.threshold for s in reference_frame.evokedspikes] , cfg.OUTPUT_V_UNIT)
            self.r['IV_avg_spike_peak']                      =_pq_mean([s.peak for s in reference_frame.evokedspikes] , cfg.OUTPUT_V_UNIT)
            self.r['IV_avg_spike_amplitude']                 =_pq_mean([s.amplitude for s in reference_frame.evokedspikes] , cfg.OUTPUT_V_UNIT)
            self.r['IV_avg_spike_half_width']                =_pq_mean([s.halfwidth for s in reference_frame.evokedspikes] , cfg.OUTPUT_S_UNIT)
            self.r['IV_avg_spike_max_rise_slope']            =_pq_mean([s.maxrise for s in reference_frame.evokedspikes] , cfg.OUTPUT_V_UNIT/cfg.OUTPUT_S_UNIT)
            self.r['IV_avg_spike_max_fall_slope']            =_pq_mean([s.maxfall for s in reference_frame.evokedspikes] , cfg.OUTPUT_V_UNIT/cfg.OUTPUT_S_UNIT)
            self.r['IV_avg_spike_ahp']                       =_pq_mean([reference_frame.ahpbaseline-s.ahp for s in reference_frame.evokedspikes if s.complete ] , cfg.OUTPUT_V_UNIT)
            self.r['IV_avg_spike_thr2ahp']                   =_pq_mean([s.threshold-s.ahp for s in reference_frame.evokedspikes if s.complete ] , cfg.OUTPUT_V_UNIT)
            #same with first spike instead of average
            self.r['IV_first_spike_threshold']               =reference_frame.evokedspikes[0].threshold.rescale(cfg.OUTPUT_V_UNIT)
            self.r['IV_first_spike_peak']                    =reference_frame.evokedspikes[0].peak.rescale(cfg.OUTPUT_V_UNIT)
            self.r['IV_first_spike_amplitude']               =reference_frame.evokedspikes[0].amplitude.rescale(cfg.OUTPUT_V_UNIT)
            self.r['IV_first_spike_half_width']              =reference_frame.evokedspikes[0].halfwidth.rescale(cfg.OUTPUT_S_UNIT)
            self.r['IV_first_spike_max_rise_slope']          =reference_frame.evokedspikes[0].maxrise.rescale(cfg.OUTPUT_V_UNIT/cfg.OUTPUT_S_UNIT)
            self.r['IV_first_spike_max_fall_slope']          =reference_frame.evokedspikes[0].maxfall.rescale(cfg.OUTPUT_V_UNIT/cfg.OUTPUT_S_UNIT)
            if reference_frame.evokedspikes[0].complete:
                self.r['IV_first_spike_ahp']                 =(reference_frame.ahpbaseline-reference_frame.evokedspikes[0].ahp).rescale(cfg.OUTPUT_V_UNIT)
                self.r['IV_first_spike_thr2ahp']             =(reference_frame.evokedspikes[0].threshold-reference_frame.evokedspikes[0].ahp).rescale(cfg.OUTPUT_V_UNIT)
            else:
                self.r['IV_first_spike_ahp']                   =np.nan
                self.r['IV_first_spike_thr2ahp']               =np.nan
            ##
            self.r['IV_first_spike_delay']                   =(reference_frame.evokedspikes[0].time-cfg.IV_CURRENT_INJECTION_START).rescale(cfg.OUTPUT_S_UNIT)
        ## in order to compute ISI, we need at least 3 spikes!
        frames_with_min_spikes=[f for f in self.frames if len(f.evokedspikes)>=max(3,cfg.IV_MIN_SPIKES_FOR_MEASURE) and f.enabled]
        if len(frames_with_min_spikes)>0:
            reference_frame=frames_with_min_spikes[0]
            self.r['IV_first_spike_interval']                =reference_frame.evokedspikes[1].ISI.rescale(cfg.OUTPUT_S_UNIT)
            self.r['IV_last_spike_interval']                 =reference_frame.evokedspikes[-1].ISI.rescale(cfg.OUTPUT_S_UNIT)
            self.r['IV_first_div_last_spike_interval']       =self.r['IV_first_spike_interval']/self.r['IV_last_spike_interval']
        frames_with_max_spikes=sorted([f for f in self.frames if len(f.evokedspikes)>cfg.IV_MIN_SPIKES_FOR_SFADAPT and f.enabled],key=lambda f:len(f.evokedspikes))
        if len(frames_with_max_spikes)>0:
            self.r['IV_sfa_freq_lin']                        =frames_with_max_spikes[-1].sfa_freq_lin
            self.r['IV_sfa_freq_log']                        =frames_with_max_spikes[-1].sfa_freq_log
            self.r['IV_sfa_freq_div']                        =frames_with_max_spikes[-1].sfa_freq_div
            self.r['IV_sfa_peak_lin']                        =frames_with_max_spikes[-1].sfa_peak_lin
            self.r['IV_sfa_peak_log']                        =frames_with_max_spikes[-1].sfa_peak_log
            self.r['IV_sfa_peak_div']                        =frames_with_max_spikes[-1].sfa_peak_div
        self.r['IV_max_nb_spikes']                           =np.max([len(f.evokedspikes) for f in self.frames])            
        self.r['IV_max_freq']                                =(self.r['IV_max_nb_spikes'] /(cfg.IV_CURRENT_INJECTION_STOP-cfg.IV_CURRENT_INJECTION_START)).rescale(pq.Hz)
        self.r['IV_max_duration']                            =_pq_max(  [(f.evokedspikes[-1].time-f.evokedspikes[0].time) if len(f.evokedspikes)>2 else np.nan*pq.s for f in self.frames] , cfg.OUTPUT_S_UNIT)
        self.r['IV_max_freq_peak']                           =(self.r['IV_max_nb_spikes'] / self.r['IV_max_duration']).rescale(pq.Hz)
        for f in self.frames:
            self.r[f'IV_evoked_spikes_({f.current})']        =len(f.evokedspikes)
        for f in self.frames:
            self.r[f'IV_rebound_spikes_({f.current})']       =len(f.reboundspikes)
        frames_with_max_spikes=sorted(self.frames,key=lambda f:len(f.evokedspikes)) ## must be recomputed as single spike frames or zero spike frames can be used to compute the firing pattern
        self.r['IV_firing_pattern']                          =frames_with_max_spikes[-1].pattern
        self.r['IV_fano']                                    =frames_with_max_spikes[-1].fano
        return self.r

    def params(self):
        return []

    def dispatch(self,evt):
        key=evt.GetKey()                ## retrieve the key for event, i.e the control that was modified
        # wait_crsr = wx.BusyCursor()   ## show some fancy cursor (useless!)
        if key in ['cmd_btn']:
            ## you may pass either the modified value or the entire parameter set (as dict) to event handler
            #value=evt.GetValue()
            #p=evt.EventObject
            #self.currentframe().process(value, p)
            pass
        # del wait_crsr                    ## restore previous cursor

    #def __getstate__(self):
    #    return super(IVProtocol,self).__getstate__(self)