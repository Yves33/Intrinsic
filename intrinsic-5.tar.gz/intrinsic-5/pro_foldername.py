#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import os,sys
sys.path.insert(0,"./modules")
from pathlib import Path
from config import cfg
import logging

'''
    Folder Name Protocol,
    Not really a protocol... but can be implemented as a protocol
    extracts info from folder name
    input:  fpath: path to folder containing recordings
    cfg:    FOLDER_NAMING_SCHEME, FOLDER_NAMING_SEP
    usage:  protocol=FolderNameProtocol(path)
            print(protocol.results())
'''
class FolderNameProtocol:
    def __init__(self,fpath, interactive=True,fig=None):
        self.r={'_FOLD_fullpath':'','_FOLD_filename':''}
        if os.path.isfile(fpath):
            self.r['_FOLD_filename']=Path(fpath).name
            fpath=str(Path(fpath).parent)
        if os.path.isdir(fpath):
            self.r['_FOLD_filename']=Path(fpath).name
            self.fpath=str(fpath)

    def provides(self):
        keys=cfg.FOLDER_NAMING_SCHEME.split(cfg.FOLDER_NAMING_SEP)
        r={'_FOLD_fullpath':'fullpath to folder',
           '_FOLD_filename':'the file or folder name'}
        r.update({'_FOLD_'+k:'no description' for k in keys})
        return r

    def results(self):
        keys=cfg.FOLDER_NAMING_SCHEME.split(cfg.FOLDER_NAMING_SEP)
        try:
            values=str(Path(self.fpath).name).split(cfg.FOLDER_NAMING_SEP)
            self.r.update({'_FOLD_'+k:v for k,v in zip(keys,values)})
        except:
            logging.getLogger('myapp').warning("Inconsistent folder naming. Check cfg.FOLDER_NAMING_SCHEME and cfg.FOLDER_NAMING_SEP values")
            self.r.update({'_FOLD_'+k:'' for k in keys })
            self.r.update({'_FOLD_fullpath':self.fpath})
        return self.r