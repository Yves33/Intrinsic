#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import sys
sys.path.insert(0,"./modules")
from pathlib import Path

## data science stack
from config import cfg
import logging
import numpy as np
import scipy as sc
#from scipy.ndimage import uniform_filter1d ## much faster than np.convolve
import quantities as pq
from quantities import uV,mV,V
from quantities import pA,nA,uA,mA,A
from quantities import ns,us,ms,s

import neo

from mpl_toolbutton import TriggerBtn,ToggleBtn
from xyfitter import XYFitter
from baseprotocol import once,BaseFrame,BaseProtocol

from utils import _autoscale,_clamp, _norm, _pq_mean, _pq_max, _pq_nearest,_pq_value,_pq_unit

from collections import namedtuple
import matplotlib.style as mplstyle
import wx
'''
    (I/E)PSCs protocol,
    counts synaptic events, measures event properties (amplitude, freq, time to peak, time to decay)...
    input:  sigs: array of neo.io.AnalogSignal with units A, pA (units are not checked)

    cfg: lots...
    usage: protocol=pscprotocol(sig,interactive)
           print(protocol.results())
'''

class pscevt:
    def __init__(self,data,sr,onset,n):
        self.onset=onset ## event onset as position in signal (int)
        self.nextonset=n ## used for fitting
        self.data=data   ## signal, ususally pA or mV
        self.sr=sr
        maxT=25e-3*pq.s  ## cfg.PSC_MAX_TIME
        maxsamples=int(onset+float(maxT*sr))
        self.nextevt=n
        self.inter=self.nextevt-self.onset if self.nextevt else None
        if n is None:
            self.offset=min(maxsamples, len(data))
        else:
            self.offset=min(n,maxsamples)          ## maximal epsc duration
        start=self.onset
        stop=min(self.offset, self.onset+int(3e-3*sr))      ## maximal time to peak
        self.peakposition=self.onset+np.argmax(np.convolve(data[start:stop],np.ones(3)/3))
        self.peakamplitude=data[self.peakposition]-data[self.onset]
        self.peakvalue=data[self.peakposition]
        self.fitline=[[],[]]
        self.fitter=None
        self.data=data ## keep ref to data
        self.sr=sr
        self.isolated=False

    def getdata(pre,post,refpt):
        return self.data[self.refpt-pre,self.refpt+post]

class PSCFrame(BaseFrame):
    PROCESS_BASELINE=0x0001
    PROCESS_EXTRACT=0x0002
    PROCESS_ANALYSE=0x0004
    def __init__(self,sig,idx,parent):
        # baseline removal
        self.current=sig
        self.sr=self.current.sampling_rate
        self.dt=(1000/self.current.sampling_rate).simplified
        self.dt=(self.dt*100)/100                               ## truncated value of sample interval in case it was 0.09923666666
        self.corrected=self.current                             ## corrected signal (after baseline correction, notch filtering,smoothing and rectification)
        self.convolved=np.zeros_like(self.corrected.pA)         ## convolved signal
        self.thresholded=self.convolved                         ## truncated convolved signal
        self.baseline=0
        self.fftthr=0
        self.events=[]
        self.filtered_events=[]
        self.bursts=[]
        self.average=[]
        super(PSCFrame,self).__init__(idx,parent)

    def prefilter(self,p):
        self.corrected=self.current.pA
        if p.convolve_duration>0:
            npts=int(p.convolve_duration*self.sr)
            ## np.convolve is very slow! see https://stackoverflow.com/questions/13728392/moving-average-or-running-mean
            #self.ccurrent-=np.convolve(self.ccurrent,np.ones(npts)/(npts), mode='same')
            self.corrected-=sc.ndimage.uniform_filter1d(self.corrected, npts)*self.corrected.units
        if p.notch_frequency>0:
            b_notch, a_notch = sc.signal.iirnotch(p.notch_frequency, 20, self.sr)
            self.corrected=sc.signal.filtfilt(b_notch, a_notch, self.corrected)*self.corrected.units
        if p.rectify_policy=='keep':
            pass
        elif p.rectify_policy=='abs':
            self.corrected=abs(self.corrected)
        elif p.rectify_policy=='negate':
            self.corrected=-1*(self.corrected)
        if p.smoothing>1:
            ## np.convolve is very slow! see https://stackoverflow.com/questions/13728392/moving-average-or-running-mean
            #self.corrected=np.convolve(self.corrected,np.ones(p.smoothing)/p.smoothing, mode='same')*self.corrected.units
            self.corrected-=sc.ndimage.uniform_filter1d(self.corrected, p.smoothing)*self.corrected.units
        # self.corrected=neo.AnalogSignal(self.corrected,sampling_rate=self.current.sampling_rate,units=self.current.units)
        self.corrected=neo.AnalogSignal(self.corrected,sampling_rate=self.current.sampling_rate)
        self.trace.set_data(self.current.s, self.corrected.pA)
        _autoscale(self._axes(0),self.corrected.s,self.corrected.pA)
        self._fig().canvas.draw()

    def fftdeconvolve(self, p):
        def mktemplate_old(tau_1, tau_2,tmax,dt,sign=1):
            t_psc = np.arange(0, tmax+dt, dt)
            Aprime = (tau_2/tau_1)**(tau_1/(tau_1-tau_2))
            template = 1./Aprime * (-np.exp(-t_psc/tau_1) + np.exp((-t_psc/tau_2)))
            return template*sign

        #self.template=mktemplate(p.rise_ms*pq.ms,
        #                          p.decay_ms*pq.ms,
        #                          self.current.ms[-1],
        #                          self.dt,sign=int(2*int(p.upward)-1))
        #t_psc=np.zeros_like(self.current.ms).magnitude
        t_psc=self.current.ms.magnitude.copy()
        tau_1=p.rise_ms ##*pq.ms,
        tau_2=p.decay_ms ##*pq.ms,
        Aprime = (tau_2/tau_1)**(tau_1/(tau_1-tau_2))
        self.template = 1./Aprime * (-np.exp(-t_psc/tau_1) + np.exp((-t_psc/tau_2))) * int(2*int(p.upward)-1)
        # Weiner filter deconvolution
        data=self.corrected.pA
        H = np.fft.fft(self.template[:data.shape[0]])
        self.convolved = np.real(np.fft.ifft(np.fft.fft(data)*np.conj(H)/(H*np.conj(H) + p.llambda**2)))
        ## tested high pass filter on convolution, but It'sactually a very bad Idea
        ## maybe substracting the low pass filtered trace?
        #b, a = scipy.signal.butter(3, 0.05, 'highpass')
        #self.quot = scipy.signal.filtfilt(b, a, self.quot)
        self.parent.cursors[0].setpos(2*np.std(self.convolved))
        self.fftthr=2*np.std(self.convolved)
        self.draw(drawall=True)
        self._fig().canvas.draw()

    def fftextract(self,p):
        self.thresholded=np.clip(self.convolved,self.fftthr,None)
        onsets = sc.signal.argrelextrema(self.thresholded, np.greater, order=p.order)[0] - 1
        data=self.corrected.pA
        self.events=[]
        self.bursts=[]
        self.filtered_events=[]
        for i in range(len(onsets)):
            n=onsets[i+1] if i<len(onsets)-1 else None
            self.events.append(pscevt(data,self.sr,onsets[i],n))
        self.filterevents(p)

    def filterevents(self,p):
        self.filtered_events=[evt for evt in self.events if evt.peakamplitude>p.filter_min_ampl and\
                                                            evt.peakamplitude<p.filter_max_ampl and\
                                                            evt.peakvalue>p.filter_min_peak
                                ]
        #if p.filter_max_tc:
        #    self.filtered_events=[evt for evt in self.filtered_events if evt.fitter and \
        #                                                                evt.fitter.success and \
        #                                                                0<evt.fitter.wtc<p.filter_max_tc]
        self.bursts=[]
        ## as we removed some events, we need to recompute offsets and inter-event intervals!
        maxT=int(25e-3*self.sr)
        for i in range(len(self.filtered_events)):
            onset=self.filtered_events[i].onset
            n=self.filtered_events[i+1].onset if i<(len(self.filtered_events)-1) else onset+maxT
            self.filtered_events[i].offset=min(onset+maxT,n,len(self.corrected)-1)
        for i in range(len(self.filtered_events[:-1])):
            self.filtered_events[i].nextevt=self.filtered_events[i+1].onset
            self.filtered_events[i].inter=self.filtered_events[i+1].onset-self.filtered_events[i].onset
        for e in self.filtered_events:
            e.isolated=e.offset>maxT
        self.averageevents(p)
        self.draw(drawall=False)
        self._fig().canvas.draw()

    def fitevents(self,p):
        maxT=int(25e-3*self.sr)
        lo,hi=self._axes(0).get_xlim()
        ## todo implement multiprocessing. fitting is very slow if some constraints are added to the fitter
        for evt in self.filtered_events:
            ## only fit event visible on screen
            if p.fit_visible and not lo<evt.peakposition/self.sr<hi:
                continue
            if (evt.offset-evt.peakposition)>int(maxT*0.9):
                y=self.corrected[evt.peakposition:evt.offset].pA.magnitude
                x=self.corrected[evt.peakposition:evt.offset].s.magnitude
                if p.fit_max_wtc:
                    bounds=((0,0,0,0,-1000),(np.inf,p.fit_max_wtc,np.inf,p.fit_max_wtc,1000))
                else:
                    bounds=None
                evt.fitter=XYFitter(x,y,2,True,bounds=bounds)
                if evt.fitter.success:
                    evt.fitter.wtc*=pq.s
                    evt.fitline=neo.AnalogSignal(evt.fitter.line(x)*pq.pA,sampling_rate=self.current.sampling_rate, t_start=x[0]*pq.s)
        self.draw(drawall=False)
        self._fig().canvas.draw()

    def extractbursts(self,p):
        firstT=p.burst_first_t
        maxT=p.burst_max_t
        self.bursts=[]
        burst=[]
        for i,evt in enumerate(self.filtered_events[:-1]):
            burst.append(evt)
            nevt=self.filtered_events[i+1]
            if (len(burst)==1 and nevt.onset-evt.onset>firstT*self.sr) or \
                (len(burst)>1 and nevt.onset-evt.onset>maxT*self.sr): ## condition to stop burst
                ## need to start a new burst
                ## set isolated flag for all events in burst
                self.bursts.append(burst)
                burst=[]
        self.bursts.append(burst)
        ## burst revision
        revbursts=[]
        ## split bursts with too few events
        for b in self.bursts:
            if len(b)>=p.burst_min_count or len(b)==1:
                revbursts.append(b)
            else:
                for e in b:
                    revbursts.append([e])
                #revbursts.extend([[e] for e in b])
        self.bursts=revbursts
        '''
        ## split bursts with too short
        for b in self.bursts:
            if len(b)>1 and b[-1].offset-b[0].onset>p.burst_min_dur:
                revbursts.append(b)
            else:
                revbursts.extend([[e] for e in b])
        self.bursts=revbursts'''
        ## recompute isolated attrinute for each event
        for b in self.bursts:
            for e in b:
                e.isolated= len(b)==1
        ##recompute event average
        self.averageevents(p)
        #self._axes(0).cla() ## because plotting bursts generates a linecollection that will not be cleared!
        self.draw(drawall=False)
        self._fig().canvas.draw()    

    def averageevents(self,p):
        pre=int(p.avg_pre*self.sr)
        post=int(p.avg_post*self.sr)
        if p.avg_onset:
            if p.avg_norm :
                self.average=np.mean(np.array([_norm(self.corrected[evt.onset-pre:evt.onset+post].pA) for evt in self.filtered_events[:-1] if evt.isolated]),axis=0)
            else:
                self.average=np.mean(np.array([self.corrected[evt.onset-pre:evt.onset+post].pA for evt in self.filtered_events[:-1] if evt.isolated]),axis=0)
        else:
            if p.avg_norm :
                self.average=np.mean(np.array([_norm(self.corrected[evt.onset-pre:evt.onset+post].pA) for evt in self.filtered_events[:-1] if evt.isolated]),axis=0)
            else:
                self.average=np.mean(np.array([self.corrected[evt.onset-pre:evt.onset+post].pA for evt in self.filtered_events[:-1] if evt.isolated]),axis=0)
        self.average=neo.AnalogSignal(self.average,sampling_rate=self.corrected.sampling_rate, units=self.corrected.units)  
        ## todo introduce fitter
        peak=np.argmax(abs(self.average))
        y=self.average[peak:].pA.magnitude
        x=self.average[peak:].s.magnitude
        self.avgfitter=XYFitter(x,y,2,True)
        if self.avgfitter.success:
            self.avgfitter.wtc*=pq.s
            self.avgfitline=neo.AnalogSignal(self.avgfitter.line(x)*pq.pA,
                                        sampling_period=self.current.sampling_period,
                                        t_start=x[0]*pq.s)


    def keyevent(self,event):
        if not event.GetKeyCode() in [ord(x) for x in 'NP ']:
            return
        lo,hi=self._axes(0).get_xlim()
        midpoint=int((hi+lo)*0.5*self.sr)
        peaks=[evt.peakposition for evt in self.filtered_events]
        closest_idx=np.searchsorted(peaks,midpoint,side="left")
        _clamp(closest_idx,0,len(peaks)-2)
        if event.GetKeyCode()==ord('N'):
            self._axes(0).set_xlim(peaks[closest_idx+1]/self.sr-(hi-lo)/2,
                                   peaks[closest_idx+1]/self.sr+(hi-lo)/2)
        if event.GetKeyCode()==ord('P'):
            self._axes(0).set_xlim(peaks[closest_idx-1]/self.sr-(hi-lo)/2,
                                   peaks[closest_idx-1]/self.sr+(hi-lo)/2)
        if event.GetKeyCode()==ord(' '):
            self.filtered_events.pop(closest_idx)
        self.draw(drawall=False)
        self._fig().canvas.draw()

    def process(self,bitmask=0xFFFF):
        ## process is automatically called at frame creation
        pass

    @once
    def setup(self):
        #self._fig().subplots(2, 1, gridspec_kw={'height_ratios': [2, 1],"top":0.9},sharex = True)
        mosaic='''
        AAAA
        BBBB
        CDEF
        '''
        self._fig().subplot_mosaic(mosaic)
        self._axes(0).sharex(self._axes(1))
        self._cursor(self._axes(1),'h',0,
                    lambda x:self.parent.currentframe().__setattr__("fftthr",x) or \
                            self.parent.draw (False))
        #self._cursor(self._axes(0),'h',cfg.TC_FIT_STOP,
        #            lambda x:cfg.set('TC_FIT_STOP',x) or self.parent.process(0xFFFF) or self.parent.draw (False))
        ## for some unknown reason, binding the key handler using mpl_connect results in a massive slowdown of the whole program
        ## we therefore bind it through standard wx.Bind()
        self._fig().canvas.Bind(wx.EVT_KEY_DOWN,self.keyevent)
        #self._fig().canvas.mpl_connect('key_press_event', self.keyevent)

    def draw(self,drawall=True):
        mplstyle.use('fast')
        self.setup() ## ensure that axes are ready!
        self._fig().canvas.set_window_title("Synaptic analysis protocol")
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            self.trace=self._axes(0).plot(self.corrected.s, self.corrected.pA,linewidth=0.5,color='blue',gid='traces')[0]
            self._axes(1).plot(self.corrected.s,self.convolved,linewidth=0.5,color='blue',gid='traces')
            _autoscale(self._axes(0),self.current.s,self.corrected.pA)
            _autoscale(self._axes(1),self.current.s,self.convolved)
        
        self._clf(['markers'])
        ## plot event onsets
        onsets=[evt.onset for evt in self.filtered_events]
        self._axes(0).plot( np.array(onsets)/self.sr, 
                            self.corrected.pA[onsets],
                            '^',color='green',gid='markers')
        ## plot event peaks
        peaks=[evt.peakposition for evt in self.filtered_events]
        self._axes(0).plot( np.array(peaks)/self.sr, 
                            self.corrected.pA[peaks],
                            'x',color='red',gid='markers')
        ##plot event offsets
        offsets=[evt.offset for evt in self.filtered_events]
        self._axes(0).plot( np.array(offsets)/self.sr, 
                            self.corrected.pA[offsets],
                            'v',color='orange',gid='markers')
        ## plot fitted decays
        for evt in self.filtered_events:
            if evt.fitter and evt.fitter.success:
                self._axes(0).plot(evt.fitline.s,evt.fitline.pA,color='black',gid='markers')
        ## plot bursts
        if any([len(b)>1 for b in self.bursts]):
            bursts=[b for b in self.bursts if len(b)>1]
            self._axes(0).hlines( [np.min(self.corrected.pA)]*len(bursts),
                    [b[0].onset/self.sr for b in bursts],
                    [b[-1].offset/self.sr for b in bursts],
                    color='orange',gid='markers')
        ## plot averaged event
        if len(self.average):     
            self._axes(2).plot(self.average.s,self.average.pA,color='blue',gid='markers')
            if self.avgfitter.success:
                self._axes(2).plot(self.avgfitline.s,self.avgfitline.pA,color='red',gid='markers')
            _autoscale(self._axes(2),self.average.s,self.average.pA)
        
        # plot histogram
        self._axes(3).hist([float(e.fitter.wtc) for e in self.filtered_events if e.fitter and e.fitter.success],
                            bins=100, color='blue',gid='markers')
        self._axes(3).autoscale()
        #plot cumulative
        cumul=np.sort(np.array([evt.inter for evt in self.filtered_events if evt.inter]))
        self._axes(4).plot(cumul,np. linspace(0,1,len(cumul)),color='blue',gid='markers')

class PSCProtocol(BaseProtocol):
    def __init__(self,sigs,cmds,interactive,fig=None):
        self.frames=[PSCFrame(s,idx=e,parent=self) for e,s in enumerate(sigs) ]
        super(PSCProtocol,self).__init__(interactive,fig)

    @classmethod
    def fromexp(cls,exp):
        current=exp.signal(0)
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            pass ## nothing to parse here
        return cls(current,[0],True,None)

    def provides(self):
        return {}

    def results(self):
        ## np.mean return nan for empty lists
        self.r= {}
        return self.r

    ## msgwrap event dispatcher
    def dispatch(self,evt):
        key=evt.GetKey()
        value=evt.GetValue()
        p=evt.EventObject
        wait_crsr = wx.BusyCursor()
        if key in ['prefilter_btn']:
            self.currentframe().prefilter(p)
        elif key in ['fft_deconvolve_btn']:
            self.currentframe().fftdeconvolve(p)
        elif key in ['fft_extract_btn']:
            self.currentframe().fftextract(p)
        elif key in ['fit_btn']:
            self.currentframe().fitevents(p)
        elif key in ['extract_btn']:
            self.currentframe().extractevents(p)
        elif key in ['burst_btn']:
            self.currentframe().extractbursts(p)
        elif key.startswith('filter_') or key.startswith('avg_'): ## filter will call avg
            self.currentframe().filterevents(p)
        del wait_crsr

    def params(self):
        return [
            [None,'foldable','Filters',None,None,'str','This tooltip should never be displayed.'],
            ['convolve_duration','spinner','Baseline average (s)',"0|10|0.5",1.0,'float','Sets the time window for baseline removal.'],
            ['notch_frequency','combo','Notch frequency (Hz)','0|50|60','0','int','Controls the frequency of Notch filter. Use 0 to skip filter'],
            ['rectify_policy','combo','Rectification','keep|negate|abs','negate','str','How to rectify the data (peaks must be upward).'],
            ['smoothing','spinner','Smoothing (pts)',"0|10|1",1,'int','Convolution for signal smoothing.'],
            ['prefilter_btn','button',' ',None,'Filter!','str','Start event extraction'],
            [None,'fend'],
            [None,'foldable','Deconvolution',None,None,'str','This tooltip should never be displayed.'],
            #['save_template','file','Save template','',str(pathlib.Path(__file__).resolve()),'str','Saves current time range as template epsc for later correlation.'],
            ['rise_ms','spinner','Rise time (ms)',"0|15.0|0.5",1.0,'float','Time constant for rising edge. usually 0.5-2.0.'],
            ['decay_ms','spinner','Decay time (ms)',"0|50.0|0.5",4.0,'float','Time constant for falling edge. usually 4.0-10.0.'],
            ['llambda','spinner','llambda',"0|10|0.5",5.0,'float','llambda.'],
            ['order','spinner','Order',"1|20|1",7,'int','order.'],
            ['upward','check','Upward events',None,True,'bool','Upward (True) or Downward (False) events'],
            ['fft_deconvolve_btn','button',' ',None,'Deconvolve!','str','Performs signal deconvolution'],
            ['fft_extract_btn','button',' ',None,'Extract!','str','Extract events'],
            [None,'fend'],
            [None,'foldable','Event Filtering',None,None,'str','This tooltip should never be displayed.'],
            ['filter_min_ampl','spinner','Minimal amplitude',"0|2000|0.5",5.0,'float','minimum event amplitude.'],
            ['filter_max_ampl','spinner','Maximal amplitude',"0|2000|5",2000,'float','maximal event amplitude.'],
            ['filter_min_peak','spinner','Minimal peak value',"0|2000|1.0",10.0,'float','minimum event peak (above baseline).'],
            [None,'fend'],
            [None,'foldable','Event Fitting',None,None,'str','This tooltip should never be displayed.'],
            ['fit_max_wtc','spinner','Maximal time constant (s)',"0.000|0.100|0.001",0.05,'float','maximal decay time constant use 0 to disable.'],
            ['fit_visible','check','Visible events only',None,False,'bool','Only fit events in current time range'],
            ['fit_btn','button',' ',None,'Fit!','str','Attempts to fit exponential on some events'],
            [None,'fend'],
            [None,'foldable','Burst grouping',None,None,'str','This tooltip should never be displayed.'],
            ['burst_first_t','spinner','First T (s)',"0.000|1e4|0.100",0.060,'float','maximum delay between the two first spikes of a burst.'],
            ['burst_max_t','spinner','Max T (s)',"0.000|1e4|0.100",0.040,'float','maximum delay two spikes in a burst.'],
            #['burst_min_dur','spinner','Minimal duration (s)',"0.000|1e4|0.100",0.020,'float','Minimal burst duration.'],
            #['burst_min_int','spinner','Minimal interval (s)',"0.000|1e4|0.100",0.200,'float','Minimal delay between two bursts.'],
            ['burst_min_count','spinner','Minimal count',"0|1e4|1",2,'float','Minimal number of events in Burst.'],
            ['burst_btn','button',' ',None,'Make bursts!','str','Computes bursts'],
            [None,'fend'],
            [None,'foldable','Average',None,None,'str','This tooltip should never be displayed.'],
            ['avg_norm','check','Normalize before average',None,True,'bool','normalize events before averaging'],
            ['avg_onset','check','Use onset for origin',None,True,'bool','Synchronize events relative to their onset (other wise peak)'],
            ['avg_pre','spinner','Time before (s)',"0.000|0.100|0.001",0.002,'float','Time to keep before event onset.'],
            ['avg_post','spinner','Time after (s)',"0|0.100|0.001",0.01,'float','Time to keep after event onset.'],
            [None,'fend'],
        ]

    def provides(self):
        r={
            "SYN_evt_ampl":"Average xPSC amplitude",
            "SYN_evt_peak":"average xPSC peak",
            "SYN_evt_inter":"average instantaneous inteval (s)",
            "SYN_evt_wtc":"average of individual time constants. more or less meaningless",
            "SYN_evt_overallfreq":"overall event frequency",
            "SYN_avgpsc_wtc":"time constant of averaged psc",
            "SYN_evt_fano":"fano factor",
            "SYN_burst2psc_ratio":"ratio between events in bursts and total pscs",
            "SYN_burst_content":"average number of psc /burst",
            "SYN_burst_inter":"average burst interval",
            "SYN_burst_dura":"average burst duration(between onset peaks of 1st and last)",
            "SYN_burst_overallfreq":"average burst interval"
        }

    def results(self):
        ##
        fr=self.frames[0]
        r={}
        r["SYN_evt_ampl"]=_pq_mean([evt.peakamplitude for evt in fr.filtered_events])
        r["SYN_evt_peak"]=_pq_mean([evt.peakvalue for evt in fr.filtered_events])
        r["SYN_evt_inter"]=_pq_mean([evt.inter/fr.sr for evt in fr.filtered_events]).rescale(s) ##np.mean(np.ediff1d([evt.peakposition...]))
        r["SYN_evt_wtc"]=_pq_mean([evt.fitter.wtc for evt in fr.filtered_events if evt.fitter and evt.fitter.success])
        r["SYN_evt_overallfreq"]=(len(fr.filtered_events)/fr.current.s[-1]).rescale(pq.Hz)
        r["SYN_avgpsc_wtc"]=fr.avgfitter.wtc if fr.avgfitter and fr.avgfitter.success else np.nan * pq.s
        r["SYN_evt_fano"]:np.std([evt.inter/fr.sr for evt in fr.filtered_events])/np.mean([evt.inter/fr.sr for evt in fr.filtered_events])
        burstevts=[e for b in fr.bursts for e in b if len(b)>1]
        r["SYN_burst2psc_ratio"]=len(burstevts)/len(fr.filtered_events)
        r["SYN_burst_content"]=np.mean([len(b)for b in fr.bursts])
        r["SYN_burst_dura"]=_pq_mean([   ((b[-1].onset -b[0].onset) / fr.sr).rescale(s) for b in fr.bursts])
        r["SYN_burst_inter"]:_pq_mean([(fr.bursts[e+1][-1].onset - b[-1].onset)/fr.sr for e,b in enumerate(fr.bursts[:-1])]).rescale(s)
        r["SYN_burst_overallfreq"]=(len(fr.bursts)/fr.current.s[-1]).rescale(pq.Hz)
        return r