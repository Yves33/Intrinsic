#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import sys
sys.path.insert(0,"./modules")
from pathlib import Path

## data science stack
from config import cfg
import logging
import numpy as np
import scipy as sc
import quantities as pq
from quantities import uV,mV,V
from quantities import pA,nA,uA,mA,A
from quantities import ns,us,ms,s

import neo
from xyfitter import XYFitter
from baseprotocol import once,BaseFrame,BaseProtocol

from utils import _autoscale,_clamp, _norm, _pq_mean, _pq_max, _pq_nearest,_pq_value,_pq_unit
from pro_iv import IVFrame,Spike

class SpontaneousActivityProtocol(BaseProtocol):
    def __init__(self,sigs,cmds,interactive,fig=None):
        ## awfull hack here:
        ## ivframe calculates baseline for  AHP between cfg.IV_CURRENT_INJECTION_START and cfg.IV_CURRENT_INJECTION_STOP
        ## as we want to take baseline for all trace, we save these values for later restoration, and update the values...
        ## may not be necessary as params are reparsed before every protocol analysis...
        cfg.IV_CURRENT_INJECTION_START, cfg.IV_CURRENT_INJECTION_STOP=0*pq.s, sigs[0].times[-1]
        self.frames=[IVFrame(s,cmds[e],idx=0,parent=self) for e,s in enumerate(sigs) ]
        super(SpontaneousActivityProtocol,self).__init__(interactive,fig=fig)
    
    @classmethod
    def fromexp(cls,exp):
        voltage=exp.signal(0)
        return cls(voltage,[0*pq.pA],True,None)

    def provides(self):
        return {'SPON_baseline':'average baseline.',
                'SPON_frequency':'average frequency.',
                'SPON_avg_spike_threshold':'spike threshold.',
                'SPON_avg_spike_peak':'spike peak.',
                'SPON_avg_spike_amplitude':'spike amplitude (=peak-threshold).',
                'SPON_avg_spike_half_width':'spike half width (at (peak-threshold)/2).',
                'SPON_avg_spike_max_rise_slope':'spike maximum rise slope.',
                'SPON_avg_spike_max_fall_slope':'spike maximum fall slope.',
                'SPON_avg_spike_ahp':'spike ahp.',
                'SPON_fano':'fano factor',
                }

    def results(self):
        self.r={}
        self.r['SPON_baseline']=self.frames[0].ahpbaseline.rescale(cfg.OUTPUT_V_UNIT)
        self.r['SPON_frequency']=(len(self.frames[0].spikes)/(cfg.IV_CURRENT_INJECTION_STOP - cfg.IV_CURRENT_INJECTION_START)).rescale(pq.Hz)
        if len(self.frames[0].spikes)>0:
            self.r['SPON_avg_spike_threshold']=_pq_mean([s.threshold for s in self.frames[0].spikes]).rescale(cfg.OUTPUT_V_UNIT)
            self.r['SPON_avg_spike_peak']=_pq_mean([s.peak for s in self.frames[0].spikes]).rescale(cfg.OUTPUT_V_UNIT)
            self.r['SPON_avg_spike_amplitude']=_pq_mean([s.amplitude for s in self.frames[0].spikes]).rescale(cfg.OUTPUT_V_UNIT)
            self.r['SPON_avg_spike_half_width']=_pq_mean([s.halfwidth for s in self.frames[0].spikes]).rescale(cfg.OUTPUT_S_UNIT)
            self.r['SPON_avg_spike_max_rise_slope']=_pq_mean([s.maxrise for s in self.frames[0].spikes]).rescale(cfg.OUTPUT_V_UNIT/cfg.OUTPUT_S_UNIT)
            self.r['SPON_avg_spike_max_fall_slope']=_pq_mean([s.maxfall for s in self.frames[0].spikes]).rescale(cfg.OUTPUT_V_UNIT/cfg.OUTPUT_S_UNIT)
            self.r['SPON_avg_spike_ahp']=_pq_mean([s.ahp for s in self.frames[0].spikes if s.complete]).rescale(cfg.OUTPUT_V_UNIT)
            self.r['SPON_fano']=self.frames[0].fano
        return self.r
    