#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is pat of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

## Python stdlib import. Can't live without it
import os,sys,logging,fnmatch,re,time
sys.path.insert(0,"./modules")
from pathlib import Path

import warnings
warnings.filterwarnings('ignore')
warnings.warn = lambda *args,**kwargs:0   ## shut down matplotlib deprecation warnings

## data science stack
import numpy as np
import pandas as pd
import quantities as pq
import neo
import neomonkey
neomonkey.installmonkey()               ## use our custom array access routines

from config import cfg
cfg.parse("./params/default_params.py")
gen_cfg_files=list(Path("./params/").glob("generic_params_*.py"))
if len(gen_cfg_files)!=1:
    logging.getLogger('myapp').critical("More than one generic config file was found!")
    exit(-1)
gen_cfg_file=str(gen_cfg_files[0])
logging.getLogger('myapp').critical(f"Current parameter file {gen_cfg_file}")
if os.path.isfile(gen_cfg_file):
	cfg.parse(gen_cfg_file)

import matplotlib
#plt.rcParams['lines.antialiased']=True
#plt.rcParams['lines.linewidth']=1.0

from experiment import Experiment

## default config file in case we lose the original one
basecfg='''
## parameters for IV curve analysis. Units are Volts and seconds
#########################################################################
## THESE PARAMETERS OVERWRITE DEFAULT PROGRAM VALUES.
#########################################################################
##

ITSQ_VERSION=3.99                                       ## the version of intrinsic that match this param file. No version check is performed, but that may change in a near future
ITSQ_LOG_LEVEL=10                                       ## log level DEBUG=10 INFO=20 WARNING=30,ERROR=40 CRITICAL=50
ITSQ_PANZOOM_WHEEL_ONLY=True                            ## should be True
ITSQ_FIT_ITERATION_COUNT=10000                          ## maximum number of iterations for curve fitting 250-10000
ITSQ_FITTER_VERSION=1                                   ## 1 or 2. 2 sometimes gives weird results
ITSQ_OUTPUT_FIELDS_FILE="./params/outfields.txt"        ## list of parameters that the program should output. automatically regenerated if absent. set to False to ignore filtering
ITSQ_SKIP_FILES=['.','_']                               ## skip files starting with one of these characters
ITSQ_ENABLE_MULTIPROCESSING=True                        ## enable parallel processing for spontaneous and iv. Not a major improvement! May not work on some platforms (win, osx)
ITSQ_PROTOCOL_SAVE_DATA=True                            ## save analysis data for each protocol. not tested on OSX. WIP
ITSQ_PARSE_PROTOCOLS=True                               ## parse protocols for current pulses (only). not heavily tested experimental. works with IV, resistance and mb time constant
ITSQ_MPL_BACKEND=None                                   ## force matplotlib backend None (auto) or one of 'GTK3Agg', 'MacOSX', 'Qt4Agg', 'Qt5Agg', 'TkAgg', 'WXAgg'; using WXAgg saves resources, but may conflict with internal app event loop
ITSQ_ENABLE_HOOKS=True                                  ## guess if current steps are nA or pA and convert to pA. No guarantee! some other hooks may be implemented later
#
EPSILON=0.001                                           ## slight offset between and current injection offsets and offsets for measurement. currently unused

## parameters for IV curve analysis
IV_CURRENT_INJECTION_START=0.1                          ## current injection start time. ususally 0.1 or 0.2      
IV_CURRENT_INJECTION_STOP=0.9                           ## current injection stop time ususally 0.9 or 1., or @IV_CURRENT_INJECTION_START+1.0
IV_BASELINE_START=0.0                                   ## baseline measurement start usually 0
IV_BASELINE_STOP=@IV_CURRENT_INJECTION_START-0.01       ## baseline measurement stop
IV_SAG_PEAK_START=@IV_CURRENT_INJECTION_START+0.01      ## start of sag peak measurement region
IV_SAG_PEAK_STOP=@IV_CURRENT_INJECTION_START+0.20       ## end of sag peak measurement region
IV_SAG_SS_START=@IV_CURRENT_INJECTION_STOP-0.3          ## start of sag stead ystate measurement region
IV_SAG_SS_STOP=@IV_CURRENT_INJECTION_STOP-0.01          ## end of sag stead ystate measurement region
IV_SAG_SS_TARGET_VOLTAGE=0.015                          ## sagratio will be measured for the frame for which sag steady state is the closest of this value (in V)
IV_SAG_TARGET_CURRENT=-90                               ## sagratio for injected current value
IV_TCFIT=True                                           ## calculate mb time constant in IV curve
IV_TCFIT_START=@IV_CURRENT_INJECTION_START+0.00025      ## where to start the membrane time constant fit
IV_TCFIT_STOP=@IV_CURRENT_INJECTION_START+0.2           ## where to stop the membrane time constant fit. if -1, will use sag peak time
IV_TCFIT_AUTOSTOP=True                                  ## automatically guess the end of the fit period (at first analyse)
IV_TCFIT_ORDER=2                                        ## fit with single (1) or double (2) exponential
IV_TCFIT_WEIGHTED_AVERAGE=True                          ## compute weighted average instead of arithmetic average
IV_TCFIT_THRESHOLD=-25                                  ## don't fit frames when injected current is less than
IV_TCFIT_R2_THRESHOLD=0.80                              ## don't accept fits with r2 coeff lower than this value (ignored)
IV_CURRENT_STEPS=list(range(-95,100,5))                 ## list of current steps applied during IV protocol
IV_SPIKE_MIN_PEAK=-0.01                                 ## absolute spike peak votage! spikes that do not cross this threshold will be ignored!
IV_SPIKE_MIN_AMP=0.020                                  ## spike amplitude. more or less the minimum voltage variation betwen threshold and peak
IV_SPIKE_MIN_INTER=0.005                                ## minimum interval between two spikes
IV_SPIKE_PRE_TIME=0.005                                 ## time to keep before spike peak for threshold and maxrise measurement; 0.0015 is ususally enough
IV_SPIKE_POST_TIME=0.01                                 ## time to keep after spike peak for halfwidth measurement;0.005 may be required for correct phase plane analysis
IV_SPIKE_DV_THRESHOLD=0.0002                            ## threshold for first derivative, in case first threshold failed, in V/s. 10 is a good value
IV_SPIKE_LOWEST_THRESHOLD=True                          ## determines two thresholds, based on first and second derivative,and take lowest (otherwise the second threshold is used if threshold detection with 2nd derivative failed )
IV_SPIKE_EVOKED_THRESHOLD=0                             ## for a spike to be considered as evoked, current must be >= to this value. use 0.000001 to eliminate spontaneous spikes
IV_MIN_SPIKES_FOR_MEASURE=1                             ## minimum number of spikes in a frame to measure the threshold,maxrise, ...
IV_MAX_SPIKES_FOR_MEASURE=2000                          ## maximum number of spikes in a frame to measure the thresholds,maxrise, ...
IV_MIN_SPIKES_FOR_SFADAPT=4                             ## number of spikes required to compute spike frequency adaptation
IV_DEBUG_FRAME=True                                     ## display each iv frame

## parameters for AHP analysis
AHP_SS_START=0.0                                        ## start of baseline region for AHP measurement
AHP_SS_STOP=0.05                                        ## end of basline region for AHP measurements 
AHP_SPIKE_MIN_PEAK=0.1                                  ## absolute peak voltage for peak detection
AHP_SPIKE_MIN_AMP=0.050                                 ## minimal amplitude of peak for detection 
AHP_SPIKE_AUTO=True                                     ## determine automagically parameters for peak detection
AHP_MIN_SPIKE_COUNT=3                                   ## minimal number of spikes to count before rejecting a file. if n_spikes<AHP_MIN_SPIKES_COUNT then reject
AHP_MAX_DELAY=0.5                                       ## maximal delay after last identified spike to measure AHP  
AHP_TIME_WINDOW_AVERAGE=0.0002                          ## width (in s) of the window surrounding maximum negative deflection after  last spike
AHP_CHECK_SPIKE_COUNT=False                             ## check wether AHP files should have 5 or 15 APs. otherwise just take the first and last spikes to define baseline and AHP measurement regions. This parameter should be True
AHP_CHECK_SPIKE_FREQ=False                              ## reject frame if computed frequency does not match
AHP_CHECK_NONE=False                                    ## do not check anything. just measure. overwrites AHP_CHECK_SPIKE_COUNT and AHP_CHECK_SPIKE_FREQ
AHP_SPIKE_START=0.1                                     ## onset of first spike. used only if AHP_CHECK_NONE is set
AHP_NEAREST_FREQUENCY=True                              ## clamp the computed frequency to the nearest frequency. usefull for 200Hz frequency, but can be dangerous           
AHP_DEBUG_FRAME=True                                    ## display ahp frame
AHP_VALID_COMBO=[(5,10)]                                ## used to generate the list of AHP output fields

## parameters for mb time constant analysis
TC_FIT_START=0.0510                                     ## start of fit region for mb time constant.
TC_FIT_STOP=@TC_FIT_START+0.04                          ## end of fit region for mb time constant
TC_FIT_CURRENT_STEPS=[-400,-400,-400,400,400,400]       ## injected current. currently not used, but the program expects to find this value with correct number of traces
TC_FIT_ORDER=2                                          ## fit with simple, double or triple exponential (1,2,3)
TC_WEIGHTED_AVERAGE=True                                ## take the weighted average of the two time constants, otherwise arithmetic average             
TC_DEBUG_FRAME=True                                     ## display tc frame

## parameters for résonnance analysis
RES_LOW_BAND=0.01                                       ## start of band pass
RES_HIGH_BAND=10                                        ## end of band pass
RES_AMPLITUDES=[30,50]                                  ## list of allowed amplitudes for resonnance protococols
RES_DEBUG_FRAME=True                                    ## display resonnance frame

## parameters for resistance analysis
INPUTR_CURRENT_INJECTION_START=0.2                      ## start of current injection (seconds)
INPUTR_CURRENT_INJECTION_STOP=0.7                       ## end of current injection (seconds)
INPUTR_CURRENT_STEP=-20                                 ## current step amplitude (pA)
INPUTR_TCFIT_START=@INPUTR_CURRENT_INJECTION_START+0.01 ## start of exponential fit
INPUTR_TCFIT_STOP=@INPUTR_CURRENT_INJECTION_STOP-0.01   ## end of exponential fit             
INPUTR_TCFIT_ORDER=2                                    ## fitting order for exp
INPUTR_TCFIT_WEIGHTED_AVERAGE=True                      ## take the weighted average of the two time constants, otherwise arithmetic average
INPUTR_DEBUG_FRAME=True                                 ## display averaged frames

## parameters for spontaneous activity (current clamp. spikes)
SPONTANEOUS_DEBUG_FRAME=True                            ## display spontaneous activity frame

## parameters for ramp
RAMP_BOUNDARIES=[0.13,1.13,1.21,2.21]                   ## the regions for Ramp
RAMP_DEBUG_FRAME=True                                   ## display ramp frames

## parameters for rheobase
RHEO_CURRENT_INJECTION_START=0.20775
RHEO_CURRENT_INJECTION_STOP=0.25775
RHEO_CURRENT_STEP=5
RHEO_BASELINE_START=0.0
RHEO_BASELINE_STOP=0.2
RHEO_DEBUG_FRAME=True

## parameters for SAG protocol
SAG_AVERAGE_COUNT=3
SAG_CURRENT_STEPS=[-200,-180,-160,-140,-120,-100,-80,-60,-40,-20,0]
SAG_CURRENT_INJECTION_START=0.1
SAG_CURRENT_INJECTION_STOP=0.9
SAG_DEBUG_FRAME=True


## parameters for folder naming
##FOLDER_NAMING_SCHEME='WTC1  -V2.1-12w-A1     -DIV21 -2022.03.01-Cell1
FOLDER_NAMING_SCHEME='date_cell'                        ## sceme for folder naming
FOLDER_NAMING_SEP='_'                                   ## separator for fields in folder name

## process flags
#PROCESS_PROTOCOLS=['FolderName','IV','TC','Sag','InputRes','Resonnance','SpontaneousActivity','AHP','Ramp','Rheobase']
PROCESS_PROTOCOLS=['FolderName','IV','TC','Sag','InputRes','Resonnance','SpontaneousActivity','AHP','Ramp','Rheobase']
PROCESS_EXTENSIONS=['.axgd','.axgx','.abf','.maty']

## output parameters for csv,excel,json
OUTPUT_CSVSEP="\t"                                      ## the separator for fields, ususally comma (',') for csv or tab ('\t') for tsv
OUTPUT_CSV=True
OUTPUT_JSON=True
OUTPUT_EXCEL=True
OUTPUT_CLIPBOARD=True                                   ## output should also be pasted to clipboard
OUTPUT_CLIPBOARD_EXCEL=True                             ## clipboard should be formatted for excel
OUTPUT_CLIPBOARD_ROWNAMES=False                         ## clipboard should include row names

## scale factors. SI values are **divided** by these values
## The program caculates everything SI (V,A,s,Ohm,F)
OUTPUT_V_SCALE=1e-3                  ## use 1e-3 to convert V to mV          (0,003V             -> 3mV)
OUTPUT_OHM_SCALE=1e6                 ## use 1e6 to convert Ohms to MOhms     (450,235,123.00Ohms -> 450,23Mohms)
OUTPUT_S_SCALE=1e-3                  ## use 1e-3 to convert s to ms          (0.1s               -> 100ms)
OUTPUT_A_SCALE=1e-12                 ## use 1e-12 to convert A to pA         (0.000 000 000 153A -> 153pA)
OUTPUT_F_SCALE=1e-12                 ## use 1e-12 to convert F to pF         (0.000 000 000 256F -> 256pA)

## protocol names
## much fun here: different names for the "not so" different protocols with strictly identical analysis, depending on the setups...
## for analysis, provide a list of all protocol names that should match a given analysis
## each value is tested as an fnmatch string (? stands for any caracter, * for any suite of caracters, [Tt] any character in group)
IV_PROTOCOL_NAMES=['IV_multiclamp','3-IV curve','*IV*',]
AHP_PROTOCOL_NAMES=['*5AP*','*AHP*',]
TC_PROTOCOL_NAMES=['*constant*',]
ZAP_PROTOCOL_NAMES=['*ZAP*', 'resonnance']
INPUTR_PROTOCOL_NAMES=['*resistance*']
SPONTANEOUS_PROTOCOL_NAMES=['*[Ss]pontaneous*']
RAMP_PROTOCOL_NAMES=['*[Rr]amp*']
RHEO_PROTOCOL_NAMES=['*rheo*']
SAG_PROTOCOL_NAMES=['*[Ss]ag_*']
'''

## some other globals
filecount=0	             ## nummber of files that were processed
##################################################################################################
##################################################################################################
## PROTOCOLS ARE NOW IN SEPARATE FILES
from pro_timeconstant import TimeConstantProtocol
from pro_sag import SagProtocol
from pro_inputres import InputResProtocol
from pro_resonnance import ResonnanceProtocol
from pro_ramp import RampProtocol
from pro_ahp import AHPProtocol
from pro_foldername import FolderNameProtocol
from pro_iv import IVProtocol
from pro_spontaneousactivity import SpontaneousActivityProtocol
from pro_rheobase import RheobaseProtocol
from utils import _clamp

##################################################################################################
##################################################################################################
##################################################################################################
## PREPROCESS AND DISPATCH FILES
##################################################################################################
##################################################################################################
##################################################################################################

def process_file(inpath):
    cfg.parse(Path(__file__).resolve().parent/gen_cfg_file)
    neuronprops={}
    protocol=None
    if str(Path(inpath).name)[0] in cfg.ITSQ_SKIP_FILES:
        logging.getLogger('myapp').info(f"Skipping file {str(inpath)}")
        return {}
    myexp=Experiment(inpath)
    protocolname=myexp.protocol.name
    logging.getLogger('myapp').info(f"{protocolname} : {str(inpath)}")

    ##
    ## processing sag protocol
    if any([fnmatch.fnmatch(protocolname,x) for x in cfg.SAG_PROTOCOL_NAMES])  and 'Sag' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        '''sigs=myexp.signal(0)
        ## for sag, average signals by groups of 3
        from neomonkey import average
        cnt=cfg.SAG_AVERAGE_COUNT
        avgsig=[average(sigs[cnt*i],sigs[cnt*i+1],sigs[cnt*i+2]) for i in range(len(sigs)//cnt) ]
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            cfg.SAG_CURRENT_INJECTION_START=myexp.protocol.ascurrentsteps()['steps'][0]['start']
            cfg.SAG_CURRENT_INJECTION_STOP=myexp.protocol.ascurrentsteps()['steps'][0]['stop']
            cfg.SAG_CURRENT_STEPS=[step['lvl'] for step in myexp.protocol.ascurrentsteps()['steps'] ]
            cfg.SAG_CURRENT_STEPS=sorted(list(set(cfg.SAG_CURRENT_STEPS)))
            HOOK_ADJUST_STEP_HEIGHT()
        dlg=PlotDialog(None,size=(800,600) )
        protocol=SagProtocol(avgsig,
                                cmds=cfg.SAG_CURRENT_STEPS,
                                interactive=cfg.SAG_DEBUG_FRAME,
                                fig=dlg.fig)'''
        protocol=SagProtocol.fromexp(myexp)
        dlg.ShowModal()
        dlg.Destroy()
        neuronprops.update(protocol.results())
    
    ##
    ## processing Time Constant protocol
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.TC_PROTOCOL_NAMES])  and 'TimeConstant' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            cfg.TC_FIT_START=myexp.protocol.ascurrentsteps()['steps'][0]['stop']+0.001
            cfg.TC_FIT_CURRENT_STEPS=[s['lvl'] for s in myexp.protocol.ascurrentsteps()['steps'] ]
        dlg=PlotDialog(None,size=(800,600) )
        protocol=TimeConstantProtocol(sigs,
                                cmds=cfg.TC_FIT_CURRENT_STEPS,
                                interactive=cfg.TC_DEBUG_FRAME,
                                fig=dlg.fig)
        dlg.ShowModal()
        dlg.Destroy()
        neuronprops.update(protocol.results())

    ##
    ## processing Input Resistance protocol
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.INPUTR_PROTOCOL_NAMES])  and 'InputRes' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        ## for resistance, average signals
        #avgsig=neo.AnalogSignal( np.mean(np.array([s.magnitude.flatten() for s in sigs]),axis=0),
        #    units='V', 
        #    sampling_rate=sigs[0].sampling_rate
        #    )
        myexp.protocol.scaleoutput(channel=0,absrange=[-500*pq.pA,500*pq.pA])
        avgsig=neomonkey.average(sigs)
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            cfg.INPUTR_CURRENT_INJECTION_START=myexp.protocol.asepochs(0)[1][1]['start']
            cfg.INPUTR_CURRENT_INJECTION_STOP=myexp.protocol.asepochs(0)[1][1]['stop']
            cfg.INPUTR_CURRENT_STEP=myexp.protocol.asepochs(0)[1][1]['lvl']
        dlg=PlotDialog(None,size=(800,600) )
        protocol=InputResProtocol([avgsig],
                                    cmds=[cfg.INPUTR_CURRENT_STEP],
                                    interactive=cfg.INPUTR_DEBUG_FRAME,
                                    fig=dlg.fig)
        dlg.ShowModal()
        dlg.Destroy()
        neuronprops.update(protocol.results())

    ##
    ## processing Resonnance protocol
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.ZAP_PROTOCOL_NAMES]) and 'Resonnance' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        ## quite complex here! on some setups / protocols, the current is not recorded, so we have to load an external stimulus file!
        try:
            current=myexp.signal(1)
        except:
            ## too much variation in protol names here. force load current with exact same name as protocol 
            reffilepath=str(Path(__file__).resolve().parent/"resources"/protocolname)
            values=np.loadtxt(reffilepath+'.txt',delimiter='\t',skiprows=1,usecols=1)
            current=[neo.AnalogSignal(values, units=pq.A,sampling_rate=sigs[0].sampling_rate)]
        resonnance_error_string='''
        Your protocol does not include Current recording. 
        Moreover, the sampling/frequency/duration is not compatible with the stored protocol frequency/duration.
        Can't process that file unless you provide a valid protocol
        '''
        #assert(sigs[0].sampling_rate==current[0].sampling_rate)
        #assert(len(sigs[0])==len(current[0]))
        if len(sigs[0])!=len(current[0]):
            logging.getLogger('myapp').error(resonnance_error_string)
            return {}
        dlg=PlotDialog(None,size=(800,600) )
        protocol=ResonnanceProtocol([sigs[0]],
                                        cmds=[current[0]],
                                        interactive=cfg.RES_DEBUG_FRAME,
                                        fig=dlg.fig)
        dlg.ShowModal()
        dlg.Destroy()
        neuronprops.update(protocol.results())
        
    
    ##
    ## processing Ramp protocol
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.RAMP_PROTOCOL_NAMES])  and 'Ramp' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        voltage=myexp.signal(1)
        dlg=PlotDialog(None,size=(800,600) )
        protocol=RampProtocol(sigs,
                                cmds=voltage,
                                interactive=cfg.RAMP_DEBUG_FRAME,
                                fig=dlg.fig)
        dlg.ShowModal()
        dlg.Destroy()
        neuronprops.update(protocol.results())

    ##        
    ## processing AHP protocol 
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.AHP_PROTOCOL_NAMES])  and 'AHP' in cfg.PROCESS_PROTOCOLS :
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        ## read frequency from protocol name
        if cfg.AHP_CHECK_NONE:
            freqstr=re.search(r'\d*[H,h]z',protocolname,re.MULTILINE)
            #apstr=re.search(r'\d*AP',protocolname,re.MULTILINE)
            ## obviously the protocol ame is not consistent between 5AP procotols and 15 AP protocols. The following regexp should match both
            apstr=re.search(r'\d*A',protocolname,re.MULTILINE)
            if freqstr:
                freq=int(freqstr.group(0)[:-2])
                logging.getLogger('myapp').info(f"AHP Protocol indicates {freq}Hz")
            else:
                logging.getLogger('myapp').warning("Could not extract frequency from AHP protocol")
                freq=None
            if apstr:
                apcount=int(apstr.group(0)[:-1])
                logging.getLogger('myapp').info(f"AHP Protocol indicates {apcount} APs")
            else:
                logging.getLogger('myapp').warning("Could not extract number of APs from AHP protocol")
                apcount=None
        else:
            freq=None
            apcount=None
        ## AF version has one frame, whereas I have many frames... Just keep the last one
        dlg=PlotDialog(None,size=(800,600) )
        protocol=AHPProtocol([sigs[-1]],
                                cmds=[None],
                                interactive=cfg.AHP_DEBUG_FRAME,
                                fig=dlg.fig,
                                frequency=freq,
                                apcount=apcount)
        dlg.ShowModal()
        dlg.Destroy()
        neuronprops.update(protocol.results())

    ##
    ## processing IV protocol
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.IV_PROTOCOL_NAMES])  and 'IV' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            cfg.IV_CURRENT_INJECTION_START=myexp.protocol.ascurrentsteps()['steps'][0]['start']
            cfg.IV_CURRENT_INJECTION_STOP=myexp.protocol.ascurrentsteps()['steps'][0]['stop']
            cfg.IV_CURRENT_STEPS=[step['lvl'] for step in myexp.protocol.ascurrentsteps()['steps'] ]
            HOOK_ADJUST_STEP_HEIGHT()
        dlg=PlotDialog(None,size=(800,600) )
        protocol=IVProtocol(sigs,
                            cmds=cfg.IV_CURRENT_STEPS,
                            interactive=cfg.IV_DEBUG_FRAME,
                            fig=dlg.fig)
        dlg.ShowModal()
        dlg.Destroy()
        neuronprops.update(protocol.results())
    
    ##
    ## processing Spontaneous Activity protocol
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.SPONTANEOUS_PROTOCOL_NAMES])  and 'SpontaneousActivity' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        dlg=PlotDialog(None,size=(800,600) )
        protocol=SpontaneousActivityProtocol(sigs,
                                cmds=[0],
                                interactive=cfg.SPONTANEOUS_DEBUG_FRAME,
                                fig=dlg.fig)
        dlg.ShowModal()
        dlg.Destroy()                        
        neuronprops.update(protocol.results())

    ##
    ## processing Rheobase protocol
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.RHEO_PROTOCOL_NAMES])  and 'Rheobase' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        cmds=[cfg.RHEO_CURRENT_STEP]*len(sigs)
        dlg=PlotDialog(None,size=(800,600) )
        protocol=RheobaseProtocol(sigs,
                                cmds=cmds,
                                interactive=cfg.RHEO_DEBUG_FRAME,
                                fig=dlg.fig)
        dlg.ShowModal()
        dlg.Destroy()    
        neuronprops.update(protocol.results())

    ## unknown protocol/disabled protocol. warn the user
    else:
        logging.getLogger('myapp').warning(f"Unknown / disabled protocol {protocolname}. Check protocol association and PROCESS__ flags.")
    
    if not protocol is None:
        if cfg.ITSQ_PROTOCOL_SAVE_DATA:protocol.savedata(inpath,protocolname)
    
    return neuronprops

def processfolder(fpath):
    ## get meta info from folder
    neuronprops={}
    protocol=FolderNameProtocol(fpath)
    neuronprops.update(protocol.results())
    ## search all files with required extension _prefix(cfg.PROCESS_EXTENSIONS,'*')
    allfiles=[f for ext in _prefix(cfg.PROCESS_EXTENSIONS,'*') for f in fpath.glob(ext) ]
    for inpath in allfiles:
        neuronprops.update(process_file(inpath))
    return neuronprops

def process(inpath,disable_filter=False):
    cfg.parse(Path(__file__).resolve().parent/gen_cfg_file)
    ## start processing
    allneurons=[]
    ## single file
    if Path(inpath).is_file() and Path(inpath).suffix in _prefix(cfg.PROCESS_EXTENSIONS,''):
        neuron={}
        neuron.update(process_file(Path(inpath)))
        allneurons.append(neuron)

    ## folder with files
    if Path(inpath).is_dir():
        if len([f for ext in _prefix(cfg.PROCESS_EXTENSIONS,'*') for f in Path(inpath).glob(ext) ])>0:
            neuron={}
            neuron.update(processfolder(Path(inpath)))
            allneurons.append(neuron)
        else:
            ## folder with mess
            folders=set([f.parents[0] for ext in _prefix(cfg.PROCESS_EXTENSIONS,'**/*') for f in Path(inpath).glob(ext) ])
            for folder in folders:
                neuron={}
                neuron.update(processfolder(folder))
                allneurons.append(neuron)
    ## before we output to csv,excel, ..., we have to make sure that we have exactly the same fields for all neurons
    ## fortunately, pandas takes care of this for us, provided that an index is given
    df=pd.DataFrame(allneurons).T
    ## optionnally read output fields from specified file
    ## python should be easy to read! sorry!
    if cfg.ITSQ_OUTPUT_FIELDS_FILE and not disable_filter:
        if (Path(__file__).resolve().parent/cfg.ITSQ_OUTPUT_FIELDS_FILE).is_file():
            outfields=[ l.split("#")[0].rstrip(' \t\n\r').lstrip('+-#')                         \
                        for l in open(Path(__file__).resolve().parent/cfg.ITSQ_OUTPUT_FIELDS_FILE)  \
                        if not ( l.split("#")[0].startswith('-') or \
                                l.split("#")[0].startswith('#') or \
                                len(l.split("#")[0].strip(' \t\n\r')) == 0
                                )
                    ]
        else:
            logging.getLogger('myapp').info("Could not find list of output parametes. Generating one")
            outfields=[ k for pname in cfg.PROCESS_PROTOCOLS for k in globals()[pname+"Protocol"].provides(None).keys()]
            with open(Path(__file__).resolve().parent/cfg.ITSQ_OUTPUT_FIELDS_FILE,'w') as outfile:
                outfile.writelines([l+"\n" for l in outfields])
        discarded=[p for p in df.index if not p in outfields]
        for p in discarded:
            logging.getLogger('myapp').warning(f"parameter {p} is rejected by output configuration ")
        df=df.reindex(outfields)

    if cfg.OUTPUT_CSV:        df.to_csv("results.csv",sep=cfg.OUTPUT_CSVSEP)
    if cfg.OUTPUT_JSON:       df.to_json("results.json")
    if cfg.OUTPUT_EXCEL:      df.to_excel("results.xlsx")
    if cfg.OUTPUT_CLIPBOARD:
        ## to_clipboard behavior has changed recently...
        df.to_clipboard(excel=cfg.OUTPUT_CLIPBOARD_EXCEL,index=cfg.OUTPUT_CLIPBOARD_ROWNAMES)
    return df
