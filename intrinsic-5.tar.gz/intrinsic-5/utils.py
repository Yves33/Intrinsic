#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

## data science stack
import numpy as np
import quantities as pq
from config import cfg

#from utils import _autoscale,_clamp
def _autoscale(ax,x,y,xmargin=0,ymargin=0.1):
    ## assume x is monotonically increasing. Not the case for periodograms...
    #xmin=float(x[0])  ## x.min()
    #xmax=float(x[-1])  ## x.max()
    xmin=float(x.min())
    xmax=float(x.max())
    ymin=float(y.min())
    ymax=float(y.max())
    xmargin=0.1*(xmax-xmin)
    ax.set_xlim(xmin-xmargin,xmax+xmargin)
    ymargin=0.1*(ymax-ymin)
    ax.set_ylim(ymin-ymargin,ymax+ymargin)

def _prefix(stringlist,prefix):
    return [prefix+l for l in stringlist] 

def _clamp(x,lo,hi):
    return max(lo, min(x, hi))

def _norm(a):
    #return a/np.linalg.norm(a)
    return a/(a.max()-a.min())

def _pq_mean(l,rescale=None):
    if len(l):
        if rescale is None:
            rescale=l[0].units
        return (np.nanmean(l)*l[0].units).rescale(rescale)
    else:
        return np.nan*rescale

def _pq_max(l,rescale=None):
    if len(l):
        if rescale is None:
            rescale=l[0].units
        return (np.nanmax(l)*l[0].units).rescale(rescale)
    else:
        return np.nan*rescale

def _pq_min(l,rescale=None):
    if len(l):
        if rescale is None:
            rescale=l[0].units
        return (np.nanmax(l)*l[0].units).rescale(rescale)
    else:
        return np.nan*rescale

def _pq_nearest(value,choices, tolerance=0.06):
    '''returns the nearest quantity within an array'''
    idx = (np.abs(choices - value)).argmin()
    res=choices[idx]
    if 1-tolerance<=(value/res).simplified<=1+tolerance:
        return True,res
    return False,res

def _pq_value(i):
        if type(i)==pq.quantity.Quantity:
            return float(i.magnitude)
        else:
            return i

def _pq_unit(i):
    if type(i)==pq.quantity.Quantity:
        return i.str
    else:
        return 'dimensionless'