#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

## Python stdlib import. Can't live without it
import os,sys,platform,logging,fnmatch,pprint,re,time
from pathlib import Path
import pickle,json

import jsonpickle
import jsonpickle.ext.numpy as jsonpickle_numpy
jsonpickle_numpy.register_handlers()
import jsonpicklehandlers

import warnings
warnings.filterwarnings('ignore')
warnings.warn = lambda *args,**kwargs:0   ## shut down matplotlib deprecation warnings
## some specific imports
from collections.abc import Iterable

## data science stack
import numpy as np
import pandas as pd
import scipy
from scipy.signal import butter, lfilter, freqz
import quantities as pq
import neo
import neomonkey
neomonkey.installmonkey()               ## use our custom array access routines

from config import cfg
cfg.parse("./params/generic_params.py")

prefix={1e-12:'p',
        1e-9:'n',
        1e-6:'µ',
        1e-3:'m',
        1:'',
        1e3:'k',
        1e6:'M',
        1e9:'G'}
import matplotlib
## tried several backend, but none is clearly faster than another, ecept for gr, but which is very buggy!
'''
'GTK3Agg', 'GTK3Cairo', 'MacOSX', 'nbAgg', 'Qt4Agg', 'Qt4Cairo', 'Qt5Agg', 'Qt5Cairo', 
'TkAgg', 'TkCairo', 'WebAgg', 'WX', 'WXAgg', 'WXCairo', 
'agg', 'cairo', 'pdf', 'pgf', 'ps', 'svg', 'template'
'''
#matplotlib.use("module://gr.matplotlib.backend_gr")
if cfg.ITSQ_MPL_BACKEND in ['GTK3Agg', 'MacOSX', 'Qt4Agg', 'Qt5Agg', 'TkAgg', 'WXAgg']:
    matplotlib.use(cfg.ITSQ_MPL_BACKEND)
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
plt.rcParams['lines.antialiased']=True
plt.rcParams['lines.linewidth']=1.0
from mpl_interaction import PanAndZoom
from mpl_toolbutton import TriggerBtn,ToggleBtn
from mpl_draggable import draggable_line

#from config import cfg
#cfg.parse("./params/generic_params.py")

from experiment import Experiment
## default config file in case we lose the original one
basecfg='''
## parameters for IV curve analysis. Units are Volts and seconds
#########################################################################
## THESE PARAMETERS OVERWRITE DEFAULT PROGRAM VALUES.
#########################################################################
##
ITSQ_VERSION=3.0                                        ## the version of intrinsic that amtch this param file. The program will not load settings if there is a version mismatch
ITSQ_LOG_LEVEL=15                                       ## log level DEBUG=10 INFO=20 WARNING=30,ERROR=40 CRITICAL=50
ITSQ_PANZOOM_WHEEL_ONLY=True                            ## should be True
ITSQ_FIT_ITERATION_COUNT=2500                           ## maximum number of iterations for curve fitting 250-10000
ITSQ_FITTER_VERSION=1                                   ## 1 or 2. 2 sometimes gives weird results
ITSQ_OUTPUT_FIELDS_FILE="./params/outfields.txt"        ## list of parameters that the program should output. automatically regenerated if absent. set to False to ignore filtering
ITSQ_SKIP_FILES=['.','_']                               ## skip files starting with one of these characters
ITSQ_ENABLE_MULTIPROCESSING=True                        ## enable parallel processing for spontaneous and iv. Not a major improvement! May not work on some platforms (win, osx)
ITSQ_PROTOCOL_SAVE_DATA=True                            ## save analysis data for each protocol. not tested on OSX. WIP
ITSQ_PARSE_PROTOCOLS=True                               ## parse protocols for current pulses. not heavily tested experimental. works with IV, resistance and mb time constant
ITSQ_MPL_BACKEND=None                                   ## force matplotlib backend None (auto) or one of 'GTK3Agg', 'MacOSX', 'Qt4Agg', 'Qt5Agg', 'TkAgg', 'WXAgg'
#
EPSILON=0.001                                           ## slight offset between and current injection offsets and offsets for measurement. currently unused

## parameters for IV curve analysis
IV_CURRENT_INJECTION_START=0.1                          ## current injection start time. ususally 0.1 or 0.2      
IV_CURRENT_INJECTION_STOP=0.9                           ## current injection stop time ususally 0.9 or 1., or @IV_CURRENT_INJECTION_START+1.0
IV_BASELINE_START=0.0                                   ## baseline measurement start usually 0
IV_BASELINE_STOP=@IV_CURRENT_INJECTION_START-0.01       ## baseline measurement stop
IV_SAG_PEAK_START=@IV_CURRENT_INJECTION_START+0.01      ## start of sag peak measurement region
IV_SAG_PEAK_STOP=@IV_CURRENT_INJECTION_START+0.20       ## end of sag peak measurement region
IV_SAG_SS_START=@IV_CURRENT_INJECTION_STOP-0.3          ## start of sag stead ystate measurement region
IV_SAG_SS_STOP=@IV_CURRENT_INJECTION_STOP-0.01          ## end of sag stead ystate measurement region
IV_SAG_SS_TARGET_VOLTAGE=0.015                          ## sagratio will be measured for the frame for which sag steady state is the closest of this value (in V)
IV_SAG_TARGET_CURRENT=-100                              ## sagratio for injected current value
IV_TCFIT=True                                           ## calculte mb time constant in IV curve
IV_TCFIT_START=@IV_CURRENT_INJECTION_START+0.00025      ## where to start the membrane time constant fit
IV_TCFIT_STOP=@IV_CURRENT_INJECTION_START+0.2           ## where to stop the membrane time constant fit. if -1, will use sag peak time
IV_TCFIT_AUTOSTOP=True                                  ## automatically guess the end of the fit period (at first analyse)
IV_TCFIT_ORDER=2                                        ## fit with single (1) or double (2) exponential
IV_TCFIT_WEIGHTED_AVERAGE=True                          ## compute weighted average instead of arithmetic average
IV_TCFIT_THRESHOLD=-50                                  ## don't fit frames when injected current is less than
IV_TCFIT_R2_THRESHOLD=0.90                              ## don't accept fits with r2 coeff lower than this value (ignored)
IV_CURRENT_STEPS=[-200+20*i for i in range(26)]         ## list of current steps applied during IV protocol
IV_SPIKE_MIN_PEAK=-0.01                                 ## absolute spike peak votage! spikes that do not cross this threshold will be ignored!
IV_SPIKE_MIN_AMP=0.020                                  ## spike amplitude. more or less the minimum voltage variation betwen threshold and peak
IV_SPIKE_MIN_INTER=0.005                                ## minimum interval between two spikes
IV_SPIKE_PRE_TIME=0.005                                 ## time to keep before spike peak for threshold and maxrise measurement; 0.0015 is ususally enough
IV_SPIKE_POST_TIME=0.01                                 ## time to keep after spike peak for halfwidth measurement;0.005 may be required for correct phase plane analysis
IV_SPIKE_DV_THRESHOLD=0.0002                            ## threshold for first derivative, in case first threshold failed, in V/s. 10 is a good value
IV_SPIKE_LOWEST_THRESHOLD=True                          ## determines two thresholds, based on first and second derivative,and take lowest (otherwise the second threshold is used if threshold detection with 2nd derivative failed )
IV_SPIKE_EVOKED_THRESHOLD=0                             ## for a spike to be considered as evoked, current must be >= to this value. use 0.000001 to eliminate spontaneous spikes
IV_MIN_SPIKES_FOR_MEASURE=4                             ## minimum number of spikes in a frame to measure the threshold,maxrise, ...
IV_MAX_SPIKES_FOR_MEASURE=2000                          ## maximum number of spikes in a frame to measure the thresholds,maxrise, ...
IV_MIN_SPIKES_FOR_SFADAPT=4                             ## number of spikes required to compute spike frequency adaptation
IV_DEBUG_FRAME=True                                     ## display each iv frame

## parameters for AHP analysis
AHP_SS_START=0.0                                        ## start of baseline region for AHP measurement
AHP_SS_STOP=0.05                                        ## end of basline region for AHP measurements 
AHP_SPIKE_MIN_PEAK=0.1                                  ## absolute peak voltage for peak detection
AHP_SPIKE_MIN_AMP=0.050                                 ## minimal amplitude of peak for detection 
AHP_SPIKE_AUTO=True                                     ## determine automagically parameters for peak detection
AHP_MIN_SPIKE_COUNT=3                                   ## minimal number of spikes to count before rejecting a file. if n_spikes<AHP_MIN_SPIKES_COUNT then reject
AHP_MAX_DELAY=0.1                                       ## maximal delay after last identified spike to measure AHP  
AHP_TIME_WINDOW_AVERAGE=0.0002                          ## width (in s) of the window surrounding maximum negative deflection after  last spike
AHP_CHECK_SPIKE_COUNT=True                              ## check wether AHP files should have 5 or 15 APs. otherwise just take the first and last spikes to define baseline and AHP measurement regions. This parameter should be True
AHP_CHECK_SPIKE_FREQ=True                               ## reject frame if computed frequency does not match
AHP_DEBUG_FRAME=True                                    ## display ahp frame
AHP_VALID_COMBO=[(5,20),(5,40),(5,60),(5,80),(5,100),(5,120),(5,200),(15,20),(15,50)]  ## used to generate the list of AHP output fields

## parameters for mb time constant analysis
TC_FIT_START=0.0510                                     ## start of fit region for mb time constant.
TC_FIT_STOP=@TC_FIT_START+0.04                          ## end of fit region for mb time constant
TC_FIT_CURRENT_STEPS=[-400,-400,-400,400,400,400]       ## injected current. currently not used
TC_FIT_ORDER=2                                          ## fit with simple, double or triple exponential (1,2,3)
TC_WEIGHTED_AVERAGE=True                                ## take the weighted average of the two time constants, otherwise arithmetic average             
TC_DEBUG_FRAME=True                                     ## display tc frame

## parameters for résonnance analysis
RES_LOW_BAND=0.01                                       ## start of band pass
RES_HIGH_BAND=10                                        ## end of band pass
RES_DEBUG_FRAME=True                                    ## display resonnance frame

## parameters for resistance analysis
INPUTR_CURRENT_INJECTION_START=0.2                      ## start of current injection (seconds)
INPUTR_CURRENT_INJECTION_STOP=0.7                       ## end of current injection (seconds)
INPUTR_CURRENT_STEP=-20                                 ## current step amplitude (pA)
INPUTR_TCFIT_START=@INPUTR_CURRENT_INJECTION_START+0.01 ## start of exponential fit
INPUTR_TCFIT_STOP=@INPUTR_CURRENT_INJECTION_STOP-0.01   ## end of exponential fit             
INPUTR_TCFIT_ORDER=2                                    ## fitting order for exp
INPUTR_TCFIT_WEIGHTED_AVERAGE=True                      ## take the weighted average of the two time constants, otherwise arithmetic average
INPUTR_DEBUG_FRAME=True                                 ## display averaged frames

## parameters for spontaneous activity (current clamp. spikes)
SPONTANEOUS_DEBUG_FRAME=True                            ## display spontaneous activity frame

## parameters for ramp
RAMP_BOUNDARIES=[0.13,1.13,1.21,2.21]                   ## the regions for Ramp
RAMP_DEBUG_FRAME=True                                   ## display ramp frames

## parameters for folder naming
##FOLDER_NAMING_SCHEME='WTC1  -V2.1-12w-A1     -DIV21 -2022.03.01-Cell1
FOLDER_NAMING_SCHEME='cellline-vial-age-plateID-wellID-date-cell'   ## sceme for folder naming
FOLDER_NAMING_SEP='-'                                               ## separator for fields in folder name

## process flags
PROCESS_PROTOCOLS=['foldername','iv','resistance','spontaneousactivity','timeconstant','ahp','resonnance','ramp']
PROCESS_EXTENSIONS=['.axgx','.axgd','.abf','.maty']

## output parameters for csv,excel,json
OUTPUT_CSVSEP="\t"                                      ## the separator for fields, ususally comma (',') for csv or tab ('\t') for tsv
OUTPUT_CSV=True
OUTPUT_JSON=True
OUTPUT_EXCEL=True
OUTPUT_CLIPBOARD=True                                   ## output should also be pasted to clipboard
OUTPUT_CLIPBOARD_EXCEL=True                             ## clipboard should be formatted for excel
OUTPUT_CLIPBOARD_ROWNAMES=False                         ## clipboard should include row names

## scale factors. SI values are **divided** by these values
## The program caculates everything SI (V,A,s,Ohm,F)
OUTPUT_V_SCALE=1e-3                  ## use 1e-3 to convert V to mV          (0,003V             -> 3mV)
OUTPUT_OHM_SCALE=1e6                 ## use 1e6 to convert Ohms to MOhms     (450,235,123.00Ohms -> 450,23Mohms)
OUTPUT_S_SCALE=1e-3                  ## use 1e-3 to convert s to ms          (0.1s               -> 100ms)
OUTPUT_A_SCALE=1e-12                 ## use 1e-12 to convert A to pA         (0.000 000 000 153A -> 153pA)
OUTPUT_F_SCALE=1e-12                 ## use 1e-12 to convert F to pF         (0.000 000 000 256F -> 256pA)

## protocol names
## much fun here: different names for the "not so" different protocols with strictly identical analysis, depending on the setups...
## for analysis, provide a list of all protocol names that should match a given analysis
## each value is tested as an fnmatch string (? stands for any caracter, * for any suite of caracters, [Tt] any character in group)
IV_PROTOCOL_NAMES=['IV_multiclamp','3-IV curve','*CCSteps*','*IV*']
AHP_PROTOCOL_NAMES=['*5AP*',"*AHP*"]
TC_PROTOCOL_NAMES=['*[Tt]ime constant*',]
ZAP_PROTOCOL_NAMES=['*ZAP*', 'resonnance']
INPUTR_PROTOCOL_NAMES=['*resistance*']
SPONTANEOUS_PROTOCOL_NAMES=['*[Ss]pontaneous*']
RAMP_PROTOCOL_NAMES=['*ramp*']

'''

## some other globals
filecount=0	             ## nummber of files that were processed

######################################################################################
######################################################################################
## BASE and UTITY CLASSES
######################################################################################
######################################################################################
##################
## utility functions
##################
def once(method):
    def inner(ref):
        if len(_axes())==0:
            return method(ref)
    return inner

def _fig():
    return plt.gcf()

def _axes(idx=-1):
    if idx==-1:
        return plt.gcf().get_axes()
    else:
        return plt.gcf().get_axes()[idx]

def _pprint(q,unit):
    try:
        if unit==pq.Ohm:
            return f'{q/cfg.OUTPUT_OHM_SCALE:.3f} {prefix[cfg.OUTPUT_OHM_SCALE]}Ohms'
        elif unit==pq.V:
            return f'{q/cfg.OUTPUT_V_SCALE:.3f} {prefix[cfg.OUTPUT_V_SCALE]}V'
        elif unit==pq.s:
            return f'{q/cfg.OUTPUT_S_SCALE:.3f} {prefix[cfg.OUTPUT_S_SCALE]}s'
        elif unit==pq.A:
            return f'{q/cfg.OUTPUT_A_SCALE:.3f} {prefix[cfg.OUTPUT_A_SCALE]}A'
        elif unit==pq.F:
            return f'{q/cfg.OUTPUT_F_SCALE:.3f} {prefix[cfg.OUTPUT_F_SCALE]}F'
    except:
        return "nan"

def _autoscale(ax,x,y,xmargin=0,ymargin=0.1):
    xmargin=0.1*abs(max(x)-min(x))
    ax.set_xlim(min(x),max(x))
    ymargin=0.1*abs(max(y)-min(y))
    ax.set_ylim(min(y)-ymargin,max(y)+ymargin)

def _prefix(stringlist,prefix):
    return [prefix+l for l in stringlist] 

######################################################################################
## fitter object
## can fit linear, single and double exponentials
## for linear f(x)=a*x+b:                       : params are f.a and f.b
## for single exp f(x)=a*exp(-(x-o)/tc)) +b     : params are f.tc
## for double exp f(x)=a*exp(-(x-o)/tc1)) +b exp(-(x-o)/tc2)) +c : params are f.wtc (weighted average tc), f.atc (arythmetic average), f.tc1 and f.tc2
## usage 
#> f=xyfitter(xvalues,yvalues)
#> if f.success and fitter.r2>some_value:
#>     print(f.tc)
#######################################################################################
class xyfitter():
    def fitlinear(self,x,a,b):
        return a*x+b

    ## exponential fits with time offsets,o
    def fit1exp(self,x,a,b,c,o):
        return a*np.exp(-(x-o)/b)+c

    def fit2exp(self,x,a,b,c,d,e,o):
        return a*np.exp(-(x-o)/b)+c*np.exp(-(x-o)/d)+e

    ## exponential fits with time offsets,o
    def fit1expnoo(self,x,a,b,c):
        return a*np.exp(-(x)/b)+c

    def fit2expnoo(self,x,a,b,c,d,e):
        return a*np.exp(-(x)/b)+c*np.exp(-(x)/d)+e

    def __init__(self,x,y,fitmode,weighted=True,o=0.0):
        self.fitmode=fitmode
        if fitmode==0:
            self.fitfunc=self.fitlinear
            self.pot=[1.0,0.0]
            self.o=0.0
            try:
                self.pot,pcov=scipy.optimize.curve_fit(self.fitfunc,x,y,p0=tuple(self.pot), maxfev=cfg.ITSQ_FIT_ITERATION_COUNT)
                self.success=True
            except:
                logging.getLogger(__name__).debug(f"Linear fit failed")
                self.a=np.nan
                self.b=np.nan
                self.success=False
        if fitmode==1:
            if cfg.ITSQ_FITTER_VERSION==1:
                self.o=o ## should be x[0]?
                self.fitfunc=self.fit2expnoo
                self.pot=[1.0,0.02,-70] ## approximate initial parameters for mb time constants
                x=x-x[0]
            else:
                self.fitfunc=self.fit1exp
                self.pot=[1.0,0.02,-70,o]  ## approximate initial parameters for mb time constants
            try:
                self.pot,pcov=scipy.optimize.curve_fit(self.fitfunc,x,y,p0=tuple(self.pot), maxfev=cfg.ITSQ_FIT_ITERATION_COUNT)
                self.tc=self.pot[1]
                self.success=True
            except:
                logging.getLogger(__name__).debug(f"First order exponential fit failed")
                self.tc=np.nan
                self.success=False
        if fitmode==2:
            if cfg.ITSQ_FITTER_VERSION==1:
                self.o=o ## should be x[0]?
                self.fitfunc=self.fit2expnoo
                self.pot=[1.0,0.02,1.0,0.0015,-0.07] ## approximate initial parameters for mb time constants
                x=x-x[0]
            else:
                self.fitfunc=self.fit2exp
                self.pot=[1.0,0.02,1.0,0.0015,-0.07,o] ## approximate initial parameters for mb time constants
            try:
                self.pot,pcov=scipy.optimize.curve_fit(self.fitfunc,x,y,p0=tuple(self.pot), maxfev=cfg.ITSQ_FIT_ITERATION_COUNT)
                self.wtc=(self.pot[0]*self.pot[1]+self.pot[2]*self.pot[3])/(self.pot[0]+self.pot[2]) ## weighted average
                self.atc=(self.pot[1]+self.pot[3])/2                                                 ## average, not weighted
                self.tc1=self.pot[1]                                                                 ## first time constant
                self.tc2=self.pot[3]                                                                 ## second time constant
                if weighted:
                    self.tc=self.wtc
                else:
                    self.tc=self.atc
                self.success=True
                self.r2=self.getr2(x,y)
            except:
                logging.getLogger(__name__).debug(f"Second order exponential fit failed")
                self.tc=np.nan
                self.r2=0.0
                self.success=False
        ## in order to output correct results with jsonpickle, we have to transform pot to list
        self.pot=[float(p) for p in self.pot]
    
    def getr2(self,x,y):
        y_fit=self.line(x)
        ss_res = np.sum((y-y_fit)**2)
        ss_tot = np.sum((y- np.mean(y))**2)
        return 1-(ss_res/ss_tot)

    def line(self,arr):
        if self.success:
            if cfg.ITSQ_FITTER_VERSION==1:
                return np.array([self.fitfunc(t-self.o,*self.pot) for t in arr])
            else:
                return np.array([self.fitfunc(t,*self.pot) for t in arr])
        else:
            return np.array([])


######################################################################################
## baseframe and baseprotocol
## ancestors to any **frame and **procotol
#######################################################################################
class baseframe:
    def __init__(self,idx,parent):
        self.idx=idx
        self.parent=parent
        self.enabled=True
        self.process() ## only exists in derived class

    def activate(self):
        ## to be called when the frame becomes current.
        pass

    def deactivate(self):
        ## to be called when the frame becomes current. currently unused
        pass

    def _cursor(self,ax,dir,value,cb):
        ## keep a reference to created cursor in figure, otherwise the cursor object disappears (while the line is still present on graph!)
        if not hasattr(_fig(),'cursors'):
            _fig().cursors=[]
        if isinstance(ax,Iterable):
            _fig().cursors.append(draggable_line(ax,dir, value, cb))
        else:
            _fig().cursors.append(draggable_line([ax],dir, value, cb))

    def _get_cursor(self,x):
        return _fig().cursors[x]

    def _update_local(self,var,value):
        self.parent.currentframe().__setattr__(var,value)

    def _update_global(self,var,value):
        cfg.set(var,value)

    def _clf(self,ids):
        for ax in _axes():
            self._cla(ax,ids)
    
    def _cla(self,ax,ids):
        for l in ax.lines[::-1]:
            if l.get_gid() in ids:
                try:
                    l.remove()
                    del l
                except:
                    pass

class baseprotocol:
    def __init__(self,interactive):
        self.f=0
        if interactive:
            pan_zoom = PanAndZoom(_fig(),cfg.ITSQ_PANZOOM_WHEEL_ONLY)
            if len(self.frames)>1:
                fwdbtn=TriggerBtn(_fig(),"prev",'alt+p',str(Path(__file__).parent/'resources/fa-backward-solid.png'),'Jump to previous frame',self.prevframe)
                trashbtn=ToggleBtn(_fig(),"disable",'alt+d',str(Path(__file__).parent/'resources/fa-trash-solid.png'),'Disable/enable this frame',self.toggleframe)
                bwdbtn=TriggerBtn(_fig(),"next",'alt+n',str(Path(__file__).parent/'resources/fa-forward-solid.png'),'Jump to next frame',self.nextframe)
                allbtn=TriggerBtn(_fig(),"all",'alt+a',str(Path(__file__).parent/'resources/fa-redo-solid.png'),'Apply parameters to all frames',self.processall)
            else:
                trashbtn=ToggleBtn(_fig(),"disable",'alt+d',str(Path(__file__).parent/'resources/fa-trash-solid.png'),'Disable/enable this frame',self.toggleframe)
            self.frames[self.f].draw()
            _fig().canvas.draw()
            plt.show()

    def currentframe(self):
        return self.frames[self.f]

    def nextframe(self,*args,**kwargs):
        self.frames[self.f].deactivate()
        self.f=max(0, min(self.f+1, len(self.frames)-1)) ## quick clamp
        self.frames[self.f].activate()
        self.frames[self.f].draw()
        self.colorize()
        _fig().canvas.draw()

    def prevframe(self,*args,**kwargs):
        self.frames[self.f].deactivate()
        self.f=max(0, min(self.f-1, len(self.frames)-1)) ## quick clamp
        self.frames[self.f].activate()
        self.frames[self.f].draw()
        self.colorize()
        _fig().canvas.draw()

    def toggleframe(self,*args,**kwargs):
        self.frames[self.f].enabled=not self.frames[self.f].enabled
        self.colorize()
        _fig().canvas.draw()

    def colorize(self):
        _fig().patch.set_facecolor('white' if self.frames[self.f].enabled else 'silver')
        for ax in _axes():
            ax.set_facecolor('white' if self.frames[self.f].enabled else 'silver')

    def process(self, bitmask=0xFFFF):
        self.frames[self.f].process(bitmask)

    def processall(self,*args,**kwargs):
        for f in self.frames:
            f.process(0xFFFF)
        self.draw(False)

    def draw(self,drawall=True):
        self.frames[self.f].draw(drawall)

    def savedata(self,basefile,protocolname):
        parentdir=Path(basefile).resolve().parent
        stem=Path(basefile).resolve().stem
        if not os.path.exists(parentdir/"@itsq"):
            os.mkdir(parentdir/"@itsq")
        filename=parentdir/f"@itsq/{stem}.itsq"
        with open(filename, 'w') as outfile:
            self.protocolname=protocolname
            outfile.write(json.dumps(json.loads(jsonpickle.encode(self,unpicklable=True)), indent=4))
    

##################################################################################################
##################################################################################################
##################################################################################################
## START OF PROTOCOLS SECTION
##################################################################################################
##################################################################################################
##################################################################################################
'''
    Time Constant Protocol, Frick lab version
    attempts to fit a single of double exponential over Voltage curve
    input:  sigs: array of neo.io.AnalogSignal with units V, mV (units are not checked, so should also work with pA)
    cfg:TC_FIT_START,TC_FIT_STOP,TC_WEIGHTED_AVERAGE,TC_DEBUG_FRAME,OUTPUT_S_SCALE
    usage: protocol=timeconstantprotocol(sig,interactive)
           print(protocol.results())
'''
class tcframe(baseframe):
    def __init__(self,sig,idx,parent):
        self.voltage=sig
        super(tcframe,self).__init__(idx,parent)

    def process(self,bitmask=0xFFFF):
        times=self.voltage.s(cfg.TC_FIT_START,cfg.TC_FIT_STOP)
        volts=self.voltage.V(cfg.TC_FIT_START,cfg.TC_FIT_STOP)
        self.fitter=xyfitter(times,volts,cfg.TC_FIT_ORDER,cfg.TC_WEIGHTED_AVERAGE,cfg.TC_FIT_START)
        self.fitline=[times,self.fitter.line(times)]
    
    @once
    def setup(self):
        _fig().subplots(1, 1)
        self._cursor(_axes(0),'v',cfg.TC_FIT_START,
                    lambda x:cfg.set('TC_FIT_START',x) or print("test") or self.parent.process(0xFFFF) or self.parent.draw (False))
        self._cursor(_axes(0),'v',cfg.TC_FIT_STOP,
                    lambda x:cfg.set('TC_FIT_STOP',x) or self.parent.process(0xFFFF) or self.parent.draw (False))

    def draw(self,drawall=True):
        self.setup() ## ensure that axes are ready!
        _fig().canvas.set_window_title("Time constant protocol")
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            _axes(0).plot(self.voltage.s(), self.voltage.V(),color='blue',gid='traces')
            _autoscale(_axes(0),self.voltage.s(),self.voltage.V())
        self._clf(['markers'])
        if self.fitter.success:
            _axes(0).set_title(f'TC: {_pprint(self.fitter.tc,pq.s)}')
            _axes(0).plot( self.fitline[0], self.fitline[1],color='red',gid='markers')

class timeconstantprotocol(baseprotocol):
    def __init__(self,sigs,interactive):
        self.frames=[tcframe(s,idx=e,parent=self) for e,s in enumerate(sigs) ]
        super(timeconstantprotocol,self).__init__(interactive)
    def provides(self):
        return {'TC_tc_neg':'avg time constant, measured for negative current pulse',
                'TC_tc_pos':'avg time constant, measured for positive current pulse'}
    def results(self):
        ## np.mean return nan for empty lists
        self.r= {'TC_tc_neg':np.nanmean([f.fitter.tc for f in self.frames if f.fitter.success and f.enabled and f.idx<len(self.frames)/2 ] )/cfg.OUTPUT_S_SCALE,
                'TC_tc_pos':np.nanmean([f.fitter.tc for f in self.frames if f.fitter.success and f.enabled and f.idx>len(self.frames)/2 ] )/cfg.OUTPUT_S_SCALE}
        return self.r
'''
    Resistance Protocol, Frick lab version
    attempts to fit a single of double exponential over Voltage curve and measures resistance
    input:  sigs: array of neo.io.AnalogSignal with units V, mV (units are not checked)
    currentstep: the value of the current step
    results:Resistance_avg_pulse,Time_constant_average_pulse
    cfg:INPUTR_CURRENT_INJECTION_START,INPUTR_CURRENT_INJECTION_STOP,INPUTR_WEIGHTED_AVERAGE,INPUTR_FIT_ORDER,OUTPUT_S_SCALE,OUTPUT_OHM_SCALE
    usage: protocol=resistanceprotocol(sig,interactive)
           print(protocol.results())
'''
class resistanceframe(baseframe):
    def __init__(self,sig,currentstep,idx,parent):
        self.voltage=sig
        self.currentstep=currentstep
        super(resistanceframe,self).__init__(idx,parent)

    def process(self,bitmask=0xFFFF):
        midpoint=0.66*(cfg.INPUTR_CURRENT_INJECTION_START+cfg.INPUTR_CURRENT_INJECTION_STOP)
        self.baseline=np.mean(self.voltage.V(0.0,cfg.INPUTR_CURRENT_INJECTION_START))
        self.steadystate=np.mean(self.voltage.V(midpoint,cfg.INPUTR_CURRENT_INJECTION_STOP))
        self.resistance=np.abs((self.baseline-self.steadystate)/self.currentstep*1e12) ##in Ohms current step is in pA 
        times=self.voltage.s(cfg.INPUTR_TCFIT_START,cfg.INPUTR_TCFIT_STOP)
        volts=self.voltage.V(cfg.INPUTR_TCFIT_START,cfg.INPUTR_TCFIT_STOP)
        self.fitter=xyfitter(times,volts,cfg.INPUTR_TCFIT_ORDER,cfg.INPUTR_TCFIT_WEIGHTED_AVERAGE,cfg.INPUTR_TCFIT_START)
        self.fitline=[times,self.fitter.line(times)]
        negpeak=np.argmin(self.voltage.V())/float(self.voltage._sampling_rate)
        self.sagpeak=np.mean(self.voltage.V(negpeak-0.01,negpeak+0.01))
        self.sagratio=(self.baseline-self.steadystate)/(self.baseline-self.sagpeak)  

    @once
    def setup(self):
        _fig().subplots(1, 1)
        self._cursor(_axes(0),'v',cfg.INPUTR_TCFIT_START,
                    lambda x:cfg.set('INPUTR_TCFIT_START',x) or self.parent.process(0xFFFF) or self.parent.draw ())
        self._cursor(_axes(0),'v',cfg.INPUTR_TCFIT_STOP,
                    lambda x:cfg.set('INPUTR_TCFIT_STOP',x) or self.parent.process(0xFFFF) or self.parent.draw ())

    def draw(self,drawall=True):
        self.setup() ## ensure that axes are ready!
        _fig().canvas.set_window_title("Resistance protocol")
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            _axes(0).plot(self.voltage.s(), self.voltage.V(),color='blue',gid='traces')
            _autoscale(_axes(0),self.voltage.s(),self.voltage.V())
        self._clf(['markers'])
        _axes(0).set_title(f'Res : {_pprint(self.resistance,pq.Ohm)} '+\
                           f'TC: {_pprint(self.fitter.tc,pq.s)}')
        if self.fitter.success:
            _axes(0).plot( self.fitline[0], self.fitline[1],color='red',gid='markers')
        _axes(0).axhline(self.baseline,color="black",linestyle ="--",gid='markers')
        _axes(0).axhline(self.steadystate,color="grey",linestyle ="--",gid='markers')
        _axes(0).axhline(self.sagpeak,color="green",linestyle ="--",gid='markers')

class resistanceprotocol(baseprotocol):
    def __init__(self,sigs,interactive,currentstep=None):
        self.frames=[resistanceframe(s,currentstep,idx=e,parent=self) for e,s in enumerate(sigs) ]
        super(resistanceprotocol,self).__init__(interactive)
    def provides(self):
        return {'INPUTR_res':'avg input resistance',
                'INPUTR_tc':'avg time constant',
                'INPUTR_baseline':'avg baseline before current pulse',
                'INPUTR_sagratio':'avg sag ratio'}
    def results(self):
        self.r= {'INPUTR_res':np.nanmean([f.resistance for f in self.frames if f.enabled ] ) / cfg.OUTPUT_OHM_SCALE,
                'INPUTR_tc':np.nanmean([f.fitter.tc for f in self.frames if f.fitter.success and f.enabled ] ) / cfg.OUTPUT_S_SCALE,
                'INPUTR_baseline':np.nanmean([f.baseline for f in self.frames if f.fitter.success and f.enabled]) / cfg.OUTPUT_V_SCALE,
                'INPUTR_sagratio':np.nanmean([f.sagratio for f in self.frames if f.fitter.success and f.enabled])}
        return self.r
'''
    AHP protocol, Frick lab version
    measures the AHP after last spike in a series of 5 or 15 spikes at distinct frequencies
    input:  sigs: array of neo.io.AnalogSignal with units V, mV (units not checked)
    freq: the frequency of spike trains. if none, the program tries to guess
    cfg:AHP_SS_START, AHP_SS_STOP, AHP_SPIKE_MIN_PEAK, AHP_SPIKE_MIN_AMP, AHP_TIME_WINDOW_AVERAGE,AHP_IGNORE_SPIKE_COUNT,AHP_IGNORE_FREQUENCY_CHECK
    usage: protocol=ahpprotocol(sig,interactive)
           print(protocol.results())
'''
class ahpframe(baseframe):
    def __init__(self,sig,frequency,idx,parent):
        self.voltage=sig
        if not frequency is None:
            self.frequency=frequency
            self.autofreq=False
        else:
            self.frequency=None
            self.autofreq=True
        self.ahp_value=None
        self.ahp_value_1s=None
        if cfg.AHP_SPIKE_AUTO:
            hi,lo=np.max(self.voltage.V()),np.min(self.voltage.V())
            delta=(hi-lo)
            cfg.AHP_SPIKE_MIN_PEAK=lo+delta*0.5
            cfg.AHP_SPIKE_MIN_AMP=delta*0.35
        super(ahpframe,self).__init__(idx,parent)

    def process(self,bitmask=0xFFFF):
        self.baseline=float(np.mean(self.voltage.V(cfg.AHP_SS_START,cfg.AHP_SS_STOP)))
        volts=self.voltage.V()
        times=self.voltage.s()
        ## working in samples, as we're using find_peaks and argmin
        peak_pos,peak_info=scipy.signal.find_peaks(volts, \
                                        height=cfg.AHP_SPIKE_MIN_PEAK,\
                                        prominence=cfg.AHP_SPIKE_MIN_AMP,\
                                        distance=int(0.00040*self.voltage._sampling_rate)) # up to 200Hz
        validcounts=set([cnt for cnt,freq in cfg.AHP_VALID_COMBO])
        validfreqs=set([freq for cnt,freq in cfg.AHP_VALID_COMBO])
        self.peakcount=len(peak_pos)
        self.peaks={'x':times[peak_pos],'y':volts[peak_pos]}
        if self.autofreq:
            try:
                self.frequency=(len(peak_pos)-1)/(times[peak_pos[-1]]-times[peak_pos[0]])
                self.frequency=int(10*round(self.frequency/10))
            except:
                self.frequency=np.nan
        if self.peakcount<cfg.AHP_MIN_SPIKE_COUNT:
            logging.getLogger().error("Could not find at least 3 peaks in file!")
            self.ahp_pos=np.nan
            self.ahp_value=np.nan
            self.ahp_pos_1s=np.nan
            self.ahp_value_1s=np.nan
            if self.peakcount<1:
                return
        if cfg.AHP_CHECK_SPIKE_COUNT and not (self.peakcount in validcounts):
            logging.getLogger().error(f"The number of detected peaks ({self.peakcount}) is unexpected!")
            self.ahp_pos=np.nan
            self.ahp_value=np.nan
            self.ahp_pos_1s=np.nan
            self.ahp_value_1s=np.nan
            return
        elif cfg.AHP_CHECK_SPIKE_FREQ and not (self.frequency in validfreqs):
            logging.getLogger().error(f"The computed frequency ({self.frequency}) is unexpected!")
            self.ahp_pos=np.nan
            self.ahp_value=np.nan
            self.ahp_pos_1s=np.nan
            self.ahp_value_1s=np.nan
            return
        ## get the mimimum
        self.ahp_pos=peak_pos[-1]+np.argmin(  volts[peak_pos[-1] : peak_pos[-1] + int(cfg.AHP_MAX_DELAY*self.voltage.sampling_rate) ] )
        start=int(self.ahp_pos-cfg.AHP_TIME_WINDOW_AVERAGE*int(self.voltage.sampling_rate))
        stop=int(self.ahp_pos+cfg.AHP_TIME_WINDOW_AVERAGE*int(self.voltage.sampling_rate))
        self.ahp_value=self.baseline-np.mean(volts[start:stop]) ##self.baseline-np.mean(self.voltage.V(start,stop)) works also, as start and stop are int
        ## get the value 1s after last peak
        try:
            self.ahp_pos_1s=peak_pos[-1]+int(1.0*self.voltage.sampling_rate)
            start=int(self.ahp_pos_1s-cfg.AHP_TIME_WINDOW_AVERAGE*int(self.voltage.sampling_rate))
            stop=int(self.ahp_pos_1s+cfg.AHP_TIME_WINDOW_AVERAGE*int(self.voltage.sampling_rate))
            self.ahp_value_1s=self.baseline-np.mean(volts[start:stop])
        except:
            self.ahp_pos_1s=np.nan
            self.ahp_value_1s=np.nan

    @once
    def setup(self):
        _fig().subplots(1, 1)
        self._cursor(_axes(0),'h',cfg.AHP_SPIKE_MIN_PEAK,
                    lambda x:cfg.set('AHP_SPIKE_MIN_PEAK',x) or self.parent.process(0xFFFF) or self.parent.draw (False))
        self._cursor(_axes(0),'h',cfg.AHP_SPIKE_MIN_PEAK-cfg.AHP_SPIKE_MIN_AMP,
                    lambda x:cfg.set('AHP_SPIKE_MIN_AMP',cfg.AHP_SPIKE_MIN_PEAK-x) or self.parent.process(0xFFFF) or self.parent.draw (False))

    def draw(self,drawall=True):
        self.setup() ## ensure that axes are ready!
        _fig().canvas.set_window_title("AHP protocol")
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            _axes(0).plot(self.voltage.s(), self.voltage.V(),color='blue',gid='traces')
            _autoscale(_axes(0),self.voltage.s(),self.voltage.V())
        self._clf(['markers'])
        _axes(0).axhline(self.baseline,color="black",linestyle ="--",gid='markers')
        if not self.ahp_value is None:
            _axes(0).set_title(f'Calc Freq: {self.frequency:.2f}Hz '+
                               f'AHP : {_pprint(self.ahp_value,pq.V)}')
            _axes(0).axhline(self.baseline-self.ahp_value,color="green",linestyle ="--",gid='markers')
        if not (self.ahp_value_1s is None or np.isnan(self.ahp_value_1s)):
            _axes(0).set_title(f'Calc Freq: {self.frequency:.2f}Hz '+
                               f'AHP : {_pprint(self.ahp_value,pq.V)} '+
                               f'AHP_1s : {_pprint(self.ahp_value_1s,pq.V)}')
            _axes(0).plot([self.ahp_pos_1s/self.voltage.sampling_rate],[self.baseline-self.ahp_value_1s],"o",color='orange', gid="markers")
        _axes(0).plot(self.peaks['x'],self.peaks['y'],'x',color='red',gid="markers")

class ahpprotocol(baseprotocol):
    def __init__(self,sigs,interactive,frequency=None):
        self.frames=[ahpframe(s,frequency,idx=e,parent=self) for e,s in enumerate(sigs) ]
        super(ahpprotocol,self).__init__(interactive)
    def provides(self):
        r={}
        for cnt,freq in cfg.AHP_VALID_COMBO:
            if cnt<6:
                r.update({f'AHP_{cnt}_{freq}Hz_min':'maximal hyperpolarization after last detected pulse.'})
            if cnt>6:
                r.update({f'AHP_{cnt}_{freq}Hz_min':'maximal hyperpolarization after last detected pulse.'})
                r.update({f'AHP_{cnt}_{freq}Hz_1s':'hyperpolarization 1s after last detected pulse.'})
        return r
    def results(self):
        cnt=self.frames[0].peakcount
        freq=self.frames[0].frequency
        if cnt<6: ## AHP MED protocol
            self.r= {f'AHP_{cnt}_{freq}Hz_min':self.frames[0].ahp_value/cfg.OUTPUT_V_SCALE}
        elif cnt>5: ## AHP SLOW protocol
            self.r= {f'AHP_{cnt}_{freq}Hz_min':self.frames[0].ahp_value/cfg.OUTPUT_V_SCALE,
                    f'AHP_{cnt}_{freq}Hz_1s':self.frames[0].ahp_value_1s/cfg.OUTPUT_V_SCALE}
        return self.r

'''
    IV protocol, Frick lab version
    counts spikes, measures spike properties, AHP, resistance,...
    input:  sigs: array of neo.io.AnalogSignal with units V, mV (units are not checked)
    "       or, to be implemented, array of tuples of neo signals with units V,mV and nA, pA
    cfg:
    usage: protocol=ivprotocol(sig,interactive)
           print(protocol.results())
'''
class spike(object):
    def __init__(self,signal,pos,idx,fidx,ahpbaseline=None):
        pre=cfg.IV_SPIKE_PRE_TIME
        post=cfg.IV_SPIKE_POST_TIME
        prepts=cfg.IV_SPIKE_PRE_TIME*signal._sampling_rate          ## number of points to keep before peak
        postpts=cfg.IV_SPIKE_POST_TIME*signal._sampling_rate        ## number of points to keep after peak
        volts=signal.V()                                        ## convert to raw numpy array
        times=signal.s()                                        ## convert to raw numpy array
        self.pos=pos                                            ## pos of spike (in samples)in frame
        self.idx=idx                                            ## the index of spike in frame
        self.fidx=fidx                                          ## the frame the spike belongs to belongs to
        self.time=times[pos]                                    ## time of spike in frame
        self.peak=volts[pos]                                    ## peak amplitude of spike
        self.ISI=np.nan                                         ## inter spike interval. will be calculated later
        self.evoked=False                                       ## spike is evoked spike. will be calculated later
        self.rebound=False                                      ## spike is rebound spike
        ## position and value for max rising slope (in samples)
        self.maxrisepos=np.argmax(np.gradient(   signal.V(self.time-pre,self.time+post)   ))
        self.maxrise=float(np.max(np.gradient(   signal.V(self.time-pre,self.time+post)   )) * signal._sampling_rate) ## to convert to V/s
        self.maxrisepos+=self.pos-int(pre*signal._sampling_rate)

        ## position and value for max descending slope (in samples)
        self.maxfallpos=np.argmin(np.gradient(  signal.V(self.time-pre,self.time+post)   ))
        self.maxfall=float(np.min(np.gradient(  signal.V(self.time-pre,self.time+post)   )) *signal._sampling_rate)
        self.maxfallpos+=self.pos-int(pre*signal._sampling_rate)

        ## phase plane values. As it is guaranteed that they will exist, we have to write them before trying to find threshold
        ## for phase plane analysis, we'll keed a list of voltages and voltage variation
        #self.PPV=volts[pos-int(prepts):pos+int(postpts)]
        self.PPV=signal.V(self.time-pre,self.time+post)
        self.PPdV=np.gradient(self.PPV)* signal._sampling_rate ## to convert to V/s

        ## position and value for threshold
        ## using second derivarive maximum is very unefficient.
        ## using second derivative threshold isn't more efficient than maximum.
        ## see https://stackoverflow.com/questions/3843017/efficiently-detect-sign-changes-in-python
        ## the latest algorithm is as follow: get the threshold pos both on first and second derivatives, and take the first one!
        try:
            thrsignal=np.gradient(np.gradient(  signal.V(self.time-pre,self.time+post)  )) -float(cfg.IV_SPIKE_DV_THRESHOLD)
            self.thresholdpos1=np.where(np.diff(np.signbit(thrsignal)))[0][0]
            self.thresholdpos1+=self.pos-int(pre*signal._sampling_rate)
        except:
            self.thresholdpos1=np.nan
        try:
            thrsignal=np.gradient(             signal.V(self.time-pre,self.time+post) ) -float(cfg.IV_SPIKE_DV_THRESHOLD)
            self.thresholdpos2=np.where(np.diff(np.signbit(thrsignal)))[0][0]
            self.thresholdpos2+=self.pos-int(pre*signal._sampling_rate)
        except:
            self.thresholdpos2=np.nan
        if cfg.IV_SPIKE_LOWEST_THRESHOLD:
            self.thresholdpos=np.nanmin([self.thresholdpos1,self.thresholdpos2])
        else:
            self.thresholdpos=self.thresholdpos1 if self.thresholdpos1!=np.nan else self.thresholdpos2

        ## if we failed at identifying a threshold, then mark spike as incomplete and use np.nan values for the remaining spike measurements
        if np.isnan(self.thresholdpos) :
            logging.getLogger(__name__).warning(f"Could not isolate threshold for spike {self.idx} in frame {self.fidx}")
            self.complete=False
            self.thresholdpos=np.nan
            self.threshold=np.nan
            self.amplitude=np.nan
            self.halfwidth=np.nan
            self.hwpos=[np.nan,np.nan]
            #self.ahp=None ## will be overriden in frame analysis
            return
        else:
            self.complete=True
            self.thresholdpos=int(self.thresholdpos)
            self.threshold=volts[self.thresholdpos]
            self.amplitude=self.peak-self.threshold
            ## position and value for half width 
            ## could be more precise here: we could find the exact time at which the signal crosses zero (),
            ## instead of first point before a zero crossing event occurs
            self.halfvoltage=self.peak-(self.peak-self.threshold)/2
            hwsignal=signal.V(self.time-pre,self.time+post)-self.halfvoltage
            self.hwpos=np.where(np.diff(np.signbit(hwsignal)))[0]
            self.hwpos[0]+=self.pos-int(pre*signal._sampling_rate)
            self.hwpos[1]+=self.pos-int(pre*signal._sampling_rate)
            self.halfwidth=float((self.hwpos[1]-self.hwpos[0])/signal._sampling_rate)            

class ivframe(baseframe):
    bitmask_ALL=0xFFFF          ## reprocess time constant
    bitmask_TC =1<<0            ## reprocess time constant
    bitmask_SPIKES =1<<1        ## reprocess time constant
    def __init__(self,sig,idx,parent,current=None):
        self.voltage=sig
        self.idx=idx
        if current==None:
            self.current=cfg.IV_CURRENT_STEPS[self.idx]
        else:
            self.current=current
        ## membrane time constant fit:
        ## each frame keeps its own settings
        self.fitter=None
        self.fitstart=cfg.IV_TCFIT_START
        self.fitstop=-1 if cfg.IV_TCFIT_AUTOSTOP else cfg.IV_TCFIT_STOP
        ## no spike for now
        self.spikes=[]
        super(ivframe,self).__init__(idx,parent)

    def process(self,bitmask=0xFFFF):
        ## baseline,resistance, sagratio
        self.baseline=np.mean(self.voltage.V(cfg.IV_BASELINE_START,cfg.IV_BASELINE_STOP))
        self.sagpeak=np.min(self.voltage.V(cfg.IV_SAG_PEAK_START,cfg.IV_SAG_PEAK_STOP))
        self.sagss=np.mean(self.voltage.V(cfg.IV_SAG_SS_START,cfg.IV_SAG_SS_STOP))
        self.sagratio=(self.baseline-self.sagss)/(self.baseline-self.sagpeak) if self.current<0 else None
        self.sagratio_pct=(self.sagss-self.sagpeak)/(self.baseline-self.sagss)*100 if self.current<0 else None
        self.resistance=(self.baseline-self.sagpeak)/self.current if self.current!=0 else None
        
        ##other analyses are in separated funcs
        if bitmask & ivframe.bitmask_TC and self.current<=cfg.IV_TCFIT_THRESHOLD:
            self.process_tc()
        if bitmask & ivframe.bitmask_SPIKES:
            self.process_spikes()
            self.process_firingpattern()
            self.process_sfa()

    def process_tc(self):
        ##if required, try to determine the end of fitting region
        if self.fitstop==-1:
            self.fitstop=float(np.argmin(self.voltage.V(cfg.IV_CURRENT_INJECTION_START,cfg.IV_CURRENT_INJECTION_STOP))/float(self.voltage.sampling_rate)+cfg.IV_CURRENT_INJECTION_START)
            self.fitstop=float(np.min([self.fitstop,cfg.IV_CURRENT_INJECTION_START+(cfg.IV_TCFIT_STOP-cfg.IV_TCFIT_START)*1.2]))
        times=self.voltage.s(self.fitstart,self.fitstop)
        volts=self.voltage.V(self.fitstart,self.fitstop)
        self.fitter=xyfitter(times,volts,cfg.IV_TCFIT_ORDER,cfg.IV_TCFIT_WEIGHTED_AVERAGE,self.fitstart)
        ## computed fitted curve till the end of current pulse
        if self.fitter.success:
            self.fitline=[               self.voltage.s(cfg.IV_CURRENT_INJECTION_START,cfg.IV_CURRENT_INJECTION_STOP),
                        self.fitter.line(self.voltage.s(cfg.IV_CURRENT_INJECTION_START,cfg.IV_CURRENT_INJECTION_STOP))]
        
    def process_spikes(self):
        ## convenient variables to simplify writing...
        times=self.voltage.s()
        volts=self.voltage.V()
        sr=int(self.voltage.sampling_rate)
        ## detect peaks
        peak_pos,peak_infos=scipy.signal.find_peaks(volts, \
                                    height=cfg.IV_SPIKE_MIN_PEAK,\
                                    prominence=cfg.IV_SPIKE_MIN_AMP,\
                                    #width=(int(0.0001*sr),int(0.05*sr)),\
                                    distance=int(cfg.IV_SPIKE_MIN_INTER*sr),\
                                    )

        ## make sure we do not have a spike at the beginning or at the end of frame (in which case we could not take pre and post points)
        skipstart=cfg.IV_SPIKE_PRE_TIME*sr
        skipend=len(self.voltage)-cfg.IV_SPIKE_POST_TIME*sr
        peak_pos=[p for p in peak_pos if p>skipstart and p<skipend]
        ## try to determine baseline
        self.ahpbaseline=self._try_guess_ahp_baseline(peak_pos)
        ## build the list of spikes
        if cfg.ITSQ_ENABLE_MULTIPROCESSING and len(peak_pos)>100:
            from multiprocessing import Pool
            with Pool() as pool:
                star_peak_pos=[(self.voltage,p,e,self.idx,self.ahpbaseline)   for e,p in enumerate(peak_pos) ]
                self.spikes=pool.starmap(spike,star_peak_pos,)
        else:
            self.spikes=[  spike(self.voltage,p,e,self.idx,self.ahpbaseline)   for e,p in enumerate(peak_pos) ]
        ## make list of evoked and rebound spikes and save attribute in spike object
        self.reboundspikes=[s for s in self.spikes if s.time>cfg.IV_CURRENT_INJECTION_STOP and self.current<0]
        self.evokedspikes=[s for s in self.spikes if cfg.IV_CURRENT_INJECTION_START<s.time<cfg.IV_CURRENT_INJECTION_STOP and self.current>=cfg.IV_SPIKE_EVOKED_THRESHOLD]
        for s in self.reboundspikes:
            s.rebound=True
        for s in self.evokedspikes:
            s.evoked=True
        ## calculate interspike interval
        for e,s in enumerate(self.evokedspikes):
            s.ISI=s.time-cfg.IV_CURRENT_INJECTION_START if e==0 else s.time-self.evokedspikes[e-1].time
        ## for evoked spikes, extract minimum following spike, aka ahp
        ahp_spikes=[s for s in self.evokedspikes if s.complete]
        for e,s in enumerate([s for s in self.evokedspikes]):
            if e<(len(self.evokedspikes)-1): ##we are sure that there will be another spike after
                s.ahppos=s.pos+np.argmin(   self.voltage.V(s.time,min(s.time+0.05,self.evokedspikes[e+1].time))  ) ## this line crashes
                s.ahp=self.ahpbaseline-volts[s.ahppos]
            else:
                s.ahppos=s.pos+np.argmin(   self.voltage.V(s.time,min(s.time+0.05,cfg.IV_CURRENT_INJECTION_STOP))    )
                s.ahp=self.ahpbaseline-volts[s.ahppos]
        ## end of spikes processing. store meta information for drawing
        self.meta={}
        self.meta['maxriseV']=   {'x': times[[s.maxrisepos for s in self.spikes]],\
                                  'y':volts[[s.maxrisepos for s in self.spikes]] }
        self.meta['maxrisedV']=  {'x': times[[s.maxrisepos for s in self.spikes]],\
                                  'y':[s.maxrise for s in self.spikes] }
        self.meta['maxfallV']=   {'x': times[[s.maxfallpos for s in self.spikes]],\
                                  'y':volts[[s.maxfallpos for s in self.spikes]] }
        self.meta['peak']=       {'x':[s.time for s in self.spikes],\
                                  'y':[s.peak for s in self.spikes] }
        self.meta['threshold']=  {'x':times[[s.thresholdpos for s in self.spikes if s.complete]],\
                                  'y':[s.threshold for s in self.spikes  if s.complete]}
        self.meta['hwstart']=    {'x':times[[s.hwpos[0] for s in self.spikes  if s.complete]],\
                                  'y':volts[[s.hwpos[1] for s in self.spikes  if s.complete]]}
        self.meta['hwstop']=     {'x':times[[s.hwpos[1] for s in self.spikes  if s.complete]], \
                                  'y':volts[[s.hwpos[1] for s in self.spikes  if s.complete]]}
        self.meta['ahp']=        {'x':times[[s.ahppos for s in self.evokedspikes  if s.complete]],\
                                  'y':[self.ahpbaseline-s.ahp for s in self.evokedspikes  if s.complete]}
    
    def _try_guess_ahp_baseline(self,pp):
            sr=int(self.voltage.sampling_rate)
            basesignal=self.voltage.V()
            basesignal[0:int(cfg.IV_CURRENT_INJECTION_START*sr)]=np.nan
            basesignal[int(cfg.IV_CURRENT_INJECTION_STOP*sr):]=np.nan
            for p in pp:
                basesignal[p-int(cfg.IV_SPIKE_PRE_TIME*sr):p+int(cfg.IV_SPIKE_POST_TIME*sr)]=np.nan
            return np.nanmean(basesignal)

    def process_firingpattern(self):
        '''pattern classification according to candelas et al.
        https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3424761/ (Tadros, 2012)
        https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1665382/ (graham, 2004)
        Single spike     : less than 2 AP/pulse - and both AP within the first 250ms
        Delayed          : first latency>95 ms and spiking frequency>8Hz within the  first 5 spikes
        Transient        : last spike time<1.4s - and number of spikes>3. 1.4 s seems very late to me (say 1s)
        Gap firing       : latency>95ms and avg frequency(1-8)<8Hz
        Regular tonic    : tonic and SEM ap frequency (1-4)<2
        Irregular tonic  : tonic and SEM ap frequency (1-4)>2
        Gap firing       : latency>95ms and avg frequency(1-8)<8Hz
        the above classification fails when there is an isolated spike in the middle of the frame
        I just added a special case to classify these cells as "delayed"
        '''
        def freq(spikes):
            return (len(spikes)-1)/(spikes[-1].time-spikes[0].time)
        def sem(spikes):
            return scipy.stats.sem(np.diff([s.time for s in spikes]))

        self.pattern="Undetermined"
        if self.current<=0:
           self.pattern=None
        if len([s for s in self.evokedspikes])==0:
            self.pattern=="silent" ## obviously!
        elif len([s for s in self.evokedspikes])<=2 and max([s.time-cfg.IV_CURRENT_INJECTION_START for s in self.evokedspikes])<0.125:
            self.pattern=p="single" ## strange that doublet spiking are indeed considered as single spiking
        elif len([s for s in self.evokedspikes])>=5 and min([s.time-cfg.IV_CURRENT_INJECTION_START for s in self.evokedspikes])>0.1:
            self.pattern=="delayed"## 
        elif len([s for s in self.evokedspikes])>=3 and max([s.time-cfg.IV_CURRENT_INJECTION_START for s in self.evokedspikes])<1.0:
            self.pattern="transient"
        elif len([s for s in self.evokedspikes])>=3 and min([s.time-cfg.IV_CURRENT_INJECTION_START for s in self.evokedspikes])>0.095 and freq(self.evokedspikes[:8])<8.0:
            self.pattern="gap"
        elif len([s for s in self.evokedspikes])>=3 and sem(self.evokedspikes[:4])>2:
            self.pattern="tonic irregular"
        elif len([s for s in self.evokedspikes])>=3 and sem(self.evokedspikes[:4])<2:
            self.pattern="tonic regular"

    def process_sfa(self):
        if len(self.evokedspikes)<cfg.IV_MIN_SPIKES_FOR_SFADAPT:
            self.sfa_freq_lin=None
            self.sfa_freq_log=None
            self.sfa_freq_div=None
            self.sfa_peak_lin=None
            self.sfa_peak_log=None
            self.sfa_peak_div=None
        else:
            ## for intervals
            y=[s.ISI for s in self.evokedspikes[1:] ]
            x=list(range(len(y)))
            self.sfa_freq_lin, self.freq_intercept_lin, r_value_lin, p_value_lin, std_err_lin = scipy.stats.linregress(x,y)
            self.sfa_freq_log, self.freq_intercept_log, r_value_log, p_value_log, std_err_log = scipy.stats.linregress(x,np.log(y))
            self.sfa_freq_div =self.evokedspikes[-1].ISI/self.evokedspikes[1].ISI
            ## for peaks
            y=[s.peak for s in self.evokedspikes[1:] ]
            x=list(range(len(y)))
            self.sfa_peak_lin, self.peak_intercept_lin, r_value_lin, p_value_lin, std_err_lin = scipy.stats.linregress(x,y)
            self.sfa_peak_log, self.peak_intercept_log, r_value_log, p_value_log, std_err_log = scipy.stats.linregress(x,np.log(y))
            self.sfa_peak_div =self.evokedspikes[-1].peak/self.evokedspikes[1].peak

    def activate(self):
        self._get_cursor(0).setpos(self.fitstart)
        self._get_cursor(1).setpos(self.fitstop)

    def charts(self,*args,**kwargs):
        fig,ax=plt.subplots(2,3)
        a00,a01,a02,a10,a11,a12=ax[0][0],ax[0][1],ax[0][2],ax[1][0],ax[1][1],ax[1][2]
        a00.plot(self.spikes[0].PPV,self.spikes[0].PPdV)
        for s in self.spikes[1:]:
            a00.plot(s.PPV,s.PPdV,color='orange')
        a00.plot(np.mean(np.array([s.PPV for s in self.spikes]),axis=0),
                np.mean(np.array([s.PPdV for s in self.spikes]),axis=0) )
        a00.set(xlabel='Voltage (V)',ylabel='dV (V)',title='Phase plane')
        if len(self.evokedspikes)>=cfg.IV_MIN_SPIKES_FOR_SFADAPT:
            y=[s.ISI for s in self.evokedspikes[1:] ]
            x=list(range(len(y)))
            a01.plot(x, y,"o")
            a01.plot(x, [s*self.sfa_freq_lin+self.freq_intercept_lin for s in x])
            a01.set(xlabel='Spike index',ylabel='Interval',title='Spike Freq delay (lin)')
            a11.plot(x, np.log(y),"o")
            a11.plot(x, [s*self.sfa_freq_log+self.freq_intercept_log for s in x])
            a11.set(xlabel='Spike index',ylabel='Interval',title='Spike Freq delay (log)')
            y=[s.peak for s in self.evokedspikes[1:] ]
            a02.plot(x, y,"o")
            a02.plot(x, [s*self.sfa_peak_lin+self.peak_intercept_lin for s in x])
            a02.set(xlabel='Spike index',ylabel='Peak',title='Spike Freq peak (lin)')
            a12.plot(x, np.log(y),"o")
            a12.plot(x, [s*self.sfa_peak_log+self.peak_intercept_log for s in x])
            a12.set(xlabel='Spike index',ylabel='Peak',title='Spike Freq peak (log)')
        fig.tight_layout()
        fig.show()

    @once
    def setup(self):
        _fig().subplots(2, 1, gridspec_kw={'height_ratios': [3, 1],"top":0.9},sharex = True)
        testbtn=TriggerBtn(_fig(),"charts",'alt+c',str(Path(__file__).parent/'resources/fa-linechart-solid.png'),'Chart graphics',
                    lambda *args,**kwargs:self.parent.currentframe().charts(*args,**kwargs))
        self._cursor(_axes(),'v',self.fitstart,
                    #lambda x:self.parent.currentframe().__setattr__('fitstart',x) or self.parent.process(ivframe.bitmask_TC) or self.parent.draw (False)
                    lambda x:self._update_local('fitstart',x) or self.parent.process(ivframe.bitmask_TC) or self.parent.draw (False)
                    )
        self._cursor(_axes(),'v',self.fitstop,
                    #lambda x:self.parent.currentframe().__setattr__('fitstop',x) or self.parent.process(ivframe.bitmask_TC) or self.parent.draw (False)
                    lambda x:self._update_local('fitstop',x) or self.parent.process(ivframe.bitmask_TC) or self.parent.draw (False)
                    )
        self._cursor(_axes(0),'h',cfg.IV_SPIKE_MIN_PEAK,
                    lambda x:cfg.set('IV_SPIKE_MIN_PEAK',x) or self.parent.process(ivframe.bitmask_SPIKES) or self.parent.draw (False)
                    )
        self._cursor(_axes(0),'h',cfg.IV_SPIKE_MIN_PEAK-cfg.IV_SPIKE_MIN_AMP,
                    lambda x:cfg.set('IV_SPIKE_MIN_AMP',cfg.IV_SPIKE_MIN_PEAK-x) or self.parent.process(ivframe.bitmask_SPIKES) or self.parent.draw (False)
                    )
        self._cursor(_axes(1),'h',cfg.IV_SPIKE_DV_THRESHOLD,
                    lambda x:cfg.set('IV_SPIKE_DV_THRESHOLD',x) or self.parent.process(ivframe.bitmask_SPIKES) or self.parent.draw (False)
                    )

    def draw(self,drawall=True):
        self.setup() ## ensure that axes are ready!
        _fig().canvas.set_window_title(f"IV/Spontaneous firing protocol {self.current}pA")
        title=''
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            aa=len(self.voltage)<200e3
            _axes(0).plot(self.voltage.s(), self.voltage.V(),color='blue', gid='traces',aa=aa)
            _axes(1).plot(self.voltage.s(),np.gradient(self.voltage.V()), color='green',gid='traces',aa=aa)
            _axes(1).plot(self.voltage.s(),np.gradient(np.gradient(self.voltage.V())), color='orange',gid='traces',aa=aa)
            _autoscale(_axes(0),self.voltage.s(),self.voltage.V())
        self._clf(['markers'])
        _axes(0).axhline(self.baseline,color="grey",linestyle ="--",gid='markers')
        if self.current<0: ## for negative current, plot sagss and sagpeak
            title+=f'sagratio: {self.sagratio:.2f} '
            _axes(0).axhline(self.sagss,color="blue",linestyle ="--",gid='markers')
            _axes(0).axhline(self.sagpeak,color="orange",linestyle ="--",gid='markers')
        if self.fitter and self.fitter.success and self.current<=cfg.IV_TCFIT_THRESHOLD: ##plot fitter if fitting was successful  (or if fitter esists)
            title+=f'TC: {_pprint(self.fitter.tc,pq.s)} '
            _axes(0).plot( self.fitline[0], self.fitline[1],color='red',gid='markers')
        ## plot spike keypoints
        _axes(0).plot(self.meta['peak']['x'],self.meta['peak']['y'],"x",color="red",gid="markers")
        _axes(0).plot(self.meta['maxriseV']['x'],self.meta['maxriseV']['y'],"o",color="orange",gid="markers")
        _axes(0).plot(self.meta['threshold']['x'],self.meta['threshold']['y'],"+",color="red",gid="markers")
        _axes(0).plot(self.meta['hwstart']['x'],self.meta['hwstart']['y'],"3",color="red",gid="markers")
        _axes(0).plot(self.meta['hwstop']['x'],self.meta['hwstop']['y'],"4",color="red",gid="markers")
        _axes(0).plot(self.meta['ahp']['x'],self.meta['ahp']['y'],"+",color="purple",gid="markers")
        _axes(0).set_title(title)

class ivprotocol(baseprotocol):
    def __init__(self,sigs,interactive):
        self.frames=[ivframe(s,idx=e,parent=self) for e,s in enumerate(sigs) ]
        super(ivprotocol,self).__init__(interactive)
    def provides(self):
        r={'IV_baseline':'average baseline (all frames).',
                'IV_resistance':'average resistance (frames with sag_ratio>0.95).',
                'IV_tc':'average time constant (frames with injected current<IV_TCFIT_THRESHOLD).',
                f'IV_sagratio_I={cfg.IV_SAG_TARGET_CURRENT}pA':'sag ratio (base-ss)/(base-peak) for IV_SAGRATIO_TGT_CURRENT amplitude.',
                f'IV_sagratio_I={cfg.IV_SAG_TARGET_CURRENT}pA_pct':'(ss-peak)/(base-ss)*100 for for IV_SAGRATIO_TGT_CURRENT amplitude.',
                f'IV_sagratio_tgt={cfg.IV_SAG_SS_TARGET_VOLTAGE}V':'sag ratio (base-ss)/(base-peak) for frame with baseline-steadystate closest to IV_SAGRATIO_TGT_VOLTAGE.',
                f'IV_sagratio_tgt={cfg.IV_SAG_SS_TARGET_VOLTAGE}V_pct':'(ss-peak)/(base-ss)*100 for frame with baseline-steadystate closest to IV_SAGRATIO_TGT_VOLTAGE.',
                'IV_rheobase':'current required to observe a spike between cfg.IV_CURRENT_INJECTION_START and cfg.IV_CURRENT_INJECTION_STOP.',
                'IV_avg_spike_threshold':'spike threshold. computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_avg_spike_peak':'spike peak. computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_avg_spike_amplitude':'spike amplitude (=peak-threshold). computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_avg_spike_half_width':'spike half width (at (peak-threshold)/2). computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_avg_spike_max_rise_slope':'spike maximum rise slope. computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_avg_spike_max_fall_slope':'spike maximum fall slope. computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_avg_spike_ahp':'spike ahp. computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_first_spike_interval':'interspike interval for two first spikes. computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_last_spike_interval':'interspike interval for two last spikes. computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_first_div_last_spike_interval':'ratio between first and last spike intervals. computed on first frame with more than cfg.IV_MIN_SPIKES_FOR_MEASURE spikes.',
                'IV_sfa_freq_lin':'spike frequency adaptation of spike intervals - linear fit. computed on spike with the more spikes if number of spikes > cfg.IV_MIN_SPIKES_FOR_SFADAPT.',
                'IV_sfa_freq_log':'spike frequency adaptation of spike intervals - log fit. computed on spike with the more spikes if number of spikes > cfg.IV_MIN_SPIKES_FOR_SFADAPT.',
                'IV_sfa_freq_div':'spike frequency adaptation of spike intervals - quotient. computed on spike with the more spikes if number of spikes > cfg.IV_MIN_SPIKES_FOR_SFADAPT.',
                'IV_sfa_peak_lin':'spike frequency adaptation of spike peak - linear fit. computed on spike with the more spikes if number of spikes > cfg.IV_MIN_SPIKES_FOR_SFADAPT.',
                'IV_sfa_peak_log':'spike frequency adaptation of spike peak - log fit. computed on spike with the more spikes if number of spikes > cfg.IV_MIN_SPIKES_FOR_SFADAPT.',
                'IV_sfa_peak_div':'spike frequency adaptation of spike peak - quotient. computed on spike with the more spikes if number of spikes > cfg.IV_MIN_SPIKES_FOR_SFADAPT.',
                'IV_firing_pattern':'spike firing pattern. buggy and meaningless',
                }
        for c in cfg.IV_CURRENT_STEPS:
            r.update({f'IV_evoked_spikes_({c})pA':f'number of evoked spikes for {c}pA injected current.'})
        for c in cfg.IV_CURRENT_STEPS:
            r.update({f'IV_rebound_spikes_({c})pA':f'number of rebound spikes for {c}pA injected current.'})
        return r

    def results(self):
        self.r={}
        self.r['IV_baseline']                                        =np.nanmean([f.baseline for f in self.frames if f.enabled ]) / cfg.OUTPUT_V_SCALE
        self.r['IV_resistance']                                      =np.nanmean([f.resistance for f in self.frames if f.current<0 and f.sagratio>0.95 and f.enabled]) / cfg.OUTPUT_OHM_SCALE
        self.r['IV_tc']=np.nanmean([f.fitter.tc for f in self.frames if f.current<cfg.IV_TCFIT_THRESHOLD and f.enabled]) / cfg.OUTPUT_S_SCALE
        self.r[f'IV_sagratio_I={cfg.IV_SAG_TARGET_CURRENT}pA']           =np.nanmean([f.sagratio for f in self.frames if f.current==cfg.IV_SAG_TARGET_CURRENT and f.enabled])
        self.r[f'IV_sagratio_I={cfg.IV_SAG_TARGET_CURRENT}pA_pct']       =np.nanmean([f.sagratio_pct for f in self.frames if f.current==cfg.IV_SAG_TARGET_CURRENT and f.enabled])
        frames_for_sag=sorted([f for f in self.frames if f.enabled],key=lambda f:np.fabs((f.baseline-f.sagss)-cfg.IV_SAG_SS_TARGET_VOLTAGE))
        self.r[f'IV_sagratio_tgt={cfg.IV_SAG_SS_TARGET_VOLTAGE}V']       =frames_for_sag[0].sagratio
        self.r[f'IV_sagratio_tgt={cfg.IV_SAG_SS_TARGET_VOLTAGE}V_pct']   =frames_for_sag[0].sagratio_pct
        frames_with_evoked_spikes=[f for f in self.frames if f.current>=0 and len(f.evokedspikes)>0 and f.enabled]
        if len(frames_with_evoked_spikes)>0:
            self.r[f'IV_rheobase']=frames_with_evoked_spikes[0].current/1.0e12 / cfg.OUTPUT_A_SCALE
        ##
        frames_with_min_spikes=[f for f in self.frames if len(f.evokedspikes)>=cfg.IV_MIN_SPIKES_FOR_MEASURE and f.enabled]
        if len(frames_with_min_spikes)>0:
            reference_frame=frames_with_min_spikes[0]
            self.r['IV_avg_spike_threshold']                 =np.nanmean([s.threshold for s in reference_frame.evokedspikes]) / cfg.OUTPUT_V_SCALE
            self.r['IV_avg_spike_peak']                      =np.nanmean([s.peak for s in reference_frame.evokedspikes]) / cfg.OUTPUT_V_SCALE
            self.r['IV_avg_spike_amplitude']                 =np.nanmean([s.amplitude for s in reference_frame.evokedspikes]) / cfg.OUTPUT_V_SCALE
            self.r['IV_avg_spike_half_width']                =np.nanmean([s.halfwidth for s in reference_frame.evokedspikes]) / cfg.OUTPUT_S_SCALE
            self.r['IV_avg_spike_max_rise_slope']            =np.nanmean([s.maxrise for s in reference_frame.evokedspikes]) / cfg.OUTPUT_S_SCALE
            self.r['IV_avg_spike_max_fall_slope']            =np.nanmean([s.maxfall for s in reference_frame.evokedspikes]) / cfg.OUTPUT_S_SCALE
            self.r['IV_avg_spike_ahp']                       =np.nanmean([s.ahp for s in reference_frame.evokedspikes if s.complete ]) / cfg.OUTPUT_V_SCALE
            self.r['IV_first_spike_interval']                =reference_frame.evokedspikes[1].ISI / cfg.OUTPUT_S_SCALE
            self.r['IV_last_spike_interval']                 =reference_frame.evokedspikes[-1].ISI / cfg.OUTPUT_S_SCALE
            self.r['IV_first_div_last_spike_interval']       =self.r['IV_first_spike_interval']/self.r['IV_last_spike_interval']
        frames_with_max_spikes=sorted([f for f in self.frames if len(f.evokedspikes)>cfg.IV_MIN_SPIKES_FOR_SFADAPT and f.enabled],key=lambda f:len(f.evokedspikes))
        if len(frames_with_max_spikes)>0:
            self.r['IV_sfa_freq_lin']                        =frames_with_max_spikes[-1].sfa_freq_lin
            self.r['IV_sfa_freq_log']                        =frames_with_max_spikes[-1].sfa_freq_log
            self.r['IV_sfa_freq_div']                        =frames_with_max_spikes[-1].sfa_freq_div
            self.r['IV_sfa_peak_lin']                        =frames_with_max_spikes[-1].sfa_peak_lin
            self.r['IV_sfa_peak_log']                        =frames_with_max_spikes[-1].sfa_peak_log
            self.r['IV_sfa_peak_div']                        =frames_with_max_spikes[-1].sfa_peak_div
        for f in self.frames:
            self.r[f'IV_evoked_spikes_({f.current})pA']     =len(f.evokedspikes)
        for f in self.frames:
            self.r[f'IV_rebound_spikes_({f.current})pA']     =len(f.reboundspikes)
        frames_with_max_spikes=sorted(self.frames,key=lambda f:len(f.evokedspikes))
        self.r['IV_firing_pattern']                          =frames_with_max_spikes[-1].pattern
        return self.r

class spontaneousactivityprotocol(baseprotocol):
    def __init__(self,sigs,interactive):
        ## awfull hack here:
        ## ivframe calculates baseline for  AHP between cfg.IV_CURRENT_INJECTION_START and cfg.IV_CURRENT_INJECTION_STOP
        ## as we want to take baseline for all trace, we save these values for later restoration, and update the values...
        ## may not be necessary as params are reparsed before every protocol analysis...
        #oldstart, oldstop= cfg.IV_CURRENT_INJECTION_START, cfg.IV_CURRENT_INJECTION_STOP
        cfg.IV_CURRENT_INJECTION_START, cfg.IV_CURRENT_INJECTION_STOP=0, sigs[0].times.magnitude.flatten()[-1]
        self.frames=[ivframe(s,idx=0,parent=self,current=0) for e,s in enumerate(sigs) ]
        super(spontaneousactivityprotocol,self).__init__(interactive)
    def provides(self):
        return {'SPON_baseline':'average baseline.',
                'SPON_frequency':'average frequency.',
                'SPON_avg_spike_threshold':'spike threshold.',
                'SPON_avg_spike_peak':'spike peak.',
                'SPON_avg_spike_amplitude':'spike amplitude (=peak-threshold).',
                'SPON_avg_spike_half_width':'spike half width (at (peak-threshold)/2).',
                'SPON_avg_spike_max_rise_slope':'spike maximum rise slope.',
                'SPON_avg_spike_max_fall_slope':'spike maximum fall slope.',
                'SPON_avg_spike_ahp':'spike ahp.',
                }

    def results(self):
        self.r={}
        self.r['SPON_baseline']=self.frames[0].ahpbaseline/cfg.OUTPUT_V_SCALE
        self.r['SPON_frequency']=len(self.frames[0].spikes)/(cfg.IV_CURRENT_INJECTION_STOP - cfg.IV_CURRENT_INJECTION_START)
        if len(self.frames[0].spikes)>0:
            self.r['SPON_avg_spike_threshold']=np.nanmean([s.threshold for s in self.frames[0].spikes])/cfg.OUTPUT_OHM_SCALE
            self.r['SPON_avg_spike_peak']=np.nanmean([s.peak for s in self.frames[0].spikes])/cfg.OUTPUT_V_SCALE
            self.r['SPON_avg_spike_amplitude']=np.nanmean([s.amplitude for s in self.frames[0].spikes])/cfg.OUTPUT_V_SCALE
            self.r['SPON_avg_spike_half_width']=np.nanmean([s.halfwidth for s in self.frames[0].spikes])/cfg.OUTPUT_S_SCALE
            self.r['SPON_avg_spike_max_rise_slope']=np.nanmean([s.maxrise for s in self.frames[0].spikes])
            self.r['SPON_avg_spike_max_fall_slope']=np.nanmean([s.maxfall for s in self.frames[0].spikes])
            self.r['SPON_avg_spike_ahp']=np.nanmean([s.ahp for s in self.frames[0].spikes if s.complete])/cfg.OUTPUT_V_SCALE
        return self.r

class foldernameprotocol:
    def __init__(self,fpath, interactive=True):
        self.r={'_FOLD_fullpath':None,'_FOLD_filename':None}
        if os.path.isfile(fpath):
            self.r['_FOLD_filename']=Path(fpath).name
            fpath=str(Path(fpath).parent)
        if os.path.isdir(fpath):
            self.r['_FOLD_filename']=Path(fpath).name
            self.fpath=fpath
    def provides(self):
        keys=cfg.FOLDER_NAMING_SCHEME.split(cfg.FOLDER_NAMING_SEP)
        r={'_FOLD_fullpath':'fullpath to folder',
           '_FOLD_filename':'the file or folder name'}
        r.update({'_FOLD_'+k:'no description' for k in keys})
        return r
    def results(self):
        keys=cfg.FOLDER_NAMING_SCHEME.split(cfg.FOLDER_NAMING_SEP)
        try:
            values=str(Path(self.fpath).name).split(cfg.FOLDER_NAMING_SEP)
            self.r.update({'_FOLD_'+k:v for k,v in zip(keys,values)})
        except:
            logging.getLogger(__name__).warning("Inconsistent folder naming. Check cfg.FOLDER_NAMING_SCHEME and cfg.FOLDER_NAMING_SEP values")
            self.r.update({'_FOLD_'+k:None for k in keys })
            self.r.update({'_FOLD_fullpath':self.fpath})
        return self.r

class resonnanceframe(baseframe):
    def __init__(self,sig,current,idx, parent):
        self.voltage=sig
        self.current=current
        super(resonnanceframe,self).__init__(idx,parent)
    
    def process(self,bitmask=0xFFFF):
        volts=self.voltage.V()
        ref=self.current.A()
        self.sig_freq,self.sig_pow=scipy.signal.periodogram(volts,fs=self.voltage._sampling_rate)
        self.ref_freq,self.ref_pow=scipy.signal.periodogram(ref,fs=self.current._sampling_rate)
        ## but floating point divisions with numbers in 10e-6/10e-24 range seems to mess up python!
        ## convert to mV and pA 
        self.ref_pow*=1e24 ## 1pA**2
        self.sig_pow*=1e6  ## 1mV**2

        self.impedence=self.sig_pow/self.ref_pow
        self.keep=np.where((self.sig_freq<cfg.RES_HIGH_BAND)&(self.sig_freq>cfg.RES_LOW_BAND))
        self.res_pos=np.argmax(self.impedence[self.keep])
        self.res_freq=float(self.ref_freq[self.keep][self.res_pos])
        self.res_imp=float(self.impedence[self.keep][self.res_pos])
    
    @once
    def setup(self):
        _fig().subplots(3, 1,sharex = True)

    def draw(self,drawall=True):
        self.setup() ## ensure that axes are ready!
        _fig().canvas.set_window_title("Resonnance protocol")
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            _axes(0).loglog(self.sig_freq[self.keep],self.sig_pow[self.keep])
            _axes(1).loglog(self.ref_freq[self.keep],self.ref_pow[self.keep])
            _axes(2).loglog(self.ref_freq[self.keep],self.impedence[self.keep])
        self._clf(['markers'])
        _axes(2).loglog([self.res_freq],self.res_imp,'o')

class resonnanceprotocol(baseprotocol):
    def __init__(self,sigs,interactive):
        self.frames=[ resonnanceframe(sigs[0],sigs[1],idx=0,parent=self)  ]
        super(resonnanceprotocol,self).__init__(interactive)
    def provides(self):
        return {'RES_resonnance':'resonnance frequency',
                'RES_impedance':'impedence of neurone at resonnance frequency'}
    def results(self):
        self.r= {'RES_resonnance':float(self.frames[0].res_freq),
                'RES_Impedance':1e6*float(self.frames[0].res_imp*1000)/cfg.OUTPUT_OHM_SCALE}
        return self.r


class rampframe(baseframe):
    def __init__(self,sig,voltage,idx, parent):
        self.current=sig
        self.voltage=voltage
        super(rampframe,self).__init__(idx,parent)
    
    def process(self,bitmask=0xFFFF):
        volts=self.voltage.V()
        amps=self.current.A()
        self.fitter1=xyfitter(self.current.s(cfg.RAMP_BOUNDARIES[0],cfg.RAMP_BOUNDARIES[0]+0.2),
                              self.current.pA(cfg.RAMP_BOUNDARIES[0],cfg.RAMP_BOUNDARIES[0]+0.2),
                                            0,True)
        times1=self.current.s(cfg.RAMP_BOUNDARIES[0],cfg.RAMP_BOUNDARIES[1])
        self.line1=[times1,self.fitter1.line(times1)]
        self.fitter2=xyfitter(self.current.s(cfg.RAMP_BOUNDARIES[1]-0.2,cfg.RAMP_BOUNDARIES[1]),
                              self.current.pA(cfg.RAMP_BOUNDARIES[1]-0.2,cfg.RAMP_BOUNDARIES[1]),
                                            0,True)
        times2=self.current.s(cfg.RAMP_BOUNDARIES[0],cfg.RAMP_BOUNDARIES[1])
        self.line2=[times2,self.fitter2.line(times2)]

    @once
    def setup(self):
        _fig().subplots(2, 1,gridspec_kw={'height_ratios': [3, 1],"top":0.9},sharex = True)

    def draw(self,drawall=True):
        self.setup() ## ensure that axes are ready!
        _fig().canvas.set_window_title("Resonnance protocol")
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            _axes(0).plot(self.current.s(),self.current.pA(),gid='traces')
            _axes(1).plot(self.voltage.s(),self.voltage.mV(),gid='traces')
        self._clf(['markers'])
        if self.fitter1.success:
           _axes(0).plot(*self.line1,gid='markers')
        if self.fitter2.success:
           _axes(0).plot(*self.line2,gid='markers')

class rampprotocol(baseprotocol):
    def __init__(self,sigs,interactive):
        self.frames=[ rampframe(sig[0],sig[1],idx=0,parent=self) for sig in sigs ]
        super(rampprotocol,self).__init__(interactive)
    def provides(self):
        return {'RAMP_slope_-40':'slope at Vhold=-40mV (pA/s)',
                'RAMP_slope_-120':'slope at Vhold=-120mV (pA/s)',
                'RAMP_iorect_40_over_120':'ratio of the slopes',
                }
    def results(self):
        self.r= {'RAMP_slope_-40':np.nanmean([f.fitter1.a for f in self.frames if f.enabled]),
                 'RAMP_slope_-120':np.nanmean([f.fitter2.a for f in self.frames if f.enabled]),
                 'RAMP_iorect_40_over_120':np.nanmean([f.fitter1.a/f.fitter2.a for f in self.frames if f.enabled]),
                }
        return self.r
##################################################################################################
##################################################################################################
##################################################################################################
## END OF PROTOCOLS SECTION
##################################################################################################
##################################################################################################
##################################################################################################

##################################################################################################
##################################################################################################
##################################################################################################
## PREPROCESS AND DISPATCH FILES
##################################################################################################
##################################################################################################
##################################################################################################

def process_file(inpath):
    cfg.parse(Path(__file__).resolve().parent/"params"/("generic_params.py"))
    neuronprops={}
    protocol=None
    if str(Path(inpath).name)[0] in cfg.ITSQ_SKIP_FILES:
        logging.getLogger(__name__).info(f"Skipping file {str(inpath)}")
        return {}
    myexp=Experiment(inpath)
    protocolname=myexp.protocol.name
    logging.getLogger(__name__).info(f"{protocolname} : {str(inpath)}")
    if any([fnmatch.fnmatch(protocolname,x) for x in cfg.IV_PROTOCOL_NAMES])  and 'iv' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            cfg.IV_CURRENT_INJECTION_START=myexp.protocol.ascurrentsteps()['steps'][0]['start']
            cfg.IV_CURRENT_INJECTION_STOP=myexp.protocol.ascurrentsteps()['steps'][0]['stop']
            cfg.IV_CURRENT_STEPS=[step['lvl'] for step in myexp.protocol.ascurrentsteps()['steps'] ]
        ## detect start and stop. not heavily tested, but should be ok for simple square pulses
        protocol=ivprotocol(sigs,cfg.IV_DEBUG_FRAME)
        neuronprops.update(protocol.results())
            
    ## processing AHPprotocol protocol 
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.AHP_PROTOCOL_NAMES])  and 'ahp' in cfg.PROCESS_PROTOCOLS :
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        ## read frequency from protocol name
        freqstr=re.search(r'\d*[H,h]z',protocolname,re.MULTILINE)
        if freqstr:
            freq=int(freqstr.group(0)[:-2])
            logging.getLogger(__name__).info(f"AHP Protocol indicates {freq}Hz")
        else:
            logging.getLogger(__name__).warning("Could not extract frequency from AHP protocol")
        ## AF version has one frame, whereas I have many frames... Just keep the last one
        protocol=ahpprotocol([sigs[-1]],cfg.AHP_DEBUG_FRAME)
        ##protocol=ahpprotocol(sigs,cfg.AHP_DEBUG_FRAME,freq)
        neuronprops.update(protocol.results())
        
    ## processing ZAP protocol
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.ZAP_PROTOCOL_NAMES]) and 'resonnance' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        ## quite complex here! on some setups, the current is not recorded, so we have to load an external stimulus file!
        try:
            current=myexp.signal(1)
        except:
            reffilepath=str(Path(__file__).resolve().parent/"resources"/"ZAPCurrent.abf")
            current=Experiment(reffilepath).signal(0)
        assert(sigs[0].sampling_rate==current[0].sampling_rate)
        assert(len(sigs[0])==len(current[0]))
        protocol=resonnanceprotocol([sigs[0],current[0]],True)
        neuronprops.update(protocol.results())

    ## processing Time Constant protocol
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.TC_PROTOCOL_NAMES])  and 'timeconstant' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            cfg.TC_FIT_START=myexp.protocol.ascurrentsteps()['steps'][0]['stop']+0.001
            #cfg.TC_FIT_STOP=myexp.protocol.ascurrentsteps()['steps'][0]['stop'] ##dynamic var
            cfg.TC_FIT_CURRENT_STEPS=myexp.protocol.ascurrentsteps()['steps'][0]['lvl']
        protocol=timeconstantprotocol(sigs,cfg.TC_DEBUG_FRAME)
        neuronprops.update(protocol.results())
    
    ## processing resistance protocol
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.INPUTR_PROTOCOL_NAMES])  and 'resistance' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        ## for resistance, average signals
        avgsig=neo.AnalogSignal( np.mean(np.array([s.magnitude.flatten() for s in sigs]),axis=0),
            units='V', sampling_rate=sigs[0].sampling_rate
            )
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            cfg.INPUTR_CURRENT_INJECTION_START=myexp.protocol.ascurrentsteps()['steps'][0]['start']
            cfg.INPUTR_CURRENT_INJECTION_STOP=myexp.protocol.ascurrentsteps()['steps'][0]['stop']
            cfg.INPUTR_CURRENT_STEP=myexp.protocol.ascurrentsteps()['steps'][0]['lvl']
        protocol=resistanceprotocol([avgsig],cfg.INPUTR_DEBUG_FRAME,currentstep=cfg.INPUTR_CURRENT_STEP)
        neuronprops.update(protocol.results())

    ## spontaneous activity protocol
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.SPONTANEOUS_PROTOCOL_NAMES])  and 'spontaneousactivity' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        protocol=spontaneousactivityprotocol(sigs,cfg.SPONTANEOUS_DEBUG_FRAME)
        neuronprops.update(protocol.results())

    ## ramp activity protocol
    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.RAMP_PROTOCOL_NAMES])  and 'ramp' in cfg.PROCESS_PROTOCOLS:
        cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
        sigs=myexp.signal(0)
        voltage=myexp.signal(1)
        protocol=rampprotocol([ (sigs[e],voltage[e]) for e in range(len(sigs))],cfg.SPONTANEOUS_DEBUG_FRAME)
        neuronprops.update(protocol.results())

    ## unknown protocol/disabled protocol. warn the user
    else:
        logging.getLogger(__name__).warning(f"Unknown / disabled protocol {protocolname}. Check protocol association and PROCESS__ flags.")
    
    if not protocol is None:
        if cfg.ITSQ_PROTOCOL_SAVE_DATA:protocol.savedata(inpath,protocolname)
    
    return neuronprops

def processfolder(fpath):
    ## get meta info from folder
    neuronprops={}
    protocol=foldernameprotocol(fpath)
    neuronprops.update(protocol.results())
    ## search all files with required extension _prefix(cfg.PROCESS_EXTENSIONS,'*')
    allfiles=[f for ext in _prefix(cfg.PROCESS_EXTENSIONS,'*') for f in fpath.glob(ext) ]
    for inpath in allfiles:
        neuronprops.update(process_file(inpath))
    return neuronprops

def process(inpath):
    cfg.parse(Path(__file__).resolve().parent/"params"/"generic_params.py")
    ## start processing
    allneurons=[]
    ## single file
    if Path(inpath).is_file() and Path(inpath).suffix in _prefix(cfg.PROCESS_EXTENSIONS,''):
        neuron={}
        neuron.update(process_file(Path(inpath)))
        allneurons.append(neuron)

    ## folder with files
    if Path(inpath).is_dir():
        if len([f for ext in _prefix(cfg.PROCESS_EXTENSIONS,'*') for f in Path(inpath).glob(ext) ])>0:
            neuron={}
            neuron.update(processfolder(Path(inpath)))
            allneurons.append(neuron)
        else:
            ## folder with mess
            folders=set([f.parents[0] for ext in _prefix(cfg.PROCESS_EXTENSIONS,'**/*') for f in Path(inpath).glob(ext) ])
            for folder in folders:
                neuron={}
                neuron.update(processfolder(folder))
                allneurons.append(neuron)
    ## before we output to csv,excel, ..., we have to make sure that we have exactly the same fields for all neurons
    ## fortunately, pandas takes care of this for us, provided that an index is given
    df=pd.DataFrame(allneurons).T
    ## optionnally read output fields from specified file
    ## python should be easy to read! sorry!
    if cfg.ITSQ_OUTPUT_FIELDS_FILE:
        if (Path(__file__).resolve().parent/cfg.ITSQ_OUTPUT_FIELDS_FILE).is_file():
            outfields=[ l.split("#")[0].rstrip(' \t\n\r').lstrip('+-#')                         \
                        for l in open(Path(__file__).resolve().parent/cfg.ITSQ_OUTPUT_FIELDS_FILE)  \
                        if not ( l.split("#")[0].startswith('-') or \
                                l.split("#")[0].startswith('#') or \
                                len(l.split("#")[0].strip(' \t\n\r')) == 0
                                )
                    ]
        else:
            logging.getLogger(__name__).info("Could not find list of output parametes. Generating one")
            outfields=[ k for pname in cfg.PROCESS_PROTOCOLS for k in globals()[pname+"protocol"].provides(None).keys()]
            with open(Path(__file__).resolve().parent/cfg.ITSQ_OUTPUT_FIELDS_FILE,'w') as outfile:
                outfile.writelines([l+"\n" for l in outfields])
        discarded=[p for p in df.index if not p in outfields]
        for p in discarded:
            logging.getLogger(__name__).warning(f"parameter {p} is rejected by output configuration ")
        df=df.reindex(outfields)

    if cfg.OUTPUT_CSV:        df.to_csv("results.csv",sep=cfg.OUTPUT_CSVSEP)
    if cfg.OUTPUT_JSON:       df.to_json("results.json")
    if cfg.OUTPUT_EXCEL:      df.to_excel("results.xlsx")
    if cfg.OUTPUT_CLIPBOARD:
        if cfg.OUTPUT_CLIPBOARD_ROWNAMES:
            df.to_clipboard(excel=cfg.OUTPUT_CLIPBOARD_EXCEL,index=False)
        else:
            df.iloc[:, 1:].to_clipboard(excel=cfg.OUTPUT_CLIPBOARD_EXCEL,index=False)
            #df.T.iloc[:].to_clipboard(excel=cfg.OUTPUT_CLIPBOARD_EXCEL,index=False) #transposed version
    return df

if __name__=='__main__':
    ##CCSteps,abf, positive and negative
    #ROOTPATH="D:\\data-yves\\labo\\projects\\Patch-Seq-GADGFP\\Cell_Recordings\\20211215_85n\\20211215_85n_0002.abf"
    #ROOTPATH="D:\\data-yves\\labo\\projects\\Patch-Seq-GADGFP\\Cell_Recordings\\20211215_85n\\20211215_85n_0003.abf"
    ##Time constant
    #ROOTPATH="D:\\data-yves\\labo\\devel\\intrinsic\\yukti&clara\\WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell4\\WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell4 004.axgd"
    ##resistance
    #ROOTPATH="D:\\data-yves\\labo\\devel\\intrinsic\\yukti&clara\\WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell4\\WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell4 005.axgd"
    ##AHP_MED
    #ROOTPATH="D:\\data-yves\\labo\\devel\\intrinsic\\yukti&clara\\WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell2\\WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell2 010.axgd"
    ##AHP_SLOW
    #ROOTPATH="D:\\data-yves\\labo\\devel\\intrinsic\\yukti&clara\\WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell2\\WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell2 011.axgd"
    ## IV
    #ROOTPATH="D:\\data-yves\\labo\\devel\\intrinsic\\yukti&clara\\WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell2\\WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell2 001.axgd"
    #ROOTPATH="D:\\data-yves\\labo\\devel\\intrinsic\\yukti&clara\\WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell1\\WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell1 002.axgd"
    ## SPON
    #ROOTPATH="D:\\data-yves\\labo\\devel\\intrinsic\\yukti&clara\\WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell1\\WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell1 005.axgd"
    ##ZAP
    ##ROOTPATH="D:\\data-yves\\labo\\devel\\intrinsic\\lianglin\\testfiles_1\\20210215 039.axgd"
    ##merged CCSteps, matlab merge
    #ROOTPATH="D:\\data-yves\\labo\\projects\\Patch-Seq-GADGFP\\Cell_Recordings\\20211008_57n\\20211008_57n.maty"
    ## AHP, pclamp version (increasing steps)
    #ROOTPATH="D:\\data-yves\\labo\\projects\\Patch-Seq-GADGFP\\Cell_Recordings\\20211217_111s\\20211217_111s_0006.abf"
    ## ramp
    #ROOTPATH="D:\\data-yves\\labo\\projects\\Patch-Seq-GADGFP\\Cell_Recordings\\20211215_82n\\20211215_82n_0007.abf"
    if len(sys.argv)>1:
        ROOTPATH=sys.argv[1]
    ## do not modify after this point!
    try:ROOTPATH
    except:
        logging.getLogger(__name__).critical("ROOTPATH is not defined.") 
        logging.getLogger(__name__).critical("Either provide path to a valid *.axgx,*.axgd,*.abf file,")
        logging.getLogger(__name__).critical("or edit this file to hard code the value of ROOTPATH in __main__ section.")
        exit(0)
    tics = time.perf_counter()
    logging.getLogger(__name__).setLevel(20)
    process(Path(ROOTPATH).resolve())
    logging.getLogger(__name__).info(f"Completed analysis of {filecount} files in {time.perf_counter()-tics} seconds")
