#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import sys
sys.path.insert(0,"./modules")

## data science stack
from config import cfg
import logging
import numpy as np
import quantities as pq
from quantities import uV,mV,V
from quantities import pA,nA,uA,mA,A
from quantities import ns,us,ms,s

import neo
from xyfitter import XYFitter
from baseprotocol import once,BaseFrame,BaseProtocol
from neomonkey import average

from utils import _autoscale,_clamp, _norm, _pq_mean, _pq_max, _pq_nearest,_pq_value,_pq_unit

'''
    Resistance Protocol, Frick lab version
    attempts to fit a single of double exponential over Voltage curve and measures resistance
    input:  sigs: list of neo.io.AnalogSignal
            cmds: list of corresponding current steps (quantities.quantity)
            interactive: show the frames
    cfg:    INPUTR_CURRENT_INJECTION_START, INPUTR_CURRENT_INJECTION_STOP, INPUTR_TCFIT_START, INPUTR_TCFIT_STOP
            ITSQ_FIT_ITERATION_COUNT, ITSQ_FITTER_VERSION
            OUTPUT_OHM_UNIT, OUTPUT_V_UNIT, OUTPUT_S_UNIT
            ITSQ_FIT_ITERATION_COUNT
    usage:  protocol=InputResProtocol(sigs,cmds,interactive)
            print(protocol.results())
'''
class InputResFrame(BaseFrame):
    PROCESS_RESISTANCE=0x0001
    PROCESS_TIMECONSTANT=0x0002
    def __init__(self,sig,cmd,idx,parent):
        self.voltage=sig
        self.currentstep=cmd
        super(InputResFrame,self).__init__(idx,parent)

    def process(self,bitmask=0xFFFF):
        midpoint=0.66*(cfg.INPUTR_CURRENT_INJECTION_START+cfg.INPUTR_CURRENT_INJECTION_STOP)
        self.baseline=self.voltage.t(0.0*s,cfg.INPUTR_CURRENT_INJECTION_START).V.mean()
        self.steadystate=self.voltage.t(midpoint,cfg.INPUTR_CURRENT_INJECTION_STOP).V.mean()
        self.resistance=(self.baseline-self.steadystate)/self.currentstep
        ## because fitter object is agnostic to units, we must provide everything dimentionless
        times=self.voltage.t(cfg.INPUTR_TCFIT_START,cfg.INPUTR_TCFIT_STOP).s.magnitude
        volts=self.voltage.t(cfg.INPUTR_TCFIT_START,cfg.INPUTR_TCFIT_STOP).V.magnitude
        self.fitter=XYFitter(times,
                             volts,
                            cfg.INPUTR_TCFIT_ORDER,
                            cfg.INPUTR_TCFIT_WEIGHTED_AVERAGE,
                            maxfev=cfg.ITSQ_FIT_ITERATION_COUNT)
        if self.fitter.success:
            self.fitline=neo.AnalogSignal(self.fitter.line(times)*pq.V,
                                        sampling_period=self.voltage.sampling_period,
                                        t_start=times[0]*pq.s)
        ## adjust time constant units
        self.fitter.tc*=pq.s

        peaktime=self.voltage.argmin()*self.voltage.sp ## get negative peak (in points) and convert to times
        self.sagpeak=self.voltage.at(peaktime,avg=1*pq.ms)
        self.sagratio=(self.baseline-self.steadystate)/(self.baseline-self.sagpeak)

    @once
    def setup(self):
        self._fig().subplots(1, 1)
        self._cursor(self._axes(0),'v',cfg.INPUTR_TCFIT_START,
                    lambda x:cfg.set('INPUTR_TCFIT_START',x) or self.parent.process(0xFFFF) or self.parent.draw (drawall=False))
        self._cursor(self._axes(0),'v',cfg.INPUTR_TCFIT_STOP,
                    lambda x:cfg.set('INPUTR_TCFIT_STOP',x) or self.parent.process(0xFFFF) or self.parent.draw (drawall=False))

    def draw(self,drawall=True):
        self.setup() ## ensure that axes are ready!
        self._fig().canvas.TopLevelParent.SetTitle("Resistance protocol")
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            self._axes(0).plot(self.voltage.s, self.voltage.V,color='blue',gid='traces')
            _autoscale(self._axes(0),self.voltage.s,self.voltage.V)
        self._clf(['markers'])
        self._axes(0).set_title(f'Res : {self.resistance.rescale(cfg.OUTPUT_OHM_UNIT):5.2f} '+\
                                f'TC: {self.fitter.tc.rescale(cfg.OUTPUT_S_UNIT):.4f}')
        if self.fitter.success:
            self._axes(0).plot( self.fitline.s, self.fitline.V,color='red',gid='markers')
        self._axes(0).axhline(self.baseline,color="black",linestyle ="--",gid='markers')
        self._axes(0).axhline(self.steadystate,color="grey",linestyle ="--",gid='markers')
        self._axes(0).axhline(self.sagpeak,color="green",linestyle ="--",gid='markers')

class InputResProtocol(BaseProtocol):
    def __init__(self,sigs,cmds,interactive,fig=None):
        self.frames=[InputResFrame(s,cmds[e],idx=e,parent=self) for e,s in enumerate(sigs) ]
        super(InputResProtocol,self).__init__(interactive,fig=fig)

    @classmethod
    def fromexp(cls,exp):
        sig=exp.signal(0)
        avgsig=average(sig)
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            exp.protocol.scaleoutput(0,[-1500*pq.pA,1500*pq.pA])
            cfg.INPUTR_CURRENT_INJECTION_START=exp.protocol.asepochs(0)[0][1]['start']
            cfg.INPUTR_CURRENT_INJECTION_STOP=exp.protocol.asepochs(0)[0][1]['stop']
            cfg.INPUTR_CURRENT_STEPS=[e[1]['lvl'] for e in exp.protocol.asepochs(0)]
            cfg.INPUTR_TCFIT_START=cfg.INPUTR_CURRENT_INJECTION_START+0.01*pq.s
            cfg.INPUTR_TCFIT_STOP=cfg.INPUTR_CURRENT_INJECTION_STOP-0.01*pq.s
        return cls(sig,cfg.INPUTR_CURRENT_STEPS,True,None)

    def provides(self):
        return {'INPUTR_res':'avg input resistance',
                'INPUTR_tc':'avg time constant',
                'INPUTR_baseline':'avg baseline before current pulse',
                'INPUTR_sagratio':'avg sag ratio'}

    def results(self):
        f=self.frames[0]
        self.r= {'INPUTR_res':f.resistance.rescale(cfg.OUTPUT_OHM_UNIT) if f.enabled else np.nan,
                ## due to the way fitter object works, the units for time constant are lost. we need to readjust them to pq.s
                'INPUTR_tc':(f.fitter.tc).rescale(cfg.OUTPUT_S_UNIT) if f.fitter.success and f.enabled else np.nan,
                'INPUTR_baseline':f.baseline.rescale(cfg.OUTPUT_V_UNIT) if f.enabled else np.nan,
                'INPUTR_sagratio':f.sagratio if f.enabled else np.nan
                }
        return self.r

    def params(self):
        return []

    def dispatch(self,evt):
        key=evt.GetKey()                ## retrieve the key for event, i.e the control that was modified
        # wait_crsr = wx.BusyCursor()   ## show some fancy cursor (useless!)
        if key in ['cmd_btn']:
            ## you may pass either the modified value or the entire parameter set (as dict) to event handler
            #value=evt.GetValue()
            #p=evt.EventObject
            #self.currentframe().process(value, p)
            pass
        # del wait_crsr                ## restore previous cursor