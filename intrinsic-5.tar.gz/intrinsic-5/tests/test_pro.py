if __name__=='__main__':
    ## system wide imports
    import warnings
    warnings.filterwarnings("ignore")
    warnings.simplefilter("ignore")
    from pyinstrument import Profiler  ## profile code
    import pathlib
    import matplotlib
    matplotlib.use('WXAgg')
    import numpy
    import quantities as pq
    import wx
    import os,sys
    sys.path.insert(0,os.getcwd())
    sys.path.insert(0,'./modules/')
    sys.path.insert(0,'../')

    import wxplotdialog,wxparampanel,experiment
    from utils import _pq_value,_pq_unit
    import neomonkey
    neomonkey.installmonkey()
    
    import jsonpicklehandlers
    jsonpicklehandlers.register_neo_handlers(200)

    from config import cfg
    cfg.parse("./params/default_params.py")

    from baseprotocol import BaseProtocol
    from pro_inputres import InputResProtocol
    from pro_iv import IVProtocol
    from pro_ahp import AHPProtocol
    from pro_rheobase import RheobaseProtocol
    from pro_spontaneousactivity import SpontaneousActivityProtocol
    from pro_timeconstant import TimeConstantProtocol
    from pro_sag import SagProtocol
    from pro_ramp import RampProtocol
    from pro_resonnance import ResonnanceProtocol
    from pro_pscs import PSCProtocol
    ROOT="../../samples/"
    INPUTRES=   ["yukti&clara/WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell4/WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell4 005.axgd"
                ]
    IV=         ["yukti&clara/WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell2/WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell2 001.axgd",
                "yukti&clara/WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell1/WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell1 002.axgd",
                "senka/5199-cfc-yfp-1/5199-cfc-yfp-1 017.axgd",
                "yves/maty/20220314_113s_0002.maty",
                "yves/maty/20211112_108s_0002.maty"
                ]
    RHEO=       ["yves/rheo/20211112_107s_0001.abf"
                ]
    SPONT=      ["yukti&clara/WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell1/WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell1 005.axgd",
                "yukti&clara/WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell2/WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell2 005.axgd",
                "yukti&clara/WTC1-V2.1-12w-B3-DIV34-2022.03.14-Cell3/WTC1-V2.1-12w-B3-DIV35-2022.03.14 cell3 003.axgd"
                ]
    AHP=        ["yukti&clara/WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell2/WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell2 009.axgd",
                 "yukti&clara/WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell2/WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell2 011.axgd",
                 "yukti&clara/3APs/0220504_4471 cell 4 010.axgd",
                 "yukti&clara/3APs/2022.06.02_1818_Cell3 009.axgd",
                 "yukti&clara/WTC1-V2.1-12w-B1-DIV28-2022.03.08-Cell4/wtc1-v2.1-12w-b1-div28-2022.03.08-cell4 006.axgd",
                 "yukti&clara/WTC1-V2.1-12w-B1-DIV28-2022.03.08-Cell4/wtc1-v2.1-12w-b1-div28-2022.03.08-cell4 007.axgd",
                 "yukti&clara/WTC1-V2.1-12w-B1-DIV28-2022.03.08-Cell4/wtc1-v2.1-12w-b1-div28-2022.03.08-cell4 008.axgd",
                 "yukti&clara/WTC1-V2.1-12w-B1-DIV28-2022.03.08-Cell4/wtc1-v2.1-12w-b1-div28-2022.03.08-cell4 009.axgd",
                 "lianglin/2021-02-08/2021-02-08 15AP train.axgd"
                 ]
    TC=         ["yukti&clara/WTC1-V2.2-12w-A1-DIV24-2022.03.11-Cell4/WTC1-V2.2-12w-A1-DIV24-2022.03.11 cell4 004.axgd"
                ]
    SAG=        ["yukti&clara/sag/0220509_4473 cell 4 006.axgd",
                 "yukti&clara/sag/0220509_4473 cell 1 008.axgd"
                ]
    RAMP=       ["yves/ramps/ramp2.abf"
                ]
    RES=        ["senka/5199-cfc-yfp-1/5199-cfc-yfp-1 005.axgd",
                 "lianglin/testfiles_4/20210215 039.axgd"
                ]
    PSC=        ["yves/synaptic/20211110_103s.smr",
                 "yves/synaptic/20211215_85n#1.smr",
                 "yves/synaptic/20211215_85n#4.smr"
                ]
    PATH=PSC[-1]
    PROTOCOL=PSCProtocol
    LOAD=False
    SAVE=False

    exppath=pathlib.Path(ROOT+PATH)
    app = wx.App(False)
    ## creates experiment and protocol
    if not LOAD:
        myexp=experiment.Experiment(exppath)
        if numpy.isnan(myexp.protocol.dacunits[0]):
            myexp.protocol.scaleoutput(0,[-800*pq.pA,800*pq.pA])
        protocol=PROTOCOL.fromexp(myexp)
    elif LOAD:
        protocol=BaseProtocol.loaddata(exppath)
    ## creates fig and display. This is not mandatory and protocol can run without any display!
    ## one may create a ParamPlotDialog (which handles extra commands) or a PlotDialog
    if True:
        dlg=wxplotdialog.ParamPlotDialog(None, size=(1200,600))
        for p in protocol.params():
            dlg.parampanel.append(p)
        dlg.parampanel.Bind(wxparampanel.EVT_PARAMPANEL_CHANGED, protocol.dispatch)
    else:
        dlg=wxplotdialog.PlotDialog(None, size=(1200,600))
    ## attach protocol to figure
    protocol.attach(dlg.fig)
    ## shows everything
    dlg.ShowModal()
    dlg.Destroy()
    
    ## before saving data, we keep current protocol configuration
    ## because quantities are objects, we store a standalone copy
    if SAVE:
        protocol.cfgsave={k:v for k,v in cfg.__dict__.items() if k.startswith('__') and 'UNIT' not in k}
        protocol.cfgsave.update({k:v*1.0 for k,v in cfg.__dict__.items() if isinstance(v,pq.Quantity) and 'UNIT' not in k})
        protocol.savedata(exppath,protocol.__class__.__name__)
        
    for  k,v in protocol.results().items():
        print(k, (_pq_value(v) , _pq_unit(v)))