#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import sys
sys.path.insert(0,"./modules")

## data science stack
from config import cfg
import logging
import numpy as np
import quantities as pq
from quantities import uV,mV,V
from quantities import pA,nA,uA,mA,A
from quantities import ns,us,ms,s

import neo
from xyfitter import XYFitter
from baseprotocol import once,BaseFrame,BaseProtocol

from utils import _autoscale,_clamp, _norm, _pq_mean, _pq_max, _pq_nearest,_pq_value,_pq_unit

'''
    Time Constant Protocol, Frick lab version
    attempts to fit a single of double exponential over Voltage curve
    input:  sigs: list of neo.io.AnalogSignal with units V, mV (units are not checked, so should also work with pA)
            cmds: list of current steps (quantities.quantity). used to differentiate between positive and negative current steps
            interactive: show the frames
    cfg:    TC_FIT_START,TC_FIT_STOP,TC_FIT_ORDER,TC_WEIGHTED_AVERAGE
            OUTPUT_S_UNIT
            ITSQ_FIT_ITERATION_COUNT
    usage:  protocol=TCProtocol(sigs,cmds,interactive)
            print(protocol.results())
'''
class TimeConstantFrame(BaseFrame):
    def __init__(self,sig,cmd,idx,parent,*kwargs):
        self.voltage=sig
        self.currentstep=cmd
        super(TimeConstantFrame,self).__init__(idx,parent)

    def process(self,bitmask=0xFFFF):
        times=self.voltage.t(cfg.TC_FIT_START,cfg.TC_FIT_STOP).s.magnitude
        volts=self.voltage.t(cfg.TC_FIT_START,cfg.TC_FIT_STOP).V.magnitude
        self.fitter=XYFitter(times,
                             volts,
                            cfg.TC_FIT_ORDER,
                            cfg.TC_WEIGHTED_AVERAGE,
                            maxfev=cfg.ITSQ_FIT_ITERATION_COUNT)
        if self.fitter.success:
            self.fitline=neo.AnalogSignal(self.fitter.line(times)*pq.V,
                                        sampling_period=self.voltage.sampling_period,
                                        t_start=times[0]*pq.s)
            ## adjust time constant units
        self.fitter.tc*=pq.s
    
    @once
    def setup(self):
        self._fig().subplots(1, 1)
        self._cursor(self._axes(0),'v',cfg.TC_FIT_START,
                    lambda x:cfg.set('TC_FIT_START',x) or self.parent.process(0xFFFF) or self.parent.draw (False))
        self._cursor(self._axes(0),'v',cfg.TC_FIT_STOP,
                    lambda x:cfg.set('TC_FIT_STOP',x) or self.parent.process(0xFFFF) or self.parent.draw (False))

    def draw(self,drawall=True):
        self.setup() ## ensure that axes are ready!
        self._fig().canvas.TopLevelParent.SetTitle("Time constant protocol")
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            self._axes(0).plot(self.voltage.s, self.voltage.V,color='blue',gid='traces')
            _autoscale(self._axes(0),self.voltage.s,self.voltage.V)
        self._clf(['markers'])
        if self.fitter.success:
            self._axes(0).set_title(f'TC: {self.fitter.tc.rescale(cfg.OUTPUT_S_UNIT)}')
            self._axes(0).plot( self.fitline.s, self.fitline.V,color='red',gid='markers')

class TimeConstantProtocol(BaseProtocol):
    def __init__(self,sigs,cmds,interactive,fig=None):
        self.frames=[TimeConstantFrame(s,cmds[e],idx=e,parent=self) for e,s in enumerate(sigs) ]
        super(TimeConstantProtocol,self).__init__(interactive,fig=fig)

    @classmethod
    def fromexp(cls,exp):
        sig=exp.signal(0)
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            exp.protocol.scaleoutput(0,[-1510*pq.pA,1510*pq.pA])
            cfg.TC_FIT_START=exp.protocol.asepochs(0)[0][1]['stop']+cfg.EPSILON
            #cfg.TC_FIT_STOP=exp.protocol.asepochs(0)[0][1]['stop']+0.04*pq.s
            cfg.TC_FIT_STOP=max(sig[0].times)-10*cfg.EPSILON
            cfg.TC_FIT_CURRENT_STEPS=[e[1]['lvl'] for e in exp.protocol.asepochs(0)]
        return cls(sig,cfg.TC_FIT_CURRENT_STEPS,True,None)

    def provides(self):
        return {'TC_tc_neg':'avg time constant, measured for negative current pulse',
                'TC_tc_pos':'avg time constant, measured for positive current pulse'}

    def results(self):
        posf=[f.fitter.tc for f in self.frames if f.currentstep>0 and f.fitter.success and f.enabled ]
        negf=[f.fitter.tc for f in self.frames if f.currentstep<0 and f.fitter.success and f.enabled ]
        self.r= {'TC_tc_neg':_pq_mean(posf,cfg.OUTPUT_S_UNIT) if len(negf) else np.nan*cfg.OUTPUT_S_UNIT,
                 'TC_tc_pos':_pq_mean(posf,cfg.OUTPUT_S_UNIT) if len(posf) else np.nan*cfg.OUTPUT_S_UNIT}
        return self.r

    def params(self):
        return []

    def dispatch(self,evt):
        key=evt.GetKey()                ## retrieve the key for event, i.e the control that was modified
        # wait_crsr = wx.BusyCursor()   ## show some fancy cursor (useless!)
        if key in ['cmd_btn']:
            ## you may pass either the modified value or the entire parameter set (as dict) to event handler
            #value=evt.GetValue()
            #p=evt.EventObject
            #self.currentframe().process(value, p)
            pass
        # del wait_crsr                    ## restore previous cursor 