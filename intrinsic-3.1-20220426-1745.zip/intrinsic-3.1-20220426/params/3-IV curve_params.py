## parameters for IV curve analysis. Units are Volts and seconds
IV_CURRENT_INJECTION_START=0.2                          ## current injection start time. ususally 0.1 or 0.2      
IV_CURRENT_INJECTION_STOP=1.0                           ## current injection stop time ususally 0.9 or 1.0
## test