#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import jsonpickle
import numpy as np
import quantities as pq
import neo
'''
import jsonpickle.ext.numpy as jsonpickle_numpy
from jsonpickle.ext.numpy import NumpyBaseHandler,NumpyGenericHandler,NumpyNDArrayHandlerView
@jsonpickle.handlers.register(np.int64, base=True)
@jsonpickle.handlers.register(np.int32, base=True)
@jsonpickle.handlers.register(np.float64, base=True)
@jsonpickle.handlers.register(np.float32, base=True)
@jsonpickle.handlers.register(np.generic, base=True)
class MyScalarHandler(NumpyGenericHandler):
    def flatten(self, obj, data):
        try:
            return obj.item()
        except:
            return super(MyScalarHandler,self).flatten(obj,data)


@jsonpickle.handlers.register(np.ndarray, base=True)
class MyArrayHandler(NumpyNDArrayHandlerView):
    def flatten(self, obj, data):
        ## NumpyNDArrayHandlerViewis complex. calling super will fail if obj.size<size_treshold
        ## we don't care as we want to dump all small objects as lists(object size<250)  
        if obj.size<250:
            return obj.tolist()
        else:
            return super(MyArrayHandler,self).flatten(obj.copy(),data)
        #except Exception as ex:
        #    print(*args,**kwargs)
        #    template = "An exception of type {0} occurred. Arguments:\n{1!r}"
        #    message = template.format(type(ex).__name__, ex.args)
        #    print(message)

@jsonpickle.handlers.register(pq.Quantity, base=True)
class MyQuantityHandler(NumpyNDArrayHandlerView):
    def flatten(self, obj, data):  # data contains {}
        try:
            return super(MyQuantityHandler,self).flatten(obj.copy(),data)
        except:
            return("JSONPICKLEERROR")
'''

from jsonpickle.ext.numpy import register_handlers,register,NumpyNDArrayHandlerView

class MyAnalogSignalHandler(NumpyNDArrayHandlerView):
    def flatten(self, obj, data):
        r=super(MyAnalogSignalHandler,self).flatten(np.array(obj),data)
        r.update({'units':obj.dimensionality.string,
                'sampling_rate':float(obj.sampling_rate),
                's_units':obj.sampling_rate.dimensionality.string,
                'sampling_period':float(obj.sampling_period),
                't_start':float(obj.times[0]) if len(obj) else 0.0, ## zero length AnalogSignal don't have times[0] member
                't_units':obj.times.dimensionality.string})
        return r

    def restore(self,data):
        d=super(MyAnalogSignalHandler,self).restore(data)
        return neo.AnalogSignal(d,pq.Quantity(1,data['units']),
                                sampling_rate=pq.Quantity(data['sampling_rate'],data['s_units']),
                                t_start=pq.Quantity(data['t_start'],data['t_units'])
                            )

class MyQuantityHandler(NumpyNDArrayHandlerView):
    def flatten(self, obj, data):  # data contains {}
        if obj.size>self.size_threshold:
            r=super(MyQuantityHandler,self).flatten(np.array(obj),data)
            r.update({'units':obj.dimensionality.string})
        elif obj.size>1:
            r=data
            r.update({'values':[float(x) for x in np.array(obj)],
               'units':obj.dimensionality.string
            })
        elif obj.size==1:
            r=data
            r.update({'values':float(obj),
                'units':obj.dimensionality.string
            })
        elif obj.size==0:
            ## slicing a quantity may result in an empty array, e.g
            ## peaks=times[[s.time for s in frame.spikes]] when frame.spikes is empty
            r=data
            r.update({'values':[],
                'units':obj.dimensionality.string,
                'WTF':'What the fuck'})
        return r

    def restore(self,data):
        if isinstance(data['values'],str):
            d=super(MyQuantityHandler,self).restore(data)
            return pq.Quantity(d,data['units'])
        elif isinstance(data['values'],list):
            return pq.Quantity(data['values'],data['units'])
        elif isinstance(data['values'],float):
            return pq.Quantity(data['values'],data['units'])

class NumpyScalarHandler(jsonpickle.handlers.BaseHandler):
    def flatten(self, obj, data):
        data['value'] = self.context.flatten(obj.tolist())
        data['dtype'] = self.context.flatten(obj.dtype)
        return data

    def restore(self, data):
        dtype = self.context.restore(data['dtype'])
        #return dtype.type(self.context.restore(data['value']))
        return data['value']

def register_neo_handlers(size_threshold):
    register_handlers()
    register(np.ndarray, NumpyNDArrayHandlerView(size_threshold=100), base=True)
    register(pq.quantity.Quantity,MyQuantityHandler(size_threshold=size_threshold),base=True)
    register(neo.AnalogSignal,MyAnalogSignalHandler(size_threshold=0),base=True)
    #register(np.generic,NumpyScalarHandler,base=True)

if __name__=='__main__':
    #import jsonpickle.ext.numpy as jsonpickle_numpy
    import neo
    import quantities as pq
    #from jsonpickle.ext.numpy import register_handlers,register,NumpyBaseHandler,NumpyGenericHandler,NumpyNDArrayHandlerView,NumpyNDArrayHandlerView
    #register_handlers()
    #register(np.ndarray, NumpyNDArrayHandlerView(size_threshold=100), base=True)
    #register(pq.quantity.Quantity,MyQuantityHandler(size_threshold=100),base=True)
    #register(neo.AnalogSignal,MyAnalogSignalHandler(size_threshold=0),base=True)
    register_neo_handlers(size_threshold=100)
    arrsize=10
    #d=np.ndarray(shape=(1,arrsize),buffer=np.array([1.0/np.random.randint(1,65365) for _ in range(arrsize)]).tobytes())
    d=np.random.rand(int(arrsize))
    d=np.random.rand(int(arrsize))*pq.mV
    #d=neo.AnalogSignal(np.random.rand(int(110))*pq.mV,sampling_rate=50000*pq.Hz)
    #d=3.14*pq.mA
    enc=jsonpickle.encode(d)
    dec=jsonpickle.decode(enc)
    print(enc,type(dec))
