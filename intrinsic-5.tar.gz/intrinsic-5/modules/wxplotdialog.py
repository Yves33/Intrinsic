#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import wx
import matplotlib
from matplotlib.backend_bases import NavigationToolbar2
from matplotlib.backends.backend_wxagg import (
    FigureCanvasWxAgg as FigureCanvas,
    NavigationToolbar2WxAgg
    )
class NewNavigationToolbar2WxAgg(NavigationToolbar2WxAgg):
    def zoom(self,*args):
        enabled=not(str(args[0].EventObject.mode)=='zoom rect')
        self.ToggleTool(self.wx_ids['Zoom'], enabled)
        self.ToggleTool(self.wx_ids['Pan'], False)
        NavigationToolbar2.zoom(self, *args)

    def pan(self,*args):
        enabled=not(str(args[0].EventObject.mode)=='pan/zoom')
        self.ToggleTool(self.wx_ids['Pan'], enabled)
        self.ToggleTool(self.wx_ids['Zoom'], False)
        NavigationToolbar2.pan(self, *args)

class PlotDialog(wx.Dialog):
    def __init__(self, *args, **kwargs):
        style=kwargs.pop("style",wx.CLOSE_BOX)
        kwargs["style"]=style|wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER|wx.CLOSE_BOX|wx.MINIMIZE_BOX|wx.MAXIMIZE_BOX
        super(PlotDialog, self).__init__(*args, **kwargs)
        self.InitUI()
        self.SetTitle("matplotlib.pyplot.workaround")

    def ShowModal(self,timeout=-1):
        if timeout>0:
            self.timer = wx.Timer(self)
            self.Bind(wx.EVT_TIMER, self.OnTimer)
            self.timer.Start(timeout)
        super(PlotDialog,self).ShowModal()

    def InitUI(self):
        vbox = wx.BoxSizer(wx.VERTICAL)
        self.fig = matplotlib.figure.Figure((1,1))
        self.canvas = FigureCanvas(self, -1, self.fig)
        self.toolbar = NewNavigationToolbar2WxAgg(self.canvas)  # matplotlib toolbar
        self.toolbar.Realize()

        vbox.Add(self.canvas, proportion=1,flag=wx.ALL|wx.EXPAND, border=5)
        vbox.Add(self.toolbar, 0, wx.EXPAND)
        self.SetSizer(vbox)

    def OnClose(self, e):
        self.Destroy()

    def OnTimer(self,event):
        self.Destroy()

class PlotPanel(wx.Panel):
    def __init__(self, parent):
        self.fig = matplotlib.figure.Figure((1,1))
        super().__init__(parent, -1)
        self.canvas = FigureCanvas(self, -1, self.fig)
        self.toolbar = NewNavigationToolbar2WxAgg(self.canvas)  # matplotlib toolbar
        self.toolbar.Realize()

        # Now put all into a sizer
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.toolbar, 0, wx.EXPAND)
        sizer.Add(self.canvas, 1, wx.LEFT | wx.TOP | wx.EXPAND)
        self.SetSizer(sizer)
        self.Fit()

    def clear(self):
        self.fig.clear()

from wxparampanel import ParamPanel, EVT_PARAMPANEL_CHANGED,EVT_PARAMPANEL_NOTIFY

class ParamPlotDialog(wx.Dialog):
    def __init__(self, *args, **kwargs):
        style=kwargs.pop("style",wx.CLOSE_BOX)
        kwargs["style"]=style|wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER|wx.CLOSE_BOX|wx.MINIMIZE_BOX|wx.MAXIMIZE_BOX
        super(ParamPlotDialog, self).__init__(*args, **kwargs)
        self.InitUI()

    def InitUI(self):
        self.splitter = wx.SplitterWindow(self, wx.ID_ANY, style=wx.SP_BORDER)
        self.splitter.SetMinimumPaneSize(150)
        self.plotpanel = PlotPanel(self.splitter)
        self.parampanel = ParamPanel(self.splitter,label_width=200,widget_width=125,widget_height=24)
        self.splitter.SplitVertically(self.parampanel, self.plotpanel)
        self.splitter.SetSashPosition(350)
        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer.Add(self.splitter,1,wx.EXPAND)
        self.SetSizer(self.sizer)
        self.SetTitle("Template")
        self.Center()
        self.fig=self.plotpanel.fig
        self.append=self.parampanel.append

    def OnExit(self, e):
        self.Close(True)

    def OnSize(self, e):
        size = self.GetSize()
        e.Skip()

    def OnDoubleClick(self, e):
        size =  self.GetSize()
        self.splitter.SetSashPosition(size.x / 2)