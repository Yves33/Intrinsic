#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import sys
sys.path.insert(0,"./modules")
from pathlib import Path

## data science stack
from config import cfg
import logging
import numpy as np
import scipy as sc
import quantities as pq
from quantities import uV,mV,V
from quantities import pA,nA,uA,mA,A
from quantities import ns,us,ms,s

import neo
from xyfitter import XYFitter
from baseprotocol import once,BaseFrame,BaseProtocol

from utils import _autoscale,_clamp, _norm, _pq_mean, _pq_max, _pq_nearest,_pq_value,_pq_unit

from pro_iv import IVFrame,Spike

class RheobaseFrame(IVFrame):
    def process_tc(self):
        pass
    def process_sfa(self):
        pass
    def process_firing_pattern(self):
        pass
    
    @once
    def setup(self):
        super(RheobaseFrame,self).setup()
        ## we'll just modify slightly the second grid
        altaxes=[ax for ax in self._axes() if ax.get_gid()=='alt']
        for ax in altaxes:
            ax.remove()
            del ax
        altaxes=self._fig().subplots(2,2)
        for ax in altaxes.flatten():
            ax.set_gid('alt')
            ax.set_visible(False)

    def drawcharts(self,drawall=False):
        axes=[ax for ax in self._axes() if ax.get_gid()=='alt']
        for ax in axes:
            ax.clear()
        a00,a01,a10,a11=axes
        ref=[f for f in self.parent.frames if len(f.evokedspikes)==0][-1].voltage
        a00.plot(self.voltage.s,self.voltage.V,color='blue')
        if len(self.evokedspikes)>0:
            a01.plot(self.evokedspikes[0].volts,np.gradient(self.evokedspikes[0].volts)*self.voltage.sr,color='blue')
        if self.idx>0:
            delta=self.voltage-ref
            if len(self.evokedspikes)>0:
                # adjust difference to preserve peak
                delta=delta-delta.at(self.evokedspikes[0].time)+self.voltage.at(self.evokedspikes[0].time)
                ##
                a00.plot(ref.s,ref.V,color='g')
                a10.plot(delta.s,delta.V,color='orange')
                pre=cfg.IV_SPIKE_PRE_TIME
                post=cfg.IV_SPIKE_POST_TIME
                t=self.evokedspikes[0].time
                ppv=delta.t(t-pre,t+post).V
                ppdv=np.gradient(ppv)*delta._sampling_rate
                a11.plot(ppv,ppdv,color='orange')
        self._fig().tight_layout()

class RheobaseProtocol(BaseProtocol):
    def __init__(self,sigs,cmds,interactive,fig=None):
        cfg.IV_CURRENT_INJECTION_START=cfg.RHEO_CURRENT_INJECTION_START
        cfg.IV_CURRENT_INJECTION_STOP=cfg.RHEO_CURRENT_INJECTION_STOP+0.05*pq.s ## a spike may occur short after end of pulse
        cfg.IV_BASELINE_START=cfg.RHEO_BASELINE_START
        cfg.IV_BASELINE_STOP=cfg.RHEO_BASELINE_STOP
        self.frames=[RheobaseFrame(s,cmds[e],idx=e,parent=self) for e,s in enumerate(sigs) ]
        super(RheobaseProtocol,self).__init__(interactive,fig=fig)

    @classmethod
    def fromexp(cls,exp):
        voltage=exp.signal(0)
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            epochs=exp.protocol.asepochs(0)
            cfg.RHEO_CURRENT_INJECTION_START=epochs[0][1]['start']
            cfg.RHEO_CURRENT_INJECTION_STOP=epochs[0][1]['stop']
            cfg.RHEO_BASELINE_START=epochs[0][0]['start']
            cfg.RHEO_BASELINE_STOP=epochs[0][0]['stop']
            cfg.RHEO_CURRENT_STEPS=[e[1]['lvl'] for e in epochs]
        return cls(voltage,cfg.RHEO_CURRENT_STEPS,True,None)

    def provides(self):
        r={"RHEO_baseline":"average baseline (all frames)",
            'RHEO_rheobase':'current required to observe a spike between cfg.RHEO_CURRENT_INJECTION_START and cfg.RHEO_CURRENT_INJECTION_STOP.',
            'RHEO_spike_threshold':'spike threshold. computed on first frame with one spike.',
            'RHEO_spike_peak':'spike peak. computed on first frame with one spike.',
            'RHEO_spike_amplitude':'spike amplitude (=peak-threshold). computed on first frame with one spike.',
            'RHEO_spike_half_width':'spike half width (at (peak-threshold)/2). computed on first frame with one spike.',
            'RHEO_spike_max_rise_slope':'spike maximum rise slope. computed on first frame with one spike.',
            'RHEO_spike_max_fall_slope':'spike maximum fall slope. computed on first frame with one spike.',
            'RHEO_spike_ahp':'spike ahp. computed on first frame with one spike.',
        }
        return r

    def results(self):
        self.r={}
        self.r['RHEO_baseline']                                        =_pq_mean([f.baseline for f in self.frames if f.enabled ]).rescale(cfg.OUTPUT_V_UNIT)
        frames_with_evoked_spikes=[f for f in self.frames if f.current>=0 and len(f.evokedspikes)>0 and f.enabled]
        if len(frames_with_evoked_spikes)>0:
            self.r[f'RHEO_rheobase']=frames_with_evoked_spikes[0].current.rescale(cfg.OUTPUT_A_UNIT)
        ##
        frames_with_min_spikes=[f for f in self.frames if len(f.evokedspikes)==1 and f.enabled]
        if len(frames_with_min_spikes)>0:
            reference_frame=frames_with_min_spikes[0]
            self.r['RHEO_spike_threshold']                 =reference_frame.evokedspikes[0].threshold.rescale(cfg.OUTPUT_V_UNIT)
            self.r['RHEO_spike_peak']                      =reference_frame.evokedspikes[0].peak.rescale(cfg.OUTPUT_V_UNIT)
            self.r['RHEO_spike_amplitude']                 =reference_frame.evokedspikes[0].amplitude.rescale(cfg.OUTPUT_V_UNIT)
            self.r['RHEO_spike_half_width']                =reference_frame.evokedspikes[0].halfwidth.rescale(cfg.OUTPUT_S_UNIT)
            self.r['RHEO_spike_max_rise_slope']            =reference_frame.evokedspikes[0].maxrise.rescale(cfg.OUTPUT_V_UNIT/cfg.OUTPUT_S_UNIT)
            self.r['RHEO_spike_max_fall_slope']            =reference_frame.evokedspikes[0].maxfall.rescale(cfg.OUTPUT_V_UNIT/cfg.OUTPUT_S_UNIT)
            if reference_frame.idx==0:
                self.r['RHEO_spike_ahp']=np.nan
            else:
                t0=reference_frame.evokedspikes[0].time-0.005*pq.s
                t1=reference_frame.evokedspikes[0].time+0.05*pq.s
                sub=self.frames[reference_frame.idx].voltage-self.frames[reference_frame.idx-1].voltage
                self.r['RHEO_spike_ahp']=np.min(sub.t(t0,t1).V).rescale(cfg.OUTPUT_V_UNIT)
        return self.r

    def params(self):
        return []

    def dispatch(self,evt):
        key=evt.GetKey()                ## retrieve the key for event, i.e the control that was modified
        # wait_crsr = wx.BusyCursor()   ## show some fancy cursor (useless!)
        if key in ['cmd_btn']:
            ## you may pass either the modified value or the entire parameter set (as dict) to event handler
            #value=evt.GetValue()
            #p=evt.EventObject
            #self.currentframe().process(value, p)
            pass
        # del wait_crsr                    ## restore previous cursor