#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import sys
sys.path.insert(0,"./modules")
import logging

## data science stack
from config import cfg
import logging
import numpy as np
import scipy as sc
import quantities as pq
from quantities import uV,mV,V
from quantities import pA,nA,uA,mA,A
from quantities import ns,us,ms,s

import neo
from xyfitter import XYFitter
from baseprotocol import once,BaseFrame,BaseProtocol

from utils import _autoscale,_clamp, _norm, _pq_mean, _pq_max, _pq_nearest,_pq_value,_pq_unit

'''
    Ramp Protocol,
    fits a straight line at start and stop of descending ramp and computes the ratio
    input:  sigs: list of neo.io.AnalogSignal with units A,mA, uA, nA, pV (units are not checked, so should also work with pA)
            cmds: the clamping voltage (list neo.io.AnalogSignal with units V, mV)
            interactive: show the frames
    cfg:    RAMP_DOWN_START,RAMP_DOWN_STOP,RAMP_UP_START,RAMP_UP_STOP,RAMP_VOLTAGE_STEPS
            OUTPUT_A_UNIT, OUTPUT_S_UNIT
    usage:  protocol=ResonnanceProtocol(sigs,cmds,interactive)
            print(protocol.results())
'''
class RampFrame(BaseFrame):
    def __init__(self,sig,cmd,idx, parent):
        self.current=sig
        self.voltage=cmd
        super(RampFrame,self).__init__(idx,parent)
    
    def process(self,bitmask=0xFFFF):
        times=self.current.t(cfg.RAMP_DOWN_START,cfg.RAMP_DOWN_STOP).s.magnitude
        sig1=self.current.t(cfg.RAMP_DOWN_START,cfg.RAMP_DOWN_START+0.2*pq.s)
        self.fitter1=XYFitter(sig1.s.magnitude,
                                sig1.pA.magnitude,
                                0,maxfev=cfg.ITSQ_FIT_ITERATION_COUNT)
        self.fitter1.a*=pA/s
        self.fitline1=neo.AnalogSignal(self.fitter1.line(times)*pq.pA,
                                        sampling_period=self.current.sampling_period,
                                        t_start=times[0]*pq.s)
        sig2=self.current.t(cfg.RAMP_DOWN_STOP-0.2*pq.s,cfg.RAMP_DOWN_STOP)
        self.fitter2=XYFitter(sig2.s.magnitude,
                                sig2.pA.magnitude,
                                0,maxfev=cfg.ITSQ_FIT_ITERATION_COUNT)
        self.fitter2.a*=pA/s
        self.fitline2=neo.AnalogSignal(self.fitter2.line(times)*pq.pA,
                                        sampling_period=self.current.sampling_period,
                                        t_start=times[0]*pq.s)
        

    @once
    def setup(self):
        self._fig().subplots(2, 1,gridspec_kw={'height_ratios': [3, 1],"top":0.9},sharex = True)
        ## tried with for loop and partial, but does not work!
        self._cursor(self._axes(),'v',cfg.RAMP_DOWN_START,
                lambda x:cfg.set('RAMP_DOWN_START',x*pq.s) or self.parent.process() or self.parent.draw (False)
                )
        self._cursor(self._axes(),'v',cfg.RAMP_DOWN_STOP,
                lambda x:cfg.set('RAMP_DOWN_STOP',x*pq.s) or self.parent.process() or self.parent.draw (False)
                )
        self._cursor(self._axes(),'v',cfg.RAMP_UP_START,
                lambda x:cfg.set('RAMP_UP_START',x*pq.s) or self.parent.process() or self.parent.draw (False)
                )
        self._cursor(self._axes(),'v',cfg.RAMP_UP_STOP,
                lambda x:cfg.set('RAMP_UP_STOP',x*pq.s) or self.parent.process() or self.parent.draw (False)
                )

    def draw(self,drawall=True):
        self.setup() ## ensure that axes are ready!
        self._fig().canvas.TopLevelParent.SetTitle("Ramp protocol")
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            self._axes(0).plot(self.current.s,self.current.pA,color='blue',gid='traces')
            self._axes(1).plot(self.voltage.s,self.voltage.mV,color='green',gid='traces')
        self._clf(['markers'])
        if self.fitter1.success:
           self._axes(0).plot(self.fitline1.s,self.fitline1.pA,color='red',gid='markers')
        if self.fitter2.success:
           self._axes(0).plot(self.fitline2.s,self.fitline2.pA,color='darkred',gid='markers')

class RampProtocol(BaseProtocol):
    def __init__(self,sigs,cmds,interactive,fig=None):
        self.frames=[ RampFrame(s,cmds[e],idx=e,parent=self) for e,s in enumerate(sigs) ]
        super(RampProtocol,self).__init__(interactive,fig=fig)

    @classmethod
    def fromexp(cls,exp):
        current=exp.signal(0)
        voltage=exp.signal(1)
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            exp.protocol.scaleoutput(0,[-1500*pq.mV,1500*pq.mV])
            cfg.RAMP_DOWN_START=exp.protocol.asepochs(0)[0][1]['start']
            cfg.RAMP_DOWN_STOP=exp.protocol.asepochs(0)[0][1]['stop']
            cfg.RAMP_UP_START=exp.protocol.asepochs(0)[0][3]['start']
            cfg.RAMP_UP_STOP=exp.protocol.asepochs(0)[0][3]['stop']
            cfg.RAMP_VOLTAGE_STEPS=[f[1]['lvl'] for f in exp.protocol.asepochs(0)]
        return cls(current,voltage,True,None)

    def provides(self):
        return {'RAMP_slope_-40':'slope at Vhold=-40mV (pA/s)',
                'RAMP_slope_-120':'slope at Vhold=-120mV (pA/s)',
                'RAMP_iorect_40_over_120':'ratio of the slopes',
                }

    def results(self):
        ramp40=_pq_mean([f.fitter1.a for f in self.frames if f.enabled and f.fitter1.success])
        ramp120=_pq_mean([f.fitter2.a for f in self.frames if f.enabled and f.fitter2.success])
        self.r= {'RAMP_slope_-40':ramp40.rescale(cfg.OUTPUT_A_UNIT/cfg.OUTPUT_S_UNIT) if not np.isnan(ramp40) else np.nan,
                 'RAMP_slope_-120':ramp120.rescale(cfg.OUTPUT_A_UNIT/cfg.OUTPUT_S_UNIT) if not np.isnan(ramp120) else np.nan,
                 'RAMP_iorect_40_over_120':np.nanmean([f.fitter1.a/f.fitter2.a for f in self.frames if f.enabled
                                                                                            and f.fitter1.success 
                                                                                            and f.fitter2.success])
                }
        return self.r