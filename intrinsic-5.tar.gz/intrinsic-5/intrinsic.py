#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is pat of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

## Python stdlib import. Can't live without it
import os,sys,logging,fnmatch,re,time
sys.path.insert(0,"./modules")
from pathlib import Path

import warnings
warnings.filterwarnings('ignore')
warnings.warn = lambda *args,**kwargs:0   ## shut down matplotlib deprecation warnings

## data science stack
import numpy as np
import pandas as pd
import quantities as pq
import neo
import neomonkey
neomonkey.installmonkey()               ## use our custom array access routines

from config import cfg
cfg.parse("./params/default_params.py")
gen_cfg_files=list(Path("./params/").glob("generic_params_*.py"))
if len(gen_cfg_files)>1:
    logging.getLogger('myapp').critical("More than one generic config file was found!")
    exit(-1)
elif len(gen_cfg_files)==1:
    gen_cfg_file=str(gen_cfg_files[0])
    logging.getLogger('myapp').critical(f"Current parameter file {gen_cfg_file}")
    if os.path.isfile(gen_cfg_file):
        cfg.parse(gen_cfg_file)
else:
    logging.getLogger('myapp').critical(f"No user specific configuration file.")
    gen_cfg_file="./params/default_params.py"


import matplotlib
#plt.rcParams['lines.antialiased']=True
#plt.rcParams['lines.linewidth']=1.0

import wxplotdialog,wxparampanel,experiment
from utils import _prefix,_pq_value,_pq_unit

## some other globals
filecount=0	             ## nummber of files that were processed
##################################################################################################
##################################################################################################
## PROTOCOLS ARE NOW IN SEPARATE FILES
from pro_timeconstant import TimeConstantProtocol
from pro_sag import SagProtocol
from pro_inputres import InputResProtocol
from pro_resonnance import ResonnanceProtocol
from pro_ramp import RampProtocol
from pro_ahp import AHPProtocol
from pro_foldername import FolderNameProtocol
from pro_iv import IVProtocol
from pro_spontaneousactivity import SpontaneousActivityProtocol
from pro_rheobase import RheobaseProtocol

##################################################################################################
##################################################################################################
##################################################################################################
## PREPROCESS AND DISPATCH FILES
##################################################################################################
##################################################################################################
##################################################################################################

def process_file(inpath):
    cfg.parse(Path(__file__).resolve().parent/gen_cfg_file)
    neuronprops={}
    protocol=None
    if str(Path(inpath).name)[0] in cfg.ITSQ_SKIP_FILES:
        logging.getLogger('myapp').info(f"Skipping file {str(inpath)}")
        return {}
    myexp=experiment.Experiment(inpath)
    protocolname=myexp.protocol.name
    logging.getLogger('myapp').info(f"{protocolname} : {str(inpath)}")
    ## try to parse protocol specific cfg file
    cfg.parse(Path(__file__).resolve().parent/"params"/(protocolname+"_params.py"))
    ##
    ## processing sag protocol
    if any([fnmatch.fnmatch(protocolname,x) for x in cfg.SAG_PROTOCOL_NAMES])  and 'Sag' in cfg.PROCESS_PROTOCOLS:
        if np.isnan(myexp.protocol.dacunits[0]):
            myexp.protocol.scaleoutput(0,[-800*pq.pA,800*pq.pA])
        protocol=SagProtocol.fromexp(myexp)

    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.TC_PROTOCOL_NAMES])  and 'TimeConstant' in cfg.PROCESS_PROTOCOLS:
        if np.isnan(myexp.protocol.dacunits[0]):
            myexp.protocol.scaleoutput(0,[-1500*pq.pA,1500*pq.pA])
        protocol=TimeConstantProtocol.fromexp(myexp)

    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.INPUTR_PROTOCOL_NAMES])  and 'InputRes' in cfg.PROCESS_PROTOCOLS:
        if np.isnan(myexp.protocol.dacunits[0]):
            myexp.protocol.scaleoutput(0,[-200*pq.pA,200*pq.pA])
        protocol=InputResProtocol.fromexp(myexp)

    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.ZAP_PROTOCOL_NAMES]) and 'Resonnance' in cfg.PROCESS_PROTOCOLS:
        ## don't need dac input values here
        protocol=ResonnanceProtocol.fromexp(myexp)

    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.RAMP_PROTOCOL_NAMES])  and 'Ramp' in cfg.PROCESS_PROTOCOLS:
        if np.isnan(myexp.protocol.dacunits[0]):
            myexp.protocol.scaleoutput(0,[-200*pq.mV,200*pq.mV])
        protocol=RampProtocol.fromexp(myexp)

    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.AHP_PROTOCOL_NAMES])  and 'AHP' in cfg.PROCESS_PROTOCOLS :
        if np.isnan(myexp.protocol.dacunits[0]):
            myexp.protocol.scaleoutput(0,[-1000*pq.pA,1000*pq.pA])
        protocol=AHPProtocol.fromexp(myexp)

    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.IV_PROTOCOL_NAMES])  and 'IV' in cfg.PROCESS_PROTOCOLS:
        if np.isnan(myexp.protocol.dacunits[0]):
            myexp.protocol.scaleoutput(0,[-800*pq.pA,800*pq.pA])
        protocol=IVProtocol.fromexp(myexp)

    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.SPONTANEOUS_PROTOCOL_NAMES])  and 'SpontaneousActivity' in cfg.PROCESS_PROTOCOLS:
        protocol=SpontaneousActivityProtocol.fromexp(myexp)
    ## other protocols to be processed here

    elif any([fnmatch.fnmatch(protocolname,x) for x in cfg.RHEO_PROTOCOL_NAMES])  and 'Rheobase' in cfg.PROCESS_PROTOCOLS:
        if np.isnan(myexp.protocol.dacunits[0]):
            myexp.protocol.scaleoutput(0,[-800*pq.pA,800*pq.pA])
        protocol=RheobaseProtocol.fromexp(myexp)

    else:
        logging.getLogger('myapp').warning(f'Unknown protocol {protocolname}')
        return neuronprops

    ## creates a window to display results and interact with user
    if len(protocol.params())>0:
        dlg=wxplotdialog.ParamPlotDialog(None, size=(1200,600))
        for p in protocol.params():
            dlg.parampanel.append(p)
        dlg.parampanel.Bind(wxparampanel.EVT_PARAMPANEL_CHANGED, protocol.dispatch)
    else:
        dlg=wxplotdialog.PlotDialog(None, size=(1200,600))
    ## attach protocol to figure
    protocol.attach(dlg.fig)
    ## shows everything
    dlg.ShowModal()#timeout=cfg.ITSQ_AUTOCLOSE)
    try:
        dlg.Destroy() ## destroy window if it has not been auto destroyed
    except:
        pass
    
    if not protocol is None and cfg.ITSQ_PROTOCOL_SAVE_DATA:
        ## before saving data, we keep current protocol configuration
        ## because quantities are objects, we store a standalone copy
        protocol.cfgsave={k:v for k,v in cfg.__dict__.items() if k.startswith('__') and 'UNIT' not in k}
        protocol.cfgsave.update({k:v*1.0 for k,v in cfg.__dict__.items() if isinstance(v,pq.Quantity) and 'UNIT' not in k})
        protocol.savedata(inpath,protocol.__class__.__name__)
        
    ## convert return values (which should be pq.Quantity) to tupple (float/int/str, unit_str)
    # neuronprops.update(protocol.results())
    neuronprops.update({k:(_pq_value(v),_pq_unit(v)) for  k,v in protocol.results().items()})
    return neuronprops

def processfolder(fpath):
    ## get meta info from folder
    neuronprops={}
    protocol=FolderNameProtocol(fpath)
    neuronprops.update({k:(_pq_value(v),_pq_unit(v)) for  k,v in protocol.results().items()})
    ## search all files with required extension _prefix(cfg.PROCESS_EXTENSIONS,'*')
    allfiles=[f for ext in _prefix(cfg.PROCESS_EXTENSIONS,'*') for f in fpath.glob(ext) ]
    for inpath in allfiles:
        neuronprops.update(process_file(inpath))
    return neuronprops

def process(inpath):
    cfg.parse(Path(__file__).resolve().parent/gen_cfg_file)
    ## start processing
    allneurons=[]
    ## single file
    if Path(inpath).is_file() and Path(inpath).suffix in _prefix(cfg.PROCESS_EXTENSIONS,''):
        neuron={}
        neuron.update(process_file(Path(inpath)))
        allneurons.append(neuron)

    ## folder with files
    if Path(inpath).is_dir():
        if len([f for ext in _prefix(cfg.PROCESS_EXTENSIONS,'*') for f in Path(inpath).glob(ext) ])>0:
            neuron={}
            neuron.update(processfolder(Path(inpath)))
            allneurons.append(neuron)
        else:
            ## folder with mess
            folders=set([f.parents[0] for ext in _prefix(cfg.PROCESS_EXTENSIONS,'**/*') for f in Path(inpath).glob(ext) ])
            for folder in folders:
                neuron={}
                neuron.update(processfolder(folder))
                allneurons.append(neuron)
    ## before we output to csv,excel, ..., we have to make sure that we have exactly the same fields for all neurons
    ## fortunately, pandas takes care of this for us, provided that an index is given
    df=pd.DataFrame(allneurons).T
    ## when processing several cells (nested folders), missing measurements are replaced by np.nan
    ## to be modified! CSV, JSON and EXCEL don't handle quantity! only output magnitude
    ## when processing several cells (nested folders), missing measurements are replaced by np.nan
    if cfg.OUTPUT_CSV:        df.applymap(lambda x:np.nan if not isinstance(x,tuple) else x[0]).to_csv("results.csv",sep=cfg.OUTPUT_CSVSEP)
    if cfg.OUTPUT_JSON:       df.applymap(lambda x:np.nan if not isinstance(x,tuple) else x[0]).to_json("results.json")
    if cfg.OUTPUT_EXCEL:      df.applymap(lambda x:np.nan if not isinstance(x,tuple) else x[0]).to_excel("results.xlsx")
    if cfg.OUTPUT_CLIPBOARD:
        ## to_clipboard behavior has changed recently...
        df.applymap(lambda x:np.nan if not isinstance(x,tuple) else x[0]).to_clipboard(excel=cfg.OUTPUT_CLIPBOARD_EXCEL,index=cfg.OUTPUT_CLIPBOARD_ROWNAMES)
    return df


def filterfields():
    if (Path(__file__).resolve().parent/cfg.ITSQ_OUTPUT_FIELDS_FILE).is_file():
        outfields=[ l.split("#")[0].rstrip(' \t\n\r').lstrip('+-#')                         \
                    for l in open(Path(__file__).resolve().parent/cfg.ITSQ_OUTPUT_FIELDS_FILE)  \
                    if not ( l.split("#")[0].startswith('-') or \
                            l.split("#")[0].startswith('#') or \
                            len(l.split("#")[0].strip(' \t\n\r')) == 0
                            )
                    ]
    else:
        logging.getLogger('myapp').info("Could not find list of output parametes. Generating one")
        outfields=[ k for pname in cfg.PROCESS_PROTOCOLS for k in globals()[pname+"Protocol"].provides(None).keys()]
        with open(Path(__file__).resolve().parent/cfg.ITSQ_OUTPUT_FIELDS_FILE,'w') as outfile:
            outfile.writelines([l+"\n" for l in outfields])
    return outfields