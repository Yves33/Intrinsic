#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import sys
sys.path.insert(0,"./modules")

## data science stack
from config import cfg
import logging
import numpy as np
import quantities as pq
from quantities import uV,mV,V
from quantities import pA,nA,uA,mA,A
from quantities import ns,us,ms,s

import neo
import neomonkey
from xyfitter import XYFitter
from baseprotocol import once,BaseFrame,BaseProtocol

from utils import _autoscale,_clamp, _norm, _pq_mean, _pq_max, _pq_nearest,_pq_value,_pq_unit


'''
    Sag Protocol, Frick lab version
    measures the ratio between steady stade and peak ratio=(baseline-steady)/(baseline-peak)
    input:  sigs: list of neo.io.AnalogSignal with units V, mV (units are not checked, so should also work with pA)
            cmds: list of corresponding current steps (quantities.quantity)
            interactive: show the frames
    cfg:    SAG_CURRENT_INJECTION_START,SAG_CURRENT_INJECTION_STOP
            SAG_CURRENT_STEPS
    usage:  protocol=SagProtocol(sigs,cmds,interactive)
            print(protocol.results())
'''
class SagFrame(BaseFrame):
    def __init__(self,sig,cmd,idx,parent): ## current should not be passed from constructor but rather read from cfg.SAG_CURRENT_STEPS
        self.voltage=sig
        self.currentstep=cmd
        super(SagFrame,self).__init__(idx,parent)

    def process(self,bitmask=0xFFFF):
        midpoint=0.66*(cfg.SAG_CURRENT_INJECTION_START+cfg.SAG_CURRENT_INJECTION_STOP)
        self.baseline=self.voltage.t(0.0*s,cfg.SAG_CURRENT_INJECTION_START).V.mean()
        self.steadystate=self.voltage.t(midpoint,cfg.SAG_CURRENT_INJECTION_STOP).V.mean()
        peaktime=self.voltage.argmin()*self.voltage.sp ## get negative peak (in points) and convert to times
        self.sagpeak=self.voltage.at(peaktime,sampleavg=1*pq.ms)
        self.sagratio=(self.baseline-self.steadystate)/(self.baseline-self.sagpeak)

    @once
    def setup(self):
        self._fig().subplots(1, 1)

    def draw(self,drawall=True):
        self.setup() ## ensure that axes are ready!
        self._fig().canvas.TopLevelParent.SetTitle("Sag protocol protocol")
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            self._axes(0).plot(self.voltage.s, self.voltage.V,color='blue',gid='traces')
            _autoscale(self._axes(0),self.voltage.s,self.voltage.V)
        self._clf(['markers'])
        self._axes(0).set_title(f'Sag ratio ({self.currentstep}): {self.sagratio:1.2f} ')
        self._axes(0).axhline(self.baseline,color="black",linestyle ="--",gid='markers')
        self._axes(0).axhline(self.steadystate,color="grey",linestyle ="--",gid='markers')
        self._axes(0).axhline(self.sagpeak,color="green",linestyle ="--",gid='markers')

class SagProtocol(BaseProtocol):
    def __init__(self,sigs,cmds,interactive,fig=None):
        self.frames=[SagFrame(s,cmds[e],idx=e,parent=self) for e,s in enumerate(sigs) ]
        super(SagProtocol,self).__init__(interactive,fig=fig)

    @classmethod
    def fromexp(cls,exp):
        sig=exp.signal(0)
        cnt=cfg.SAG_AVERAGE_COUNT
        avgsig=[neomonkey.average( [sig[cnt*i],sig[cnt*i+1],sig[cnt*i+2] ]) for i in range(len(sig)//cnt) ]
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            cfg.SAG_CURRENT_INJECTION_START=exp.protocol.asepochs(0)[0][1]['start']
            cfg.SAG_CURRENT_INJECTION_STOP=exp.protocol.asepochs(0)[0][1]['stop']
            cfg.SAG_CURRENT_STEPS=[e[1]['lvl'] for e in exp.protocol.asepochs(0)][::3]
        return cls(avgsig,cfg.SAG_CURRENT_STEPS,True,None)


    def provides(self):
        r={}
        for c in cfg.SAG_CURRENT_STEPS:
            r[f'SAG_ratio_({c})']=f'average voltage peak value for {c} pA current step'
        return r

    def results(self):
        r={}
        for f in self.frames:
            r[f'SAG_ratio_({f.currentstep})']=f.sagratio if f.enabled else np.nan
        return r

    def params(self):
        return []

    def dispatch(self,evt):
        key=evt.GetKey()                ## retrieve the key for event, i.e the control that was modified
        # wait_crsr = wx.BusyCursor()   ## show some fancy cursor (useless!)
        if key in ['cmd_btn']:
            ## you may pass either the modified value or the entire parameter set (as dict) to event handler
            #value=evt.GetValue()
            #p=evt.EventObject
            #self.currentframe().process(value, p)
            pass
        # del wait_crsr                    ## restore previous cursor