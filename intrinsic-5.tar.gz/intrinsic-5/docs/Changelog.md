Pending bugs:
============
+ icons in toolbar are not always displayed using Qt5/4Agg. I don't know how, I don't know why...


**bug fixes**
see version 3.2 ChangeLog

**new features**

**internals**
+ The different protocols are now splitted in different parts for more clarity
+ The API has changed:
++all protocols takes signal, command, interactive as first 3 parameters.
++the program now uses a wx.Dialog to display frames, which avoids messing up with matplotlib event loop

**todo**
protocols should have a fig and a propertypanel parameter
