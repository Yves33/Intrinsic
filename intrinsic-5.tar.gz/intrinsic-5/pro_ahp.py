#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import sys
sys.path.insert(0,"./modules")

## data science stack
from config import cfg
import logging
import numpy as np
import scipy as sc
import quantities as pq
from quantities import uV,mV,V
from quantities import pA,nA,uA,mA,A
from quantities import ns,us,ms,s

import neo
from xyfitter import XYFitter
from baseprotocol import once,BaseFrame,BaseProtocol

from utils import _autoscale,_clamp, _norm, _pq_mean, _pq_max, _pq_nearest,_pq_value,_pq_unit

'''
    AHP Protocol, Frick lab version
    Measure peak of AHP and AHP within a givent time window. 
    Also dumps voltage drop between baseline and 5 or 10 ms after last start of time window
    Onset of time window is automatically adjusted to last detected spike or last pusle in train
    input:  sigs: list of neo.io.AnalogSignal with units V, mV (units are not checked, so should also work with pA)
            cmds: not used
            frequency: the expected pulse frequency
            apcount: the expected number of APs
            interactive: show the frames
    cfg:    cfg:AHP_SS_START, AHP_SS_STOP, AHP_SPIKE_MIN_PEAK, AHP_SPIKE_MIN_AMP, cfg.AHP_VALID_COMBO
    usage:  protocol=InputResProtocol(sigs,cmds,interactive)
            print(protocol.results())
'''
class AHPFrame(BaseFrame):
    def __init__(self,sig,cmd,idx,parent,frequency,apcount):
        self.voltage=sig
        self.cmd=cmd
        self.parsed_freq=frequency
        self.parsed_apcount=apcount
        self.actual_freq=np.nan
        self.peakpos=[]
        self.ahp_value=np.nan
        self.ahp_value_1s=np.nan
        self.ahp_time=np.nan
        self.adp_5ms=np.nan
        self.adp_10ms=np.nan
        hi,lo=self.voltage.V.max(),self.voltage.V.min()
        delta=(hi-lo)
        cfg.AHP_SPIKE_MIN_PEAK=lo+delta*0.5
        cfg.AHP_SPIKE_MIN_AMP=delta*0.35
        self.strict_policy=False
        super(AHPFrame,self).__init__(idx,parent)

    def prepare(self):
        self.baseline=self.voltage.t(cfg.AHP_SS_START,cfg.AHP_SS_STOP).V.mean()
        ## compute theoretical position of peaks (in s). 
        ## this supposes that AHP_SS_STOP is the time of first pulse
        self.pulse_times=[ cfg.AHP_SS_STOP + 1/self.parsed_freq*x for x in range(self.parsed_apcount) ]
        ## extract real peak positions and computes real frequency
        self.peak_pos,peak_info=sc.signal.find_peaks(self.voltage.V, \
                                        height=float(cfg.AHP_SPIKE_MIN_PEAK.rescale(V)),\
                                        prominence=float(cfg.AHP_SPIKE_MIN_AMP.rescale(V)),\
                                        distance=int(0.00040*self.voltage.sr)) # up to 200Hz
        if len(self.peak_pos)>=2:
            self.actual_freq=(len(self.peak_pos)-1)/(self.voltage.s[self.peak_pos[-1]]-self.voltage.s[self.peak_pos[0]])
            self.actual_freq=int(10*round(self.actual_freq/10)) ## clamp to nearest power of 10
        if self.strict_policy and len(self.peak_pos)!=self.parsed_apcount:
            logging.getLogger().warning("number of detected AP does not match expected number")
        if self.strict_policy and self.actual_freq!=self.parsed_freq:
            logging.getLogger().warning("Measured peak frequency does not match with expected frequency")
        ## todo adjust to nearest frequency and AP count
        self.peaks={'x':self.voltage.s[self.peak_pos],'y':self.voltage.V[self.peak_pos]}
        if len(self.peak_pos):
            self.start,self.stop=self.peaks['x'][-1],self.peaks['x'][-1]+cfg.AHP_MAX_DELAY
        else:
            self.start,self.stop=self.pulse_times[-1],self.pulse_times[-1]+cfg.AHP_MAX_DELAY
        ## As baseprotocol is not inited at that stage, we are not sure that the cursor exist!
        try:
            self.parent.cursors[2].setpos(self.start)
            self.parent.cursors[3].setpos(self.stop)
        except:
            pass

    def measure(self):
        start,stop=self.start,self.stop 
        self.ahp_time=start+self.voltage.t(start,stop).argmin()*self.voltage.sp
        self.ahp_value=self.voltage.at(self.ahp_time).rescale(pq.V) ## both should be quantities!
        self.ahp_1s_value=self.voltage.at(start+1*pq.s).rescale(pq.V)
        self.adp_5ms=self.voltage.at(start+5*pq.ms).rescale(pq.V)
        self.adp_10ms=self.voltage.at(start+10*pq.ms).rescale(pq.V)

    def process(self,bitmask=0xFFFF):
        if bitmask & 0x0001:
            self.prepare()
        if bitmask & 0x0002:
            self.measure()

    @once
    def setup(self):
        self._fig().subplots(1, 1)

        self._cursor(self._axes(0),'h',cfg.AHP_SPIKE_MIN_PEAK,
                    lambda x:cfg.set('AHP_SPIKE_MIN_PEAK',x*pq.V) or self.parent.process(0xFFFF) or self.parent.draw (False))
        self._cursor(self._axes(0),'h',cfg.AHP_SPIKE_MIN_PEAK-cfg.AHP_SPIKE_MIN_AMP,
                    lambda x:cfg.set('AHP_SPIKE_MIN_AMP',cfg.AHP_SPIKE_MIN_PEAK-x*pq.V) or self.parent.process(0xFFFF) or self.parent.draw (False))
        self._cursor(self._axes(0),'v',self.start,
                    lambda x:self.parent.currentframe().__setattr__('start',x*pq.s) or self.parent.process(0x0002) or self.parent.draw (False))
        self._cursor(self._axes(0),'v',self.stop,
                    lambda x:self.parent.currentframe().__setattr__('stop',x*pq.s) or self.parent.process(0x0002) or self.parent.draw (False))

    def draw(self,drawall=True):
        self.setup() ## ensure that axes are ready!
        self._fig().canvas.TopLevelParent.SetTitle("AHP protocol")
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            self._axes(0).plot(self.voltage.s, self.voltage.V,color='blue',gid='traces')
            _autoscale(self._axes(0),self.voltage.s,self.voltage.V)
        self._clf(['markers'])
        self._axes(0).axhline(self.baseline,color="black",linestyle ="--",gid='markers')
        if not np.isnan(self.ahp_value):
            self._axes(0).set_title(f'Calc Freq: {self.parsed_freq:.2f} '+
                               f'AHP : {self.ahp_value}')
            #self._axes(0).axhline(self.ahp_value,color="green",linestyle ="--",gid='markers')
            self._axes(0).plot([self.ahp_time],[self.ahp_value],"o",color='g', gid="markers")
        if not np.isnan(self.ahp_1s_value):
            self._axes(0).set_title(f'Calc Freq: {self.parsed_freq:.2f} '+
                               f'AHP : {self.baseline-self.ahp_value} '+
                               f'AHP_1s{self.baseline-self.ahp_1s_value}')
            self._axes(0).plot([self.start+1*pq.s],[self.ahp_1s_value],"o",color='orange', gid="markers")
        self._axes(0).plot(self.peaks['x'],self.peaks['y'],'x',color='red',gid="markers")

class AHPProtocol(BaseProtocol):
    def __init__(self,sigs,cmds,interactive,fig=None,frequency=None,apcount=None):
        self.frames=[AHPFrame(s,cmds[e],idx=e,parent=self,frequency=frequency,apcount=apcount) for e,s in enumerate(sigs) ]
        super(AHPProtocol,self).__init__(interactive,fig=fig)

    @classmethod
    def fromexp(cls,exp):
        voltage=[exp.signal(0)[0] ]  ## some protocotls @Frick's lab (liangling) have several episodes in AHPframe. only process first
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            epochs=exp.protocol.asepochs(0)[0]
            cfg.AHP_SS_START=epochs[0]['start']
            cfg.AHP_SS_STOP=epochs[0]['stop']
            freq=round(1/(epochs[1]['up']+epochs[1]['down']))*pq.Hz
            apcount=epochs[1]['s_dur']//(epochs[1]['s_up']+epochs[1]['s_down'])
        else:
            import re
            ## todo parse from protocol name
            freqstr=re.search(r'\d*[H,h]z',exp.protocol.name,re.MULTILINE)
            #apstr=re.search(r'\d*AP',protocolname,re.MULTILINE)
            apstr=re.search(r'\d*A',exp.protocol.name,re.MULTILINE)
            try:
                freq=int(freqstr.group(0)[:-2])*pq.Hz
                apcount=int(apstr.group(0)[:-1])
            except:
                logging.getLogger().critical("Could not determine AP count or frequency from protocol name")
                exit()
        return cls(voltage,[None],True,None,
                        frequency=freq,apcount=apcount)
    
    def provides(self):
        r={}
        for cnt,freq in cfg.AHP_VALID_COMBO:
            if cnt<6:
                r.update({f'AHP_{cnt}_{freq*pq.Hz}_ahp_min':'maximal hyperpolarization after last detected pulse.'})
            if cnt>6:
                r.update({f'AHP_{cnt}_{freq*pq.Hz}_ahp_min':'maximal hyperpolarization after last detected pulse.'})
                r.update({f'AHP_{cnt}_{freq*pq.Hz}_ahp_1s':'hyperpolarization 1s after last detected pulse.'})
        for cnt,freq in cfg.AHP_VALID_COMBO:
            r.update({f'AHP_{cnt}_{freq*pq.Hz}_adp_5ms':"ADP 5 ms after last spike (voltage(peak) -voltage(peak+5)"})
            r.update({f'AHP_{cnt}_{freq*pq.Hz}_adp_10ms':"ADP 10 ms after last spike (voltage(peak) -voltage(peak+5)"})
        return r

    def results(self):
        cnt=self.frames[0].parsed_apcount
        freq=self.frames[0].parsed_freq
        if cnt<6: ## AHP MED protocol
            self.r= {f'AHP_{cnt}_{freq}_ahp_min':(self.frames[0].baseline-self.frames[0].ahp_value).rescale(cfg.OUTPUT_V_UNIT)}
        elif cnt>5: ## AHP SLOW protocol
            self.r= {f'AHP_{cnt}_{freq}_ahp_min':(self.frames[0].baseline-self.frames[0].ahp_value).rescale(cfg.OUTPUT_V_UNIT),
                     f'AHP_{cnt}_{freq}_ahp_1s' :(self.frames[0].baseline-self.frames[0].ahp_1s_value).rescale(cfg.OUTPUT_V_UNIT)  }
        self.r.update( {f'AHP_{cnt}_{freq}_adp_5ms': (self.frames[0].baseline-self.frames[0].adp_5ms).rescale(cfg.OUTPUT_V_UNIT) } )
        self.r.update( {f'AHP_{cnt}_{freq}_adp_10ms':(self.frames[0].baseline-self.frames[0].adp_10ms).rescale(cfg.OUTPUT_V_UNIT)} )
        return self.r

    def params(self):
        return []

    def dispatch(self,evt):
        key=evt.GetKey()                ## retrieve the key for event, i.e the control that was modified
        # wait_crsr = wx.BusyCursor()   ## show some fancy cursor (useless!)
        if key in ['cmd_btn']:
            ## you may pass either the modified value or the entire parameter set (as dict) to event handler
            #value=evt.GetValue()
            #p=evt.EventObject
            #self.currentframe().process(value, p)
            pass
        # del wait_crsr                    ## restore previous cursor