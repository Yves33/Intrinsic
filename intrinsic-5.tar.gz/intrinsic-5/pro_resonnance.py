#!/usr/bin/env python3
# Copyright (c)2020-2022, Yves Le Feuvre <yves.le-feuvre@u-bordeaux.fr>
#
# All rights reserved.
#
# This file is prt of the intrinsic program
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted under the terms of the BSD License. See
# LICENSE file in the root of the Project.

import sys
sys.path.insert(0,"./modules")
import logging

## data science stack
from config import cfg
import logging
import numpy as np
import scipy as sc
import quantities as pq

from quantities import uV,mV,V
from quantities import pA,nA,uA,mA,A
from quantities import ns,us,ms,s

import neo
from xyfitter import XYFitter
from baseprotocol import once,BaseFrame,BaseProtocol

from utils import _autoscale,_clamp, _norm, _pq_mean, _pq_max, _pq_nearest,_pq_value,_pq_unit

'''
    Resonnance Protocol, Frick lab version
    computes power spectrum of signal and command. Only the first frame is procesed
    input:  sig: list of neo.io.AnalogSignal with units V, mV (units are not checked, so should also work with pA)
            cmds: list of injected current trace (neo.io.AnalogSignal with units A, mA, uA, nA, pA)
            interactive: show the frames
    cfg:    RES_AMPLITUDES, RES_LOW_BAND, RES_LOW_BAND
            OUTPUT_OHM_UNIT
    usage:  protocol=ResonnanceProtocol(sigs,cmds,interactive)
            print(protocol.results())
'''

class ResonnanceFrame(BaseFrame):
    def __init__(self,sig,cmd,idx, parent):
        self.voltage=sig
        self.current=cmd
        self.start=0
        self.stop=len(self.voltage)
        super(ResonnanceFrame,self).__init__(idx,parent)
    
    def process(self,bitmask=0xFFFF):
        ## quick hack as some protocols in frick's lab have a pre-sweep hyperpolarizing pulse
        self.start=int(_clamp(self.start,0,len(self.voltage)-1))  ## working in samples here!
        self.stop=int(_clamp(self.stop,0,len(self.voltage)-1))    ## working in samples here!
        volts=self.voltage[self.start:self.stop].V
        ref=self.current[self.start:self.stop].A
        self.amplitude=0.5*(np.max(ref[self.start:self.stop])-np.min(ref[self.start:self.stop]))    ## retrieve half amplitude
        #self.amplitude=5*round( (1e12*self.amplitude) / 5 ) / 1e12                                  ## convert to nearest multiple of 5pA
        #self.amplitude=self.amplitude.rescale(cfg.RES_AMPLITUDES[0].units)                          ## convert to user supplied unit
        ## comparing quantities here is complex due to floating point rounding issues....
        ## we check that amplitudes do not differ that much (6%) of at least one of the expected values
        found,self.amplitude=_pq_nearest(self.amplitude,cfg.RES_AMPLITUDES)
        if not found:
            logging.getLogger('myapp').warning(f"Unexpected current amplitude in resonnance protocol {self.amplitude}")
        self.sig_freq,self.sig_pow=sc.signal.periodogram(volts,fs=self.voltage.sr)
        self.ref_freq,self.ref_pow=sc.signal.periodogram(ref,fs=self.current.sr)
        ## given our units, we should have Hz,V,A,Ohm
        ## However, the values are very low 10e-6/10e-24 which results in floating point errors in python
        ## convert to mV and pA
        self.sig_pow*=1e6  *pq.mV*pq.mV/pq.Hz ## 1mV**2
        self.ref_pow*=1e24 *pq.pA*pq.pA/pq.Hz ## 1pA**2
        self.scale=1e9*pq.Ohm                ##d on't know shere this comes from! 1e-3 / 1e-12 ??

        self.impedence=self.sig_pow/self.ref_pow
        self.keep=np.where((self.sig_freq<cfg.RES_HIGH_BAND)&(self.sig_freq>cfg.RES_LOW_BAND))
        self.res_pos=np.argmax(self.impedence[self.keep])
        self.res_freq=float(self.ref_freq[self.keep][self.res_pos])*pq.Hz
        self.res_imp=float(self.impedence[self.keep][self.res_pos])*self.scale
        self.imp05=float(self.impedence[np.argmin(np.abs(self.sig_freq - 0.5*pq.Hz))])*self.scale 

    @once
    def setup(self):
        #self._fig().subplots(3, 1,sharex = True)
        self._fig().subplots(4, 1)
        self._axes(1).sharex(self._axes(0))
        self._axes(2).sharex(self._axes(0))
        self._cursor(self._axes(3),'v',self.start,
                    lambda x:self.parent.currentframe().__setattr__('start',x) or \
                        self.parent.process() or \
                        self.parent.draw (True)
                    )
        self._cursor(self._axes(3),'v',self.stop,
                    lambda x:self.parent.currentframe().__setattr__('stop',x) or \
                        self.parent.process() or \
                        self.parent.draw (True)
                    )

    def draw(self,drawall=True):
        self.setup() ## ensure that axes are ready!
        self._fig().canvas.TopLevelParent.SetTitle("Reonnance protocol")
        if drawall:  ## avoid redrawing signals if not required
            self._clf(['traces'])
            self._axes(0).loglog(self.sig_freq[self.keep],self.sig_pow[self.keep],c='#1f77b4',gid="traces")
            #self._axes(0).set_title("Voltage power spectrum",fontdict={'fontsize':10})
            #_autoscale(self._axes(0),self.sig_freq[self.keep],self.sig_pow[self.keep])
            self._axes(1).loglog(self.ref_freq[self.keep],self.ref_pow[self.keep],c='#1f77b4',gid="traces")
            #self._axes(1).set_title("Current power spectrum",fontdict={'fontsize':10})
            #_autoscale(self._axes(1),self.ref_freq[self.keep],self.ref_pow[self.keep])
            self._axes(2).loglog(self.ref_freq[self.keep],self.impedence[self.keep]*self.scale,c='#1f77b4',gid="traces")
            #self._axes(2).set_title("Impedance",fontdict={'fontsize':10})
            #_autoscale(self._axes(2),self.ref_freq[self.keep],self.impedence[self.keep])
            self._axes(3).plot(self.voltage.V, color='k',gid="traces")
            #self._axes(3).set_title("Voltage",fontdict={'fontsize':10})
        self._clf(['markers'])
        self._axes(2).loglog([self.res_freq],self.res_imp,'o',color='orange',gid="markers")
        self._axes(2).loglog([0.5],self.imp05,'x',color='green',gid="markers")
        self._fig().tight_layout()

class ResonnanceProtocol(BaseProtocol):
    def __init__(self,sigs,cmds,interactive,fig=None):
        self.frames=[ ResonnanceFrame(sigs[0],cmds[0],idx=0,parent=self)  ]
        super(ResonnanceProtocol,self).__init__(interactive,fig=fig)

    @classmethod
    def fromexp(cls,exp):
        voltage=exp.signal(0)
        try:
            current=exp.signal(1)
        except:
            ## too much variation in protol names here. force load current with exact same name as protocol 
            from pathlib import Path
            reffilepath=str(Path(__file__).resolve().parent/"resources"/exp.protocol.name)
            values=np.loadtxt(reffilepath+'.txt',delimiter='\t',skiprows=1,usecols=1)
            current=[neo.AnalogSignal(values, units=pq.A,sampling_rate=voltage[0].sampling_rate)]
            resonnance_error_string='''
            Your protocol does not include Current recording. 
            Moreover, the sampling/frequency/duration is not compatible with the template protocol frequency/duration.
            Can't process that file unless you provide a valid protocol
            '''
            logging.getLogger().warning(resonnance_error_string)
        if cfg.ITSQ_PARSE_PROTOCOLS: ## get pulses info
            ## nothing to parse here.
            pass
        return cls(voltage,current,True,None)

    def provides(self):
        r={}
        for amp in cfg.RES_AMPLITUDES:
            r.update({f'RES_resonnance_{amp}':'resonnance frequency',
                f'RES_impedance_{amp}':'impedence of neurone at resonnance frequency',
                f'RES_impedance_05Hz_{amp}':'impedence of neurone at 0.5Hz'}
            )
        return r

    def results(self):
        self.r= {f'RES_resonnance_{self.frames[0].amplitude}':self.frames[0].res_freq,
                f'RES_impedance_{self.frames[0].amplitude}':self.frames[0].res_imp.rescale(cfg.OUTPUT_OHM_UNIT),
                f'RES_impedance_05Hz_{self.frames[0].amplitude}':self.frames[0].imp05.rescale(cfg.OUTPUT_OHM_UNIT),
                }
        return self.r

    def params(self):
        return []

    def dispatch(self,evt):
        key=evt.GetKey()                ## retrieve the key for event, i.e the control that was modified
        # wait_crsr = wx.BusyCursor()   ## show some fancy cursor (useless!)
        if key in ['cmd_btn']:
            ## you may pass either the modified value or the entire parameter set (as dict) to event handler
            #value=evt.GetValue()
            #p=evt.EventObject
            #self.currentframe().process(value, p)
            pass
        # del wait_crsr                 ## restore previous cursor